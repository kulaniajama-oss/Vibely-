package com.vibely.app.data

import okhttp3.OkHttpClient
import java.util.Locale
import java.util.concurrent.TimeUnit

/** One HTTP client for the whole app (connection reuse, same timeouts everywhere). */
internal val sharedHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        // Free Render instances sleep when idle; the first request can take ~50 s to wake up.
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
}

/** Accepts seconds ("123.4"), "mm:ss" or "hh:mm:ss". Returns whole seconds, or null if unknown. */
fun runtimeSeconds(raw: String?): Int? {
    val text = raw?.trim().orEmpty()
    if (text.isEmpty()) return null
    if (text.contains(':')) {
        val parts = text.split(':').map { it.trim().toDoubleOrNull() ?: return null }
        if (parts.size !in 2..3) return null
        var total = 0.0
        for (p in parts) total = total * 60 + p
        return total.toInt().takeIf { it > 0 }
    }
    return text.toDoubleOrNull()?.toInt()?.takeIf { it > 0 }
}

/** "125" -> "2:05", "3725.4" -> "1:02:05", "12:30" stays "12:30"; null when unknown. */
fun formatRuntime(raw: String?): String? {
    val text = raw?.trim().orEmpty()
    if (text.contains(':')) return text.takeIf { runtimeSeconds(it) != null }
    val total = runtimeSeconds(text) ?: return null
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(Locale.ROOT, h, m, s) else "%d:%02d".format(Locale.ROOT, m, s)
}

/** A safe, unique file name for a download: "<id>_<remote name>" with only letters, digits and . _ - */
fun downloadFileName(id: String, remoteName: String): String {
    val ext = remoteName.substringAfterLast('.', "").filter { it.isLetterOrDigit() }.take(5)
    val base = (id + "_" + remoteName.substringBeforeLast('.'))
        .replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
    return if (ext.isEmpty()) base else "$base.$ext"
}
