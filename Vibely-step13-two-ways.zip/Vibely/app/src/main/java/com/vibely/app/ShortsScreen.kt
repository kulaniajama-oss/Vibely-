package com.vibely.app

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.vibely.app.data.LibraryRepository
import com.vibely.app.data.VibelyRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import androidx.media3.common.MediaItem as ExoMediaItem

/** What the Shorts player is doing for the clip that is on screen. */
private enum class ShortState { LOADING, PLAYING, PAUSED, FAILED }

/**
 * Shorts tab: a vertical feed of short clips (stock-footage sites). The clip on screen plays
 * inline (loops), tap to pause/resume, swipe up for the next one. Like and Share are real; Comments
 * need an account and are not built yet.
 */
@Composable
fun ShortsContent(
    modifier: Modifier = Modifier,
    library: LibraryRepository,
    signedIn: Boolean,
    onRequireSignIn: () -> Unit
) {
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload) {
        loading = true
        val result = VibelyRepository.shorts()
        items = result.items
        message = result.message
        loading = false
    }

    Box(modifier.fillMaxSize().background(Bg)) {
        when {
            loading -> CircularProgressIndicator(color = Accent, modifier = Modifier.align(Alignment.Center))
            items.isEmpty() -> Column(
                Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    message.ifBlank { "No shorts found." },
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { reload++ }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                    Text("Try again")
                }
            }
            else -> ShortsPager(items, library, signedIn, onRequireSignIn)
        }
    }
}

@Composable
private fun ShortsPager(
    items: List<MediaItem>,
    library: LibraryRepository,
    signedIn: Boolean,
    onRequireSignIn: () -> Unit
) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(pageCount = { items.size })
    val page = pagerState.settledPage

    // One player for the whole feed; it belongs to this screen and is released when the tab is left.
    val shortsPlayer = remember {
        ExoPlayer.Builder(context)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
            .apply { repeatMode = Player.REPEAT_MODE_ONE }
    }
    DisposableEffect(shortsPlayer) { onDispose { shortsPlayer.release() } }

    var urls by remember { mutableStateOf<List<String>>(emptyList()) }
    var urlIndex by remember { mutableIntStateOf(0) }
    var state by remember { mutableStateOf(ShortState.LOADING) }
    var retry by remember { mutableIntStateOf(0) }

    // Player events: buffering / playing / paused, and "try the next file" when one cannot be decoded.
    DisposableEffect(shortsPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_BUFFERING) state = ShortState.LOADING
                if (playbackState == Player.STATE_READY) {
                    state = if (shortsPlayer.playWhenReady) ShortState.PLAYING else ShortState.PAUSED
                }
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (shortsPlayer.playbackState == Player.STATE_READY) {
                    state = if (playWhenReady) ShortState.PLAYING else ShortState.PAUSED
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                if (urlIndex + 1 < urls.size) urlIndex += 1 else state = ShortState.FAILED
            }
        }
        shortsPlayer.addListener(listener)
        onDispose { shortsPlayer.removeListener(listener) }
    }

    // Stop playing when the app leaves the screen.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, shortsPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) shortsPlayer.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // When a new clip settles on screen, find its real file URLs.
    LaunchedEffect(page, items, retry) {
        val item = items.getOrNull(page) ?: return@LaunchedEffect
        state = ShortState.LOADING
        shortsPlayer.stop()
        shortsPlayer.clearMediaItems()
        urls = emptyList()
        urlIndex = 0
        try {
            urls = VibelyRepository.resolve(item, fresh = retry > 0).urls
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            state = ShortState.FAILED
        }
    }

    // Play the file we are currently trying (the next one after a decode error).
    LaunchedEffect(urls, urlIndex) {
        val url = urls.getOrNull(urlIndex) ?: return@LaunchedEffect
        shortsPlayer.setMediaItem(ExoMediaItem.fromUri(url))
        shortsPlayer.prepare()
        shortsPlayer.playWhenReady = true
    }

    VerticalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize(),
        key = { index -> items[index].key }
    ) { index ->
        val item = items[index]
        val active = index == page
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AsyncImage(
                model = item.thumbnailUrl,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
            if (active) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            this.player = shortsPlayer
                            useController = false
                        }
                    },
                    update = { it.player = shortsPlayer },
                    onRelease = { it.player = null }
                )
                // Tap anywhere on the clip: retry if it failed, otherwise pause / resume.
                Box(
                    Modifier.fillMaxSize().clickable(onClickLabel = "Pause or resume") {
                        if (state == ShortState.FAILED) {
                            retry++
                        } else if (shortsPlayer.isPlaying) {
                            shortsPlayer.pause()
                        } else {
                            shortsPlayer.play()
                        }
                    }
                )
                when (state) {
                    ShortState.LOADING -> CircularProgressIndicator(
                        color = Accent,
                        modifier = Modifier.align(Alignment.Center)
                    )
                    ShortState.PAUSED -> Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "Paused",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.align(Alignment.Center).size(72.dp)
                    )
                    ShortState.FAILED -> Text(
                        "Couldn't play this clip. Tap to retry or swipe up for the next one.",
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(32.dp)
                    )
                    ShortState.PLAYING -> Unit
                }
            }
            ShortOverlay(item, library, signedIn, onRequireSignIn)
        }
    }
}

/** Title at the bottom, Like / Comments / Share on the right. */
@Composable
private fun BoxScope.ShortOverlay(
    item: MediaItem,
    library: LibraryRepository,
    signedIn: Boolean,
    onRequireSignIn: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val liked by remember(item.key) { library.isLiked(item) }.collectAsStateWithLifecycle(initialValue = false)
    var promptFor by remember { mutableStateOf<String?>(null) } // what a guest tried to do

    Column(
        Modifier.align(Alignment.BottomStart)
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
            .padding(start = 16.dp, end = 76.dp, top = 28.dp, bottom = 16.dp)
    ) {
        Text(
            item.title,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Text("${item.uploader} • ${item.source}", color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
    }

    Column(
        Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        IconButton(onClick = {
            if (signedIn) {
                scope.launch { library.setLiked(item, !liked) }
            } else {
                promptFor = "like videos"
            }
        }) {
            Icon(
                if (signedIn && liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (signedIn && liked) "Unlike" else "Like",
                tint = if (signedIn && liked) Accent else Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
        IconButton(onClick = {
            if (signedIn) {
                // Comments need server-side storage that does not exist yet; say so honestly.
                Toast.makeText(context, "Comments are coming soon.", Toast.LENGTH_SHORT).show()
            } else {
                promptFor = "comment on videos"
            }
        }) {
            Icon(Icons.Default.ChatBubbleOutline, "Comments", tint = Color.White, modifier = Modifier.size(28.dp))
        }
        IconButton(onClick = {
            val text = listOfNotNull(item.title, item.pageUrl).joinToString("\n")
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(send, "Share"))
        }) {
            Icon(Icons.Default.Share, "Share", tint = Color.White, modifier = Modifier.size(28.dp))
        }
    }

    promptFor?.let { action ->
        SignInPromptDialog(
            action = action,
            onSignIn = {
                promptFor = null
                onRequireSignIn()
            },
            onDismiss = { promptFor = null }
        )
    }
}
