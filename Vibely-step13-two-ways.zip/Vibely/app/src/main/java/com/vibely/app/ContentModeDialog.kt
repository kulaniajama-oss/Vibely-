package com.vibely.app

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibely.app.data.ContentMode

/** Settings → Media sources: how Vibely gets its videos (this phone, the Vibely server, or both). */
@Composable
fun ContentModeDialog(
    current: ContentMode,
    serverConfigured: Boolean,
    onPick: (ContentMode) -> Unit,
    onClose: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Media sources") },
        text = {
            Column {
                ContentMode.values().forEach { mode ->
                    Row(
                        Modifier.fillMaxWidth()
                            .selectable(selected = mode == current, role = Role.RadioButton, onClick = { onPick(mode) })
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        RadioButton(
                            selected = mode == current,
                            onClick = null, // the whole row is the target
                            colors = RadioButtonDefaults.colors(selectedColor = Accent)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(mode.label, fontWeight = FontWeight.Medium)
                            Text(mode.description, fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (serverConfigured) "A Vibely server is set up in this build."
                    else "No Vibely server is set up in this build (VIBELY_BACKEND_URL), so the phone is used.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done", color = Accent) } }
    )
}
