package com.vibely.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ContentModeTest {
    @Test
    fun modeIsReadFromItsKeyAndDefaultsToAutomatic() {
        assertEquals(ContentMode.PHONE, ContentMode.fromKey("phone"))
        assertEquals(ContentMode.SERVER, ContentMode.fromKey("server"))
        assertEquals(ContentMode.AUTO, ContentMode.fromKey("auto"))
        assertEquals(ContentMode.AUTO, ContentMode.fromKey(null))
        assertEquals(ContentMode.AUTO, ContentMode.fromKey("something else"))
        assertEquals(3, ContentMode.values().map { it.key }.toSet().size)
    }

    @Test
    fun breakerSkipsTheServerForAWhileAndResets() {
        var now = 1_000L
        val breaker = BackendBreaker(pauseMs = 180_000L, clock = { now })
        assertTrue(breaker.available())
        breaker.trip()
        assertFalse(breaker.available())
        now += 179_999L
        assertFalse(breaker.available())
        now += 1L
        assertTrue(breaker.available())          // pause is over: try the server again
        breaker.trip()
        breaker.reset()                          // the server woke up
        assertTrue(breaker.available())
    }
}
