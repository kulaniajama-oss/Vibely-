# Vibely

Vibely is an Android app (Kotlin + Jetpack Compose) with a small Python server (FastAPI). The server visits
several video websites politely, keeps a catalogue of their newest videos, and finds a **fresh playable link at the
moment you tap a video**. The app shows the catalogue, searches it, and plays the video inside Vibely (Media3/ExoPlayer,
or the site's own web player in a WebView when a site gives no direct file). Nothing opens in the browser.

> There is **no Internet Archive** in Vibely any more, and no website's API key is needed to run it.

## The 5-stage roadmap, and where each stage lives

| Stage | What | Where |
| --- | --- | --- |
| 1. Planning and analysis | The site list, and how each site delivers video (API / page HTML, direct `.mp4`/`.m3u8` / embed) | table below |
| 2. Scraper | One extractor per site, all producing the same JSON shape (`title, thumbnail, source_name, page_url, published_date`); scheduled scrape into SQLite | `backend/app/scraping/sites.py`, `backend/app/db.py`, `backend/app/jobs.py` |
| 3. Backend API and live stream extractor | `/api/videos` feed from the database; `/api/stream?url=` finds a fresh link when a video is tapped (links expire, so none is stored) | `backend/app/main.py`, `backend/app/scraping/stream.py` |
| 4. Mobile app | Home feed, filter by **site** (chips) or search by title, Media3 player, WebView fallback, Shorts | `app/` (`VibelyRepository.kt`, `MainActivity.kt`, `PlayerScreen.kt`, `EmbedPlayer.kt`) |
| 5. Test and publish | Rate limiting, unit tests in GitHub Actions, Render deployment, APK builds | `backend/tests`, `.github/workflows`, `render.yaml` |

### The sites (Stage 1)

| Site | How it is read | How it plays |
| --- | --- | --- |
| Pexels | web page HTML (BeautifulSoup) | direct `.mp4` found on the video page |
| Pixabay | web page HTML | direct `.mp4` found on the video page |
| Mixkit | web page HTML | direct `.mp4` found on the video page |
| Rumble | web page HTML + its embed data | `.mp4` when available, otherwise Rumble's web player inside the app |
| Odysee | its public search + LBRY resolve endpoint | `.mp4` stream, web player as fallback |
| PeerTube (diode.zone) | official public API | `.mp4` or HLS, web player as fallback |
| Wikimedia Commons | official MediaWiki API | `.webm` / `.mp4` |
| Dailymotion | official public API (list only) | Dailymotion's web player |
| Vimeo | web page HTML + public oEmbed | Vimeo's web player |

Where a site offers a public API it is used (more reliable than reading pages). Pages are only read where there is
no API. Every extractor is a pure parsing function plus a thin fetch, so when a site changes its layout the fix is
one function in `sites.py` and a server update: **the app does not need to be updated.**

## Two ways to read the sites (the phone and the server)

Vibely can read the websites in two ways, and **both are built in**:

1. **The phone itself** reads the sites (the original way). It needs no server, no deployment, nothing.
2. **The Vibely server** (Render) reads them for you, keeps a catalogue, and keeps up with website changes without
   an app update.

**Settings → Media sources** chooses how Vibely works:

| Mode | What happens |
| --- | --- |
| **Automatic** (default) | The server is asked first, with short time limits (6 s to connect, 12 s to answer). If it is missing, asleep or failing, **the phone reads the sites at once, exactly as before**, and the server is left alone for 3 minutes. |
| **This phone only** | The server is never used. Works with no server at all. |
| **Server only** | Only the server is used; an error is shown when it is down (for testing the server). |

When the app opens it also sends a quiet request to wake a sleeping free server, so after the first minute the server
answers again and is used. If you never set `VIBELY_BACKEND_URL`, the app simply works on the phone alone.
The Home message says which way answered ("from the Vibely server" or "read on this phone").

## What the server does

* **Polite:** `robots.txt` is checked before any page is read (and our own name, `VibelyBot`, is honoured), requests
  to one site are spaced 0.4 s apart, timeouts are short, and the User-Agent says what this is.
* **Scheduled scrape:** every `SCRAPE_INTERVAL_MINUTES` (default 45) the newest videos of every site are stored in
  SQLite. One site failing never stops the others; `/api/sources` shows each site's last result.
* **Live stream extractor:** `/api/stream?url=<video page>` uses the site's own extractor first and falls back to
  [yt-dlp](https://github.com/yt-dlp/yt-dlp) (only for the sites above, or hosts you add in `EXTRA_STREAM_HOSTS`).
  Answers are cached for 15 minutes.
* **Rate limiting:** `RATE_LIMIT_PER_MINUTE` requests per IP (default 90), then HTTP 429.

| Endpoint | Purpose |
| --- | --- |
| `GET /api/videos?page=&source=` | newest videos, mixed across sites (or one site) |
| `GET /api/search?q=&page=&source=` | live search of the sites + the catalogue |
| `GET /api/shorts` | short clips (stock-footage sites, or anything up to 2 minutes) |
| `GET /api/stream?url=` | fresh playable link and/or web-player address for a video page |
| `GET /api/sources` | the sites, video counts, last scrape result |
| `POST /api/admin/scrape` | run a scrape now (needs the `X-Admin-Token` header; for outside timers) |

## What Vibely will not do (on purpose)

* **YouTube is not supported.** Getting YouTube streams out of the page means getting around protections YouTube
  puts there, and its terms do not allow it. The server refuses YouTube addresses; this is also why `yt-dlp` is limited
  to an allowlist.
* No logging in to sites, no captcha solving, no DRM-protected streams (those formats are skipped), no hiding who is asking.
* A site that says "no" in `robots.txt`, or blocks the server, is simply skipped.
* Each site has its own terms and each video its own licence. **Read them before you publish the app.** Pexels, Pixabay
  and Mixkit clips are free-licence stock footage; Rumble, Odysee, Vimeo and Dailymotion videos belong to their uploaders.
  A Google Play listing is unlikely to be accepted for an app like this; share the APK from your own site or F-Droid.

## Honest limits

* Websites change. Mixkit, Pexels, Pixabay, Rumble and Vimeo are read from their pages and can break without notice.
  Datacenter addresses (Render) are blocked by some sites more often than a phone is, which is why **the app also
  reads the same sites straight from the phone when the server is missing, asleep or failing.**
* Render's free plan sleeps when idle (the first request takes ~50 s) and wipes its disk on restart. The catalogue then
  refills itself on the next request. To keep it fresh while the server sleeps, use the GitHub **Vibely Scrape** timer
  (see "Connect Render").
* Nothing here has been run against the live websites by the person who wrote it: the parsers are tested with saved
  page snippets, not with the real sites. Expect to fix a parser or two after the first deployment.

## App features

* Home with filter chips (All + one per site), infinite scroll, search by title or site name, results cached for
  5 minutes and readable offline.
* Player: Media3/ExoPlayer with a MediaSession service (background play, notification, headset controls), a web-player
  fallback (WebView, fullscreen, cannot navigate away from the site), retry, plain-language errors, and "More from this site".
* Shorts: vertical feed of short clips with inline playback, like and share.
* Library on the device (Room): history, liked, saved, playlists, downloads (direct files only), with optional Firebase
  account sync. Guests can search and watch without an account.
* Settings: account, background play, appearance, playback, privacy.

## Build APK on GitHub

1. Create a GitHub repository named `Vibely`.
2. Upload/push the contents of this folder to the repository root.
3. Open **Actions** and run **Vibely Android APK**, or push to `main`.
4. When the workflow finishes, open its run and download the `Vibely-debug-apk` artifact.

The workflow uses Gradle 8.9 and JDK 17. Android Gradle Plugin 8.7.3 is configured in the root
Gradle build.

## Connect Render (the server)

1. Create a Render Web Service from this repository, root directory `backend` (or use the included `render.yaml`
   blueprint). Deploy the Docker service.
2. Environment variables (all optional):

   | Name | Default | Meaning |
   | --- | --- | --- |
   | `SCRAPE_INTERVAL_MINUTES` | `45` | how often the server scrapes by itself (`0` = never) |
   | `DB_PATH` | `data/vibely.db` | where the SQLite catalogue is kept |
   | `RATE_LIMIT_PER_MINUTE` | `90` | requests per IP per minute |
   | `ADMIN_TOKEN` | *(none)* | enables `POST /api/admin/scrape` (the blueprint generates one) |
   | `EXTRA_STREAM_HOSTS` | *(none)* | extra websites (comma separated) allowed through yt-dlp. Never YouTube. |

3. Copy the service URL, e.g. `https://vibely-api.onrender.com`. Open `/api/sources`: every site should show a video
   count after the first scrape (a minute or two).
4. In GitHub: **Settings, Secrets and variables, Actions, Variables:** `VIBELY_BACKEND_URL` = that URL. Re-run
   **Vibely Android APK**. (Locally you can instead edit `BACKEND_BASE_URL` in `app/build.gradle.kts`.)
5. *(Optional, keeps a sleeping free server fresh)* add the secret `VIBELY_ADMIN_TOKEN` (the same value as the server's
   `ADMIN_TOKEN`). The **Vibely Scrape** workflow then asks the server to scrape every 30 minutes.

To update a broken extractor: change the parser in `backend/app/scraping/sites.py`, add the changed page snippet to
`backend/tests/test_sites.py`, push. Render redeploys; the app keeps working.

## Connect Firebase (optional — enables account + cloud sync)

Accounts need Firebase: **without it nobody can sign in, so everyone stays a guest who can only watch videos.** To turn on accounts, the library and sync:

1. In the [Firebase console](https://console.firebase.google.com) create a project.
2. Add an **Android app** with package name `com.vibely.app` (the app id changed when EbisaTube was renamed
   to Vibely — an Android app registered with the old `com.ebisa.tube` name will not work) and download
   `google-services.json`.
3. **Authentication → Sign-in method →** enable **Email/Password**.
4. **Firestore Database → Create database.** Open the **Rules** tab, paste the contents of
   `firebase/firestore.rules`, and **Publish**.
5. In your GitHub repo: **Settings → Secrets and variables → Actions → New repository secret**.
   Name: `GOOGLE_SERVICES_JSON`, value: the full contents of `google-services.json`.
6. Re-run the **Vibely Android APK** workflow and install the new APK.
7. In the app: **Settings → Account → Create account**. Your library syncs automatically.

For a local build, put `google-services.json` in `app/` (it is git-ignored). Never commit it or any
service-account private key.

How sync works: Room on the device is the source of truth. While signed in, every change is also written to
`users/{uid}/…` in Firestore, and **Sync now** (also run on sign-in and app start) merges the cloud library
with the device. Items removed while offline can reappear after the next sync. Signing in with a *different*
account clears the previous account's local library first, so data is never copied between accounts.

## Signed release build

The debug APK from **Vibely Android APK** is for testing. For a version you can share or publish, build a
**signed** one. You only create the signing key once.

**1. Create the signing key (on your own device).** Needs a JDK (`pkg install openjdk-17` in Termux):

```
bash tools/make-keystore.sh
```

It asks for a password and a few details, then writes `vibely-release.jks` and
`vibely-release.jks.base64.txt`. **Back up `vibely-release.jks` and the password somewhere safe.** If you lose
either, you can never ship an update to people who installed a signed Vibely. Never commit or share them
(both file types are git-ignored).

**2. Add them to GitHub.** Repo → **Settings → Secrets and variables → Actions**.

*Secrets* tab:

| Name | Value |
| --- | --- |
| `KEYSTORE_BASE64` | full contents of `vibely-release.jks.base64.txt` |
| `KEYSTORE_PASSWORD` | the password you chose |
| `KEY_ALIAS` | `vibely` |
| `KEY_PASSWORD` | the same password again |

*Variables* tab: `VIBELY_BACKEND_URL` = your Render URL, e.g. `https://vibely-api.onrender.com`
(optional: without it the app reads the sites straight from the phone). The debug workflow uses this variable too.

**3. Build.** **Actions → Vibely Release (signed) → Run workflow.** When it finishes, download
`Vibely-release-apk` (install on phones) and `Vibely-release-aab` (upload to Google Play). Pushing a tag such
as `v0.8.0` also attaches both files to a GitHub Release.

Things to know:

- A signed build has a different signature than debug builds, so Android will not install it over a debug
  install of the same app. **Uninstall the debug Vibely first** (local history/playlists on that install are
  lost unless you signed in and synced).
- Each run raises the version code automatically, so later releases can update earlier ones.
- Local signing is also possible: put `storeFile`, `storePassword`, `keyAlias`, `keyPassword` in a git-ignored
  `keystore.properties` in the project root and run `gradle :app:assembleRelease`.
- Email/password sign-in needs no key fingerprints. The workflow prints the SHA-1/SHA-256 of your key (public
  information) in case you add Google sign-in later.
- Code shrinking (R8) is off on purpose until it has been tested on a real device.

## Roadmap

- [x] Library, accounts and sync, background playback, paging and caching, guest mode, signed releases.
- [x] Step 12: **Internet Archive removed.** Content now comes from the sites above, through the Vibely server
      (scheduled scrape, SQLite catalogue, live `/api/stream` extractor) with the phone as the automatic fallback.
      Home filters by site; the Internet Archive categories, item details, comments and "more like this" are gone.
- [x] Two ways to read the sites: the phone (as before) and the server, with automatic fallback and a switch in Settings.
- [ ] Comments (needs a server-side store).
- [ ] More sites: add one `Site` subclass in `sites.py` (see PeerTube for an API site, Mixkit for a page-reading site).
- [ ] Source toggles in Settings (hide a site).

## License

Choose and add a project license before distributing. `yt-dlp` is released under the Unlicense; if you reuse NewPipe
code, comply with its GPL-3.0 license and all applicable attribution/source-distribution requirements.
