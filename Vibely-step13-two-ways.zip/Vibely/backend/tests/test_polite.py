from app.scraping.polite import FetchError, Politeness, robots_allows, fetch_text


def test_robots_rules_are_honoured():
    txt = "User-agent: *\nDisallow: /private\nAllow: /private/open\nDisallow: /*.json$\n\nUser-agent: other\nDisallow: /"
    assert robots_allows(txt, "/free-stock-video/")
    assert not robots_allows(txt, "/private/area")
    assert robots_allows(txt, "/private/open/page")
    assert not robots_allows(txt, "/data/list.json")
    assert robots_allows("", "/anything")


def test_a_rule_for_our_own_name_is_honoured():
    txt = "User-agent: VibelyBot\nDisallow: /\n"
    assert not robots_allows(txt, "/video/1")
    assert robots_allows("User-agent: SomeoneElse\nDisallow: /\n", "/video/1")


def test_spacing_between_requests_to_one_site():
    now = [100.0]
    slept = []
    p = Politeness(min_gap_seconds=0.4, clock=lambda: now[0], sleep=slept.append)
    assert p.wait_turn("a.com") == 0
    assert abs(p.wait_turn("a.com") - 0.4) < 1e-9      # second request is delayed
    assert p.wait_turn("b.com") == 0                    # another site is independent
    now[0] += 10
    assert p.wait_turn("a.com") == 0                    # long enough ago: no wait
    assert len(slept) == 1


def test_robots_are_fetched_once_per_site_and_unreachable_means_allowed():
    calls = []
    p = Politeness()

    def get_robots(url):
        calls.append(url)
        return "User-agent: *\nDisallow: /blocked"

    assert p.allowed("https://x.com/ok", get_robots)
    assert not p.allowed("https://x.com/blocked/page", get_robots)
    assert len(calls) == 1

    def broken(url):
        raise RuntimeError("down")

    assert Politeness().allowed("https://y.com/anything", broken)


def test_only_https_is_fetched():
    try:
        fetch_text("http://example.com/")
    except FetchError:
        return
    raise AssertionError("http should have been refused")
