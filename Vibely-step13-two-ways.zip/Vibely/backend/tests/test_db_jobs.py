from app.db import Store
from app.jobs import interleave, pages_for, scrape_all, search_live
from app.ratelimit import SlidingWindowLimiter
from app.scraping.models import Entry
from app.cache import TTLCache


def e(source, vid, title="T", seconds=None, uploader="U", published=None):
    return Entry(source, source.title(), vid, title, uploader, None, f"https://{source}.example/{vid}", seconds, None, published)


def test_upsert_keeps_first_seen_and_fills_gaps():
    s = Store(":memory:")
    assert s.upsert([e("a", "1", "Old title")]) == 1
    s.upsert([e("a", "1", "New title", seconds=30, published="2025-01-02")])
    rows = s.feed()
    assert len(rows) == 1
    assert rows[0]["title"] == "New title" and rows[0]["duration_seconds"] == 30 and rows[0]["published_date"] == "2025-01-02"
    s.upsert([e("a", "1", "Newest", seconds=None)])                       # missing duration must not erase the known one
    assert s.feed()[0]["duration_seconds"] == 30


def test_feed_mixes_sites_round_robin_and_pages():
    s = Store(":memory:")
    s.upsert([e("a", str(i)) for i in range(1, 5)] + [e("b", "1"), e("b", "2")])
    order = [(r["source_id"]) for r in s.feed(limit=6)]
    assert order == ["a", "b", "a", "b", "a", "a"]
    assert len(s.feed(limit=2, offset=2)) == 2
    assert {r["source_id"] for r in s.feed(source="b")} == {"b"}
    assert s.counts() == {"a": 4, "b": 2} and s.total() == 6


def test_search_matches_every_word_in_title_uploader_or_source_name():
    s = Store(":memory:")
    s.upsert([e("rumble", "1", "Funny cats", uploader="CatChannel"), e("pexels", "2", "Sea waves", uploader="Ann")])
    assert [r["video_id"] for r in s.search("funny cats")] == ["1"]
    assert [r["video_id"] for r in s.search("rumble")] == ["1"]        # by source name
    assert [r["video_id"] for r in s.search("ann sea")] == ["2"]       # words may come from different fields
    assert s.search("100%") == [] and s.search("a_b") == []            # wildcards are not special
    assert [r["video_id"] for r in s.search("sea", source="rumble")] == []


def test_shorts_are_stock_clips_or_short_videos():
    s = Store(":memory:")
    s.upsert([e("pexels", "1"), e("rumble", "2", seconds=45), e("rumble", "3", seconds=900), e("rumble", "4")])
    assert sorted(r["video_id"] for r in s.feed(shorts=True)) == ["1", "2"]


def test_status_and_prune():
    s = Store(":memory:")
    s.set_status("a", False, 0, "boom")
    s.set_status("a", True, 5, None)
    assert s.statuses()["a"]["last_ok"] == 1 and s.statuses()["a"]["last_error"] is None
    s.upsert([e("a", "1")])
    assert s.prune(days=30) == 0
    assert s.prune(days=-1) == 1


class FakeSite:
    topic_based = False
    description = ""

    def __init__(self, source_id, entries=None, fail=False):
        self.source_id, self.name, self.entries, self.fail = source_id, source_id.title(), entries or [], fail

    def latest(self, page=1, limit=20):
        if self.fail:
            raise RuntimeError("blocked by robots.txt")
        return [x for x in self.entries]

    def search(self, query, page=1, limit=20):
        return self.latest(page, limit)


def test_scrape_isolates_failing_sites_and_records_status():
    s = Store(":memory:")
    good, bad = FakeSite("good", [e("good", "1"), e("good", "2")]), FakeSite("bad", fail=True)
    summary = scrape_all(s, [good, bad], run=0)
    assert summary["good"]["count"] == 4 and summary["good"]["error"] is None      # 2 pages x 2 entries (duplicates upsert to 2 rows)
    assert "robots" in summary["bad"]["error"]
    assert s.total() == 2
    assert s.statuses()["bad"]["last_ok"] == 0 and s.statuses()["good"]["last_ok"] == 1


def test_topic_sites_rotate_their_pages():
    api, topic = FakeSite("api"), FakeSite("topic")
    topic.topic_based = True
    assert pages_for(api, 5) == [1, 2]
    assert pages_for(topic, 0) == [1, 2] and pages_for(topic, 1) == [3, 4]


def test_live_search_reports_failed_sites():
    lists, failed = search_live([FakeSite("ok", [e("ok", "1")]), FakeSite("bad", fail=True)], "cats", 1)
    assert [[x.video_id for x in l] for l in lists] == [["1"]]
    assert failed == ["Bad"]


def test_interleave_drops_duplicates():
    a = [e("a", "1"), e("a", "2"), e("a", "3")]
    b = [e("b", "1"), e("a", "1")]
    assert [(x.source_id, x.video_id) for x in interleave([a, b])] == [("a", "1"), ("b", "1"), ("a", "2"), ("a", "3")]


def test_rate_limiter_window():
    now = [0.0]
    limiter = SlidingWindowLimiter(2, 60.0, clock=lambda: now[0])
    assert limiter.allow("x") and limiter.allow("x") and not limiter.allow("x")
    assert limiter.allow("y")
    now[0] = 61.0
    assert limiter.allow("x")


def test_ttl_cache_expires_and_evicts():
    now = [0.0]
    c = TTLCache(ttl_seconds=10, max_entries=2, clock=lambda: now[0])
    c.set("a", 1)
    c.set("b", 2)
    c.set("c", 3)
    assert c.get("a") is None and c.get("b") == 2 and len(c) == 2
    now[0] = 11
    assert c.get("b") is None
