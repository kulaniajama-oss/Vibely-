"""Data shapes shared by every site extractor (the "Data Normalization" step of the roadmap)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Entry:
    """One video, normalised the same way no matter which website it came from."""

    source_id: str                 # "rumble", "pexels", ...
    source_name: str               # "Rumble", "Pexels", ...
    video_id: str                  # id used by that site's extractor (also by the Android app)
    title: str
    uploader: str
    thumbnail: Optional[str]
    page_url: str                  # the video's own page (never a stream link: those expire)
    duration_seconds: Optional[int] = None
    duration_text: Optional[str] = None
    published_date: Optional[str] = None   # ISO date (YYYY-MM-DD) when the site tells us


@dataclass
class StreamInfo:
    """What a site gave us to actually play a video. Fetched live, never stored (links expire)."""

    urls: List[str] = field(default_factory=list)   # direct .mp4 / .m3u8 / .webm links, best first
    embed_url: Optional[str] = None                   # the site's own web player (WebView fallback)
    media_type: str = "video"


def format_duration(seconds: Optional[int]) -> Optional[str]:
    """125 -> '2:05', 3725 -> '1:02:05', unknown/0 -> None."""
    if not seconds or seconds <= 0:
        return None
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
