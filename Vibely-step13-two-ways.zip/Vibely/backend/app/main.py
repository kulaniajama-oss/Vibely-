"""Vibely API: a polite multi-site video index with a live stream extractor.

* ``/api/videos``   newest videos from the catalogue (filled by the scheduled scrape)
* ``/api/search``   live search across the sites (+ catalogue), optionally one site only
* ``/api/stream``   fresh playable link for a video page (never stored: links expire)
* ``/api/sources``  the sites, with how many videos each has and whether the last scrape worked
"""
import asyncio
import logging
import os
import secrets
import threading
from contextlib import asynccontextmanager
from typing import List, Optional

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware

from app.cache import TTLCache
from app.db import Store
from app.jobs import interleave, scrape_all, search_live
from app.ratelimit import SlidingWindowLimiter
from app.schemas import MediaItem, SearchResponse, SourceInfo, StreamResponse
from app.scraping.models import Entry, format_duration
from app.scraping.sites import ALL_SITES, PER_PAGE, SITES_BY_ID
from app.scraping.stream import StreamError, resolve_stream

log = logging.getLogger("vibely.api")

DB_PATH = os.environ.get("DB_PATH", "data/vibely.db")
SCRAPE_INTERVAL_MINUTES = float(os.environ.get("SCRAPE_INTERVAL_MINUTES", "45"))   # 0 = no scheduled scrape
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")
RATE_LIMIT_PER_MINUTE = int(os.environ.get("RATE_LIMIT_PER_MINUTE", "90"))

store = Store(DB_PATH)
limiter = SlidingWindowLimiter(RATE_LIMIT_PER_MINUTE, 60.0)
stream_cache = TTLCache(ttl_seconds=900, max_entries=512)
search_cache = TTLCache(ttl_seconds=300, max_entries=256)
_scrape_lock = threading.Lock()


def run_scrape(run: int = 0) -> dict:
    """One scrape of every site. Only one runs at a time."""
    with _scrape_lock:
        return scrape_all(store, ALL_SITES, run)


async def _scrape_loop() -> None:
    run = 0
    while True:
        try:
            await asyncio.to_thread(run_scrape, run)
            await asyncio.to_thread(store.prune, 30)
        except Exception:
            log.exception("scheduled scrape failed")
        run += 1
        await asyncio.sleep(max(1.0, SCRAPE_INTERVAL_MINUTES * 60))


@asynccontextmanager
async def lifespan(_: FastAPI):
    task = asyncio.create_task(_scrape_loop()) if SCRAPE_INTERVAL_MINUTES > 0 else None
    yield
    if task:
        task.cancel()


app = FastAPI(
    title="Vibely API",
    version="1.0.0",
    description="Polite multi-site video index with a live stream extractor.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # the Android app does not need CORS; restrict this if you add a website.
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------------------------

def _client_key(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    return forwarded.split(",")[0].strip() or (request.client.host if request.client else "unknown")


def _limit(request: Request) -> None:
    if not limiter.allow(_client_key(request)):
        raise HTTPException(status_code=429, detail="Too many requests. Please wait a minute and try again.")


def _check_source(source: Optional[str]) -> None:
    if source and source not in SITES_BY_ID:
        raise HTTPException(status_code=400, detail=f"Unknown source '{source}'.")


def _from_entry(e: Entry) -> MediaItem:
    return MediaItem(
        id=e.video_id, title=e.title, uploader=e.uploader, thumbnail_url=e.thumbnail,
        duration=e.duration_text or format_duration(e.duration_seconds), source=e.source_name,
        source_id=e.source_id, media_type="video", page_url=e.page_url, source_name=e.source_name,
        published_date=e.published_date,
    )


def _from_row(r: dict) -> MediaItem:
    return MediaItem(
        id=r["video_id"], title=r["title"], uploader=r["uploader"] or r["source_name"], thumbnail_url=r["thumbnail"],
        duration=format_duration(r["duration_seconds"]), source=r["source_name"], source_id=r["source_id"],
        media_type="video", page_url=r["page_url"], source_name=r["source_name"], published_date=r["published_date"],
    )


def _message(count: int, failed: List[str], empty_text: str) -> str:
    text = f"{count} results." if count else empty_text
    if failed:
        text += " Unavailable right now: " + ", ".join(dict.fromkeys(failed)) + "."
    return text


def _ensure_seeded(source: Optional[str]) -> None:
    """A fresh server (free hosting wipes the disk on restart) has an empty catalogue: fill it once, right now."""
    empty = store.counts().get(source, 0) == 0 if source else store.total() == 0
    if not empty:
        return
    with _scrape_lock:
        still_empty = store.counts().get(source, 0) == 0 if source else store.total() == 0
        if still_empty:
            sites = [SITES_BY_ID[source]] if source else ALL_SITES
            scrape_all(store, sites, 0)


# ---------------------------------------------------------------------------------------------
# endpoints
# ---------------------------------------------------------------------------------------------

@app.get("/health")
def health():
    return {"status": "ok", "service": "vibely-api", "videos": store.total()}


@app.get("/api/sources", response_model=List[SourceInfo])
def sources():
    counts, statuses = store.counts(), store.statuses()
    return [
        SourceInfo(
            id=s.source_id, name=s.name, description=s.description, video_count=counts.get(s.source_id, 0),
            last_run=(statuses.get(s.source_id) or {}).get("last_run"),
            last_error=(statuses.get(s.source_id) or {}).get("last_error"),
        )
        for s in ALL_SITES
    ]


@app.get("/api/videos", response_model=SearchResponse)
@app.get("/api/featured", response_model=SearchResponse, include_in_schema=False)
def videos(request: Request, page: int = Query(1, ge=1, le=100), source: Optional[str] = Query(None, max_length=30)):
    _limit(request)
    _check_source(source)
    _ensure_seeded(source)
    rows = store.feed(PER_PAGE, (page - 1) * PER_PAGE, source)
    items = [_from_row(r) for r in rows]
    return SearchResponse(query="", items=items, page=page, has_more=len(rows) == PER_PAGE,
                          message=_message(len(items), [], "Nothing to show yet. The first scrape may still be running."))


@app.get("/api/shorts", response_model=SearchResponse)
def shorts(request: Request):
    _limit(request)
    _ensure_seeded(None)
    items = [_from_row(r) for r in store.feed(30, 0, shorts=True)]
    return SearchResponse(query="", items=items, page=1, has_more=False, message=_message(len(items), [], "No short clips yet."))


@app.get("/api/search", response_model=SearchResponse)
def search(request: Request, q: str = Query(min_length=1, max_length=160), page: int = Query(1, ge=1, le=50),
           source: Optional[str] = Query(None, max_length=30)):
    _limit(request)
    _check_source(source)
    query = q.strip()
    cache_key = (query.lower(), page, source or "")
    cached = search_cache.get(cache_key)
    if cached is not None:
        return cached

    sites = [SITES_BY_ID[source]] if source else ALL_SITES
    live_lists, failed = search_live(sites, query, page)
    live = interleave(live_lists)
    store.upsert(live)                                   # what people look for also feeds the catalogue
    seen = {(e.source_id, e.video_id) for e in live}
    items = [_from_entry(e) for e in live]
    for row in store.search(query, PER_PAGE, (page - 1) * PER_PAGE, source):
        if (row["source_id"], row["video_id"]) not in seen:
            items.append(_from_row(row))
    response = SearchResponse(query=query, items=items, page=page, has_more=len(items) >= PER_PAGE,
                              message=_message(len(items), failed, "No results found."))
    if items:
        search_cache.set(cache_key, response)
    return response


@app.get("/api/stream", response_model=StreamResponse)
def stream(request: Request, url: str = Query(min_length=8, max_length=2048)):
    _limit(request)
    cached = stream_cache.get(url)
    if cached is not None:
        return cached
    try:
        result = resolve_stream(url)
    except StreamError as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))
    response = StreamResponse(**result)
    stream_cache.set(url, response)
    return response


@app.post("/api/admin/scrape")
def admin_scrape(x_admin_token: str = Header(default="")):
    """Lets an outside timer (for example a GitHub Actions schedule) trigger a scrape while a free server sleeps."""
    if not ADMIN_TOKEN:
        raise HTTPException(status_code=404, detail="Not enabled.")
    if not secrets.compare_digest(x_admin_token, ADMIN_TOKEN):
        raise HTTPException(status_code=403, detail="Wrong token.")
    return {"status": "done", "sources": run_scrape(int.from_bytes(os.urandom(2), "big") % 1000)}
