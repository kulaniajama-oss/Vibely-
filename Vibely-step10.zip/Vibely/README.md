# Vibely

Vibely is an Android media-discovery starter project with a Kotlin/Jetpack Compose client,
a FastAPI backend, and a modular source-plugin architecture.

## What works in this starter

- Android app shell with Home, Shorts, Library and Settings tabs.
- Compact search UI connected to the backend endpoint.
- Shorts discovery screen layout with like, comment and share affordances.
- Library shortcuts for History, Downloads, Playlists, Liked videos and Saved.
- Settings sections for account, appearance, language, playback, privacy and sources.
- FastAPI health, source-list, search and allowlisted page-metadata endpoints.
- **Step 1 (done): real source — Internet Archive.** Search and a Featured feed return real
  openly accessible videos/audio with thumbnails; `/api/resolve` returns a direct playable file URL.
- **Step 2 (done): in-app player.** Tapping a card opens a Media3/ExoPlayer screen with controls,
  loading and retry states, audio artwork, and a link to the original page.
- **Step 3 (done): local library.** History, Liked, Saved and Playlists are stored on the device
  with Room and shown in the Library tab. The player has Like / Save / Playlist buttons.
- **Step 4 (done): accounts + cloud sync.** Settings → Account: sign in / create account / reset password,
  Sync now, sign out. Library syncs through Firestore when `google-services.json` is provided.
- **Step 5 (done): background playback.** Playback runs in a Media3 `MediaSessionService`, so audio/video
  keeps going when you press Home or lock the screen, with a media notification and headset controls.
  Back closes the player and stops playback. Settings → Playback has a "background play" switch.
- **Step 6 (done): paging, caching, accessibility, tests.** Home scrolls endlessly ("Load more" + automatic
  next page), the Music / Technology / Education chips now run real searches, results are cached
  (backend 5 min / app 5 min, and the last results stay readable offline), screen-reader labels were added,
  and there are Python (15) and Android (7) unit tests that run in GitHub Actions.
- **Step 7 (done): signed release builds.** A separate GitHub Actions workflow builds a signed
  `app-release.apk` (install on phones) and `app-release.aab` (Google Play), verifies the signature,
  and can attach both to a GitHub Release. The app now has a launcher icon and shows its version in Settings.
- **Guest mode.** Nobody has to sign in to use Vibely: anyone can search and watch videos. Liking, saving,
  playlists, comments, downloads and the personal library (history, liked, saved, playlists) need an account;
  guests see a "Sign in required" prompt, and after signing in they return to what they were doing.
  (Downloads need an account. Comments are Internet Archive viewer reviews: everyone can read them, and writing happens on archive.org.)
- **Step 9 (done): no more demo content, videos play out of the box.** The app calls the public Internet Archive
  API directly from the phone, so Home, search, Shorts and the player show and play **real** videos even when no
  Render backend is configured (the old placeholder backend URL used to leave the app in demo mode, where nothing
  could play). If a backend URL *is* configured it is tried first and the direct API is the automatic fallback.
  The player now tries up to four candidate files per item (a file the device cannot decode is skipped, Ogg Theora
  is no longer chosen), Retry really re-loads the video after an error, and errors are explained in plain words.
  The **Shorts** tab is a real vertical feed of short clips with inline playback (tap to pause, swipe for the next),
  a working Like (account needed) and a working Share.
- **Step 10 (done): everything the app shows comes from Internet Archive.**
  - **Categories:** the Home chips are now All, Movies, Music, Kids, News, Technology, Education, Sports and
    Radio & podcasts (scrollable). Each one browses real Internet Archive collections with paging and caching.
  - **Video details:** the player shows the description, date, license and topics of the item.
  - **Comments:** viewer reviews written on archive.org are shown under the video (with stars and date).
    Writing a review opens archive.org, because it needs an Internet Archive account.
  - **More like this:** related videos/audio (same topics, else same collection) under every item; tap to switch.
  - **Downloads:** *Download* in the player saves the file to the phone with Android's DownloadManager
    (progress notification, resumes after a lost connection). Library → Downloads lists them with progress,
    plays them with no internet, and deletes them. Downloads need an account (guest rule).
  - **Audio:** Music, Audiobooks, Podcasts, Old radio and Live concerts are Home categories. Albums, audiobooks
    and concerts play as a queue (one MP3 per track, in track order) with a track list under the player; tap a
    track to jump to it. Playback continues in the background with notification controls. A broken track is skipped.
    Offline download currently covers single videos/recordings, not whole albums.
  - These new features call the public Internet Archive API directly from the phone, so no Render backend is needed.
- Plugin interface with Internet Archive (live, the only content source) and a demo plugin (off by default; set `ENABLE_DEMO=true`).
- Backend unit tests (`backend/tests`) run in GitHub Actions.
- GitHub Actions workflow that builds and uploads a debug APK.
- Render Docker deployment configuration.
- Firebase Firestore security rules template.

## Important source integration boundary

Vibely gets its content from the Internet Archive's public API. If you add another source later, connect it only through
authorized APIs, feeds, embeds, or other methods permitted by that service. This project does not
bypass login, DRM, signatures, rate limits, or other access controls. The generic metadata endpoint
only fetches HTTPS pages on domains explicitly listed in `ALLOWED_METADATA_DOMAINS`.

## Build APK on GitHub

1. Create a GitHub repository named `Vibely`.
2. Upload/push the contents of this folder to the repository root.
3. Open **Actions** and run **Vibely Android APK**, or push to `main`.
4. When the workflow finishes, open its run and download the `Vibely-debug-apk` artifact.

The workflow uses Gradle 8.9 and JDK 17. Android Gradle Plugin 8.7.3 is configured in the root
Gradle build.

## Connect Render

1. Create a Render Web Service from this repository.
2. Set the root directory to `backend` (or use the included `render.yaml` blueprint).
3. Deploy the Docker service.
4. Set `ALLOWED_METADATA_DOMAINS` to a comma-separated allowlist of domains you are permitted
   to fetch metadata from.
5. Copy the service URL.
6. *(Optional — the app works without a backend.)* In `app/build.gradle.kts`, replace `https://YOUR-RENDER-SERVICE.onrender.com` in
   `BACKEND_BASE_URL` with your Render URL.
7. Push the change to GitHub to rebuild the APK.

## Connect Firebase (optional — enables account + cloud sync)

Accounts need Firebase: **without it nobody can sign in, so everyone stays a guest who can only watch videos.** To turn on accounts, the library and sync:

1. In the [Firebase console](https://console.firebase.google.com) create a project.
2. Add an **Android app** with package name `com.vibely.app` (the app id changed when EbisaTube was renamed
   to Vibely — an Android app registered with the old `com.ebisa.tube` name will not work) and download
   `google-services.json`.
3. **Authentication → Sign-in method →** enable **Email/Password**.
4. **Firestore Database → Create database.** Open the **Rules** tab, paste the contents of
   `firebase/firestore.rules`, and **Publish**.
5. In your GitHub repo: **Settings → Secrets and variables → Actions → New repository secret**.
   Name: `GOOGLE_SERVICES_JSON`, value: the full contents of `google-services.json`.
6. Re-run the **Vibely Android APK** workflow and install the new APK.
7. In the app: **Settings → Account → Create account**. Your library syncs automatically.

For a local build, put `google-services.json` in `app/` (it is git-ignored). Never commit it or any
service-account private key.

How sync works: Room on the device is the source of truth. While signed in, every change is also written to
`users/{uid}/…` in Firestore, and **Sync now** (also run on sign-in and app start) merges the cloud library
with the device. Items removed while offline can reappear after the next sync. Signing in with a *different*
account clears the previous account's local library first, so data is never copied between accounts.

## Signed release build

The debug APK from **Vibely Android APK** is for testing. For a version you can share or publish, build a
**signed** one. You only create the signing key once.

**1. Create the signing key (on your own device).** Needs a JDK (`pkg install openjdk-17` in Termux):

```
bash tools/make-keystore.sh
```

It asks for a password and a few details, then writes `vibely-release.jks` and
`vibely-release.jks.base64.txt`. **Back up `vibely-release.jks` and the password somewhere safe.** If you lose
either, you can never ship an update to people who installed a signed Vibely. Never commit or share them
(both file types are git-ignored).

**2. Add them to GitHub.** Repo → **Settings → Secrets and variables → Actions**.

*Secrets* tab:

| Name | Value |
| --- | --- |
| `KEYSTORE_BASE64` | full contents of `vibely-release.jks.base64.txt` |
| `KEYSTORE_PASSWORD` | the password you chose |
| `KEY_ALIAS` | `vibely` |
| `KEY_PASSWORD` | the same password again |

*Variables* tab: `VIBELY_BACKEND_URL` = your Render URL, e.g. `https://vibely-api.onrender.com`
(optional: without it the app talks to the Internet Archive directly). The debug workflow uses this variable too.

**3. Build.** **Actions → Vibely Release (signed) → Run workflow.** When it finishes, download
`Vibely-release-apk` (install on phones) and `Vibely-release-aab` (upload to Google Play). Pushing a tag such
as `v0.8.0` also attaches both files to a GitHub Release.

Things to know:

- A signed build has a different signature than debug builds, so Android will not install it over a debug
  install of the same app. **Uninstall the debug Vibely first** (local history/playlists on that install are
  lost unless you signed in and synced).
- Each run raises the version code automatically, so later releases can update earlier ones.
- Local signing is also possible: put `storeFile`, `storePassword`, `keyAlias`, `keyPassword` in a git-ignored
  `keystore.properties` in the project root and run `gradle :app:assembleRelease`.
- Email/password sign-in needs no key fingerprints. The workflow prints the SHA-1/SHA-256 of your key (public
  information) in case you add Google sign-in later.
- Code shrinking (R8) is off on purpose until it has been tested on a real device.

## Roadmap

- [x] Step 1: real authorized source adapter (Internet Archive) + thumbnails + featured feed.
- [x] Step 2: Media3 player screen (tap a card to play video/audio; uses `/api/resolve`).
- [x] Step 3: Room persistence for history, liked, saved and playlists.
- [x] Step 4: Firebase Auth (email/password) and per-user Firestore sync.
- [x] Step 5: background playback (MediaSession service, notification controls).
- [x] Step 6: paging ("load more"), caching, accessibility labels, more tests.
- [x] Step 7: signed release APK/AAB via GitHub Actions secrets.
- [x] Step 8: guest mode (watch without an account).
- [x] Step 9: real API everywhere (no demo content), reliable playback, real Shorts feed.
- [x] Step 10: categories, video details, comments (IA reviews), related videos, offline downloads.

Original milestone notes:

- Add a real authorized source adapter for each additional service.
- Add local Room persistence for history, favorites and playlists.
- Add Firebase Auth and per-user Firestore synchronization.
- Add Media3 player screen and MediaSession background playback.
- Add image loading, paging, caching, accessibility and automated tests.
- Configure a signed release APK using GitHub Actions secrets.

## License

Choose and add a project license before distributing. If you reuse NewPipe code, comply with its
GPL-3.0 license and all applicable attribution/source-distribution requirements.
