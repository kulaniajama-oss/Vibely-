package com.vibely.app

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import android.widget.Toast
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.vibely.app.data.DownloadsRepository
import com.vibely.app.data.IaReview
import com.vibely.app.data.ItemDetails
import com.vibely.app.data.VibelyRepository
import com.vibely.app.data.LibraryRepository
import com.vibely.app.data.MediaTrack
import com.vibely.app.data.formatRuntime
import com.vibely.app.data.ResolvedMedia
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import androidx.media3.common.MediaItem as ExoMediaItem

/**
 * Full-screen player UI. Playback itself runs in [PlaybackService] (so it can continue in the background);
 * this screen resolves a playable URL for [item] and controls the service through a MediaController.
 */
@Composable
fun PlayerScreen(
    item: MediaItem,
    library: LibraryRepository,
    backgroundPlay: Boolean,
    signedIn: Boolean,
    onRequireSignIn: () -> Unit,
    onPlayRelated: (MediaItem) -> Unit,
    onClose: () -> Unit
) {
    var attempt by remember(item.id) { mutableIntStateOf(0) }
    val scrollState = rememberScrollState()
    var details by remember(item.key) { mutableStateOf<ItemDetails?>(null) }
    var related by remember(item.key) { mutableStateOf<List<MediaItem>>(emptyList()) }
    var resolved by remember(item.id) { mutableStateOf<ResolvedMedia?>(null) }
    var error by remember(item.id) { mutableStateOf<String?>(null) }
    var urlIndex by remember(item.id) { mutableIntStateOf(0) } // which candidate file is being tried
    val uriHandler = LocalUriHandler.current
    val controller = rememberMediaController()
    val context = LocalContext.current

    // Android 13+: the playback notification needs the notification permission.
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && backgroundPlay &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Leaving the player with Back ends playback; pressing Home keeps it going (if background play is on).
    val close: () -> Unit = {
        controller?.let {
            it.stop()
            it.clearMediaItems()
        }
        onClose()
    }

    LaunchedEffect(item.id, attempt) {
        resolved = null
        error = null
        urlIndex = 0
        try {
            resolved = VibelyRepository.resolve(item, fresh = attempt > 0)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "Could not load this item."
        }
    }

    // Description, topics, viewer comments and related videos come from Internet Archive too.
    // If they cannot be loaded (offline, downloaded file), the player just shows less.
    LaunchedEffect(item.key) {
        scrollState.scrollTo(0)
        details = VibelyRepository.details(item)
        details?.let { related = VibelyRepository.related(item, it) }
    }

    // Guests only watch; history is part of the signed-in library.
    LaunchedEffect(resolved, signedIn) {
        if (resolved != null && signedIn) library.recordWatched(item)
    }

    // A file the device cannot play is not the end: try the next candidate, and only then show the error.
    val onPlaybackError: (String) -> Unit = { message ->
        val current = resolved
        // A queue (album/audiobook) skips a broken track itself; trying other formats only makes sense for single files.
        if (current != null && current.tracks.isEmpty() && urlIndex + 1 < current.urls.size) urlIndex += 1 else error = message
    }

    BackHandler(onBack = close)

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = close) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }
            Text("Now playing", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        }

        Column(Modifier.weight(1f).verticalScroll(scrollState)) {
            val media = resolved
            val failure = error
            when {
                failure != null -> StatusBox {
                    Text(failure, color = Color.White, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { attempt++ },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) { Text("Retry") }
                }
                media == null -> StatusBox {
                    CircularProgressIndicator(color = Accent)
                    Spacer(Modifier.height(12.dp))
                    Text("Preparing playback…", color = Color.LightGray, fontSize = 13.sp)
                }
                media.type == "audio" -> {
                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(SurfaceDark)) {
                        if (item.thumbnailUrl != null) {
                            AsyncImage(
                                model = item.thumbnailUrl,
                                contentDescription = item.title,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    MediaPlayerView(
                        url = if (media.tracks.isNotEmpty()) media.tracks.first().url
                        else media.urls.getOrElse(urlIndex) { media.urls.first() },
                        item = item,
                        isAudio = true,
                        controller = controller,
                        backgroundPlay = backgroundPlay,
                        onError = onPlaybackError,
                        modifier = Modifier.fillMaxWidth().height(110.dp),
                        tracks = media.tracks
                    )
                    if (media.tracks.isNotEmpty()) TrackList(media.tracks, controller)
                }
                else -> MediaPlayerView(
                    url = media.urls.getOrElse(urlIndex) { media.urls.first() },
                    item = item,
                    isAudio = false,
                    controller = controller,
                    backgroundPlay = backgroundPlay,
                    onError = onPlaybackError,
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black)
                )
            }

            Column(Modifier.padding(16.dp)) {
                Text(item.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("${item.uploader} • ${item.source}", color = Color.Gray, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                ActionRow(item, library, signedIn, onRequireSignIn, resolved)
                details?.let { info ->
                    val facts = listOf(info.date, info.license).filter { it.isNotBlank() }.joinToString(" • ")
                    if (facts.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(facts, color = Color.Gray, fontSize = 12.sp)
                    }
                    DescriptionBlock(info.description)
                    if (info.subjects.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Topics: " + info.subjects.take(6).joinToString(", "),
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                if (!item.pageUrl.isNullOrBlank()) {
                    Spacer(Modifier.height(16.dp))
                    OutlinedButton(onClick = { uriHandler.openUri(item.pageUrl) }) {
                        Text("Open original page", color = Color.White)
                    }
                }
                details?.let { info ->
                    CommentsSection(info.reviews, item.pageUrl) { url -> uriHandler.openUri(url) }
                }
            }

            if (related.isNotEmpty()) {
                Text(
                    "More like this",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 4.dp)
                )
                related.forEach { other ->
                    CompactRow(other, onClick = { onPlayRelated(other) })
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun StatusBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(SurfaceDark).padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}

/** Connects to [PlaybackService]; returns null until the connection is ready. */
@Composable
private fun rememberMediaController(): MediaController? {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            { controller = runCatching { future.get() }.getOrNull() },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            controller = null
            MediaController.releaseFuture(future)
        }
    }
    return controller
}

@Composable
private fun MediaPlayerView(
    url: String,
    item: MediaItem,
    isAudio: Boolean,
    controller: MediaController?,
    backgroundPlay: Boolean,
    onError: (String) -> Unit,
    modifier: Modifier = Modifier,
    tracks: List<MediaTrack> = emptyList()
) {
    if (controller == null) {
        Box(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Accent)
        }
        return
    }

    // Hand the media to the service, unless it is already loaded and healthy (e.g. coming back to the app).
    // An IDLE player means the last attempt failed or was stopped, so Retry must load and prepare it again.
    LaunchedEffect(controller, url, tracks) {
        if (tracks.size > 1) {
            val needsLoad = controller.mediaItemCount != tracks.size ||
                controller.getMediaItemAt(0).mediaId != tracks.first().url ||
                controller.playbackState == Player.STATE_IDLE
            if (needsLoad) {
                controller.setMediaItems(
                    tracks.map { t ->
                        ExoMediaItem.Builder()
                            .setMediaId(t.url)
                            .setUri(t.url)
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(t.title)
                                    .setArtist(item.uploader)
                                    .setAlbumTitle(item.title)
                                    .setArtworkUri(item.thumbnailUrl?.let { Uri.parse(it) })
                                    .build()
                            )
                            .build()
                    }
                )
                controller.prepare()
            }
        } else if (controller.currentMediaItem?.mediaId != url || controller.playbackState == Player.STATE_IDLE) {
            controller.setMediaItem(
                ExoMediaItem.Builder()
                    .setMediaId(url)
                    .setUri(url)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(item.title)
                            .setArtist(item.uploader)
                            .setArtworkUri(item.thumbnailUrl?.let { Uri.parse(it) })
                            .build()
                    )
                    .build()
            )
            controller.prepare()
        }
        controller.playWhenReady = true
    }

    val latestOnError by rememberUpdatedState(onError)
    val latestTracks by rememberUpdatedState(tracks)
    DisposableEffect(controller) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // In an album one broken file should not stop the music: move on to the next track.
                if (latestTracks.size > 1 && controller.hasNextMediaItem()) {
                    controller.seekToNextMediaItem()
                    controller.prepare()
                    controller.play()
                } else {
                    latestOnError(friendlyPlaybackError(error))
                }
            }
        }
        controller.addListener(listener)
        onDispose { controller.removeListener(listener) }
    }

    // With background play off, pause when the app is no longer visible.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, controller, backgroundPlay) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && !backgroundPlay) controller.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = controller
                useController = true
                if (isAudio) {
                    controllerShowTimeoutMs = 0
                    controllerHideOnTouch = false
                    showController()
                }
            }
        },
        update = { it.player = controller },
        onRelease = { it.player = null }
    )
}

@Composable
private fun ActionRow(
    item: MediaItem,
    library: LibraryRepository,
    signedIn: Boolean,
    onRequireSignIn: () -> Unit,
    resolved: ResolvedMedia?
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    // A finished download is played from the device, so there is nothing to download again.
    val isLocalFile = item.mediaUrl?.startsWith("file:") == true
    var downloaded by remember(item.key) { mutableStateOf(false) }
    LaunchedEffect(item.key, signedIn) {
        if (signedIn && !isLocalFile) downloaded = DownloadsRepository.has(context, item)
    }
    val liked by remember(item.key) { library.isLiked(item) }.collectAsStateWithLifecycle(initialValue = false)
    val saved by remember(item.key) { library.isSaved(item) }.collectAsStateWithLifecycle(initialValue = false)
    var showPlaylists by remember { mutableStateOf(false) }
    var promptFor by remember { mutableStateOf<String?>(null) } // what a guest tried to do

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ActionChip(
            icon = when {
                !signedIn -> Icons.Default.Lock
                liked -> Icons.Default.Favorite
                else -> Icons.Default.FavoriteBorder
            },
            label = if (signedIn && liked) "Liked" else "Like",
            active = signedIn && liked
        ) {
            if (signedIn) {
                scope.launch { library.setLiked(item, !liked) }
            } else {
                promptFor = "like videos"
            }
        }
        ActionChip(
            icon = when {
                !signedIn -> Icons.Default.Lock
                saved -> Icons.Default.Bookmark
                else -> Icons.Default.BookmarkBorder
            },
            label = if (signedIn && saved) "Saved" else "Save",
            active = signedIn && saved
        ) {
            if (signedIn) {
                scope.launch { library.setSaved(item, !saved) }
            } else {
                promptFor = "save videos"
            }
        }
        ActionChip(
            icon = if (signedIn) Icons.Default.PlaylistAdd else Icons.Default.Lock,
            label = "Playlist",
            active = false
        ) {
            if (signedIn) {
                showPlaylists = true
            } else {
                promptFor = "add videos to playlists"
            }
        }
    }

    // Albums are many files; offline download covers single videos and recordings for now.
    val multiTrack = (resolved?.tracks?.size ?: 0) > 1
    if (!isLocalFile && !multiTrack) {
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionChip(
                icon = when {
                    !signedIn -> Icons.Default.Lock
                    downloaded -> Icons.Default.DownloadDone
                    else -> Icons.Default.Download
                },
                label = if (signedIn && downloaded) "Downloaded" else "Download",
                active = signedIn && downloaded
            ) {
                val media = resolved
                when {
                    !signedIn -> {
                        promptFor = "download videos"
                    }
                    downloaded -> {
                        Toast.makeText(context, "Find it in Library → Downloads.", Toast.LENGTH_SHORT).show()
                    }
                    media == null -> {
                        Toast.makeText(context, "Still preparing — try again in a moment.", Toast.LENGTH_SHORT).show()
                    }
                    else -> {
                        scope.launch {
                            try {
                                DownloadsRepository.start(context, item, media)
                                downloaded = true
                                Toast.makeText(context, "Download started. See Library → Downloads.", Toast.LENGTH_LONG).show()
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Toast.makeText(context, e.message ?: "Download failed.", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPlaylists && signedIn) {
        AddToPlaylistDialog(item, library) { showPlaylists = false }
    }
    promptFor?.let { action ->
        SignInPromptDialog(
            action = action,
            onSignIn = {
                promptFor = null
                onRequireSignIn()
            },
            onDismiss = { promptFor = null }
        )
    }
}

@Composable
private fun ActionChip(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(label) },
        leadingIcon = { Icon(icon, null, modifier = Modifier.size(18.dp)) },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = if (active) Color(0xFF392126) else SurfaceDark,
            labelColor = Color.White,
            leadingIconContentColor = if (active) Accent else Color.White
        ),
        border = null
    )
}

@Composable
private fun AddToPlaylistDialog(item: MediaItem, library: LibraryRepository, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val playlists by remember { library.playlists() }
        .collectAsStateWithLifecycle(emptyList<com.vibely.app.data.db.PlaylistSummary>())
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        NameDialog(
            title = "New playlist",
            confirmLabel = "Create & add",
            onConfirm = { name ->
                scope.launch {
                    val id = library.createPlaylist(name)
                    if (id != null) {
                        library.addToPlaylist(id, item)
                        Toast.makeText(context, "Added to ${name.trim()}", Toast.LENGTH_SHORT).show()
                    }
                }
                onDismiss()
            },
            onDismiss = { creating = false }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                if (playlists.isEmpty()) {
                    Text("You have no playlists yet.")
                }
                playlists.forEach { p ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    library.addToPlaylist(p.id, item)
                                    Toast.makeText(context, "Added to ${p.name}", Toast.LENGTH_SHORT).show()
                                }
                                onDismiss()
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(p.name, modifier = Modifier.weight(1f), maxLines = 1)
                        Text(if (p.itemCount == 1) "1 item" else "${p.itemCount} items", fontSize = 12.sp, color = Color.Gray)
                    }
                    HorizontalDivider()
                }
            }
        },
        confirmButton = { TextButton(onClick = { creating = true }) { Text("New playlist", color = Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

/** Turns a Media3 error into something a person can act on. */
private fun friendlyPlaybackError(error: PlaybackException): String = when (error.errorCode) {
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
        "Network problem while loading the video. Check your connection and tap Retry."
    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
        "The server did not return this video (HTTP error). Tap Retry or open the original page."
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
    PlaybackException.ERROR_CODE_DECODING_FAILED,
    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
        "This video format can't be played on this device. You can open the original page instead."
    else -> "Playback failed: ${error.errorCodeName}"
}

@Composable
private fun DescriptionBlock(text: String) {
    if (text.isBlank()) return
    var expanded by remember(text) { mutableStateOf(false) }
    Spacer(Modifier.height(12.dp))
    Text(
        text,
        color = Color.LightGray,
        fontSize = 14.sp,
        maxLines = if (expanded) Int.MAX_VALUE else 4,
        overflow = TextOverflow.Ellipsis
    )
    if (text.length > 200 || text.count { it == '\n' } >= 3) {
        TextButton(onClick = { expanded = !expanded }, contentPadding = PaddingValues(0.dp)) {
            Text(if (expanded) "Show less" else "Show more", color = Accent)
        }
    }
}

/** Viewer reviews from archive.org, shown as comments. Writing one needs an Internet Archive account, so it opens the site. */
@Composable
private fun CommentsSection(reviews: List<IaReview>, pageUrl: String?, openUrl: (String) -> Unit) {
    var showAll by remember(reviews) { mutableStateOf(false) }
    val shown = if (showAll) reviews else reviews.take(3)

    Spacer(Modifier.height(24.dp))
    Text(
        if (reviews.isEmpty()) "Comments" else "Comments (${reviews.size})",
        color = Color.White,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold
    )
    Text("Reviews written by viewers on Internet Archive", color = Color.Gray, fontSize = 12.sp)
    Spacer(Modifier.height(8.dp))
    if (reviews.isEmpty()) {
        Text("No comments yet.", color = Color.LightGray, fontSize = 14.sp)
    }
    shown.forEach { review ->
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    review.author,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (review.date.isNotBlank()) {
                    Text("  •  ${review.date}", color = Color.Gray, fontSize = 12.sp)
                }
            }
            if (review.stars > 0) {
                Text("★".repeat(review.stars) + "☆".repeat(5 - review.stars), color = Accent, fontSize = 13.sp)
            }
            if (review.title.isNotBlank()) {
                Text(review.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
            Text(review.body, color = Color.LightGray, fontSize = 14.sp, maxLines = 12, overflow = TextOverflow.Ellipsis)
        }
        HorizontalDivider(color = Color(0xFF303137))
    }
    if (reviews.size > 3) {
        TextButton(onClick = { showAll = !showAll }) {
            Text(if (showAll) "Show fewer" else "Show all ${reviews.size} comments", color = Accent)
        }
    }
    if (!pageUrl.isNullOrBlank()) {
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { openUrl(pageUrl) }) {
            Text("Write a review on Internet Archive", color = Color.White)
        }
    }
}

/** Track list of an album / audiobook / concert: tap a track to jump to it; the playing one is highlighted. */
@Composable
private fun TrackList(tracks: List<MediaTrack>, controller: MediaController?) {
    var current by remember { mutableIntStateOf(controller?.currentMediaItemIndex ?: 0) }
    DisposableEffect(controller) {
        if (controller == null) return@DisposableEffect onDispose { }
        current = controller.currentMediaItemIndex
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: ExoMediaItem?, reason: Int) {
                current = controller.currentMediaItemIndex
            }
        }
        controller.addListener(listener)
        onDispose { controller.removeListener(listener) }
    }
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Text(
            "Tracks (${tracks.size})",
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        tracks.forEachIndexed { index, track ->
            val playing = index == current
            Row(
                Modifier.fillMaxWidth()
                    .clickable(onClickLabel = "Play ${track.title}") {
                        controller?.seekTo(index, 0L)
                        controller?.play()
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${index + 1}",
                    color = if (playing) Accent else Color.Gray,
                    fontSize = 13.sp,
                    modifier = Modifier.width(32.dp)
                )
                Text(
                    track.title,
                    color = if (playing) Accent else Color.White,
                    fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal,
                    fontSize = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                formatRuntime(track.seconds?.toString())?.let {
                    Text(it, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
    }
}
