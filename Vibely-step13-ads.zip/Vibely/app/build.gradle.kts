import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

// Firebase is optional: the Google Services plugin is applied only when google-services.json exists
// (locally, or written from the GOOGLE_SERVICES_JSON GitHub secret during CI).
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

// ---- Build-time configuration (all optional; CI passes these as environment variables) ----

fun envOrProp(name: String): String? =
    System.getenv(name)?.takeIf { it.isNotBlank() }
        ?: providers.gradleProperty(name).orNull?.takeIf { it.isNotBlank() }

// Backend URL: set VIBELY_BACKEND_URL (CI variable) or edit the fallback below.
val backendUrl = envOrProp("VIBELY_BACKEND_URL") ?: "https://YOUR-RENDER-SERVICE.onrender.com"

// Optional free keys for extra video sources (a source without its key is simply skipped).
val pexelsKey = envOrProp("PEXELS_API_KEY") ?: ""
val pixabayKey = envOrProp("PIXABAY_API_KEY") ?: ""
val vimeoToken = envOrProp("VIMEO_ACCESS_TOKEN") ?: ""

// ---- Start.io ads ----
// App ID from the Start.io portal (override with START_IO_APP_ID if you ever create a new app entry).
val startioAppId = envOrProp("START_IO_APP_ID") ?: "210557168"
// Kill switch: set VIBELY_ADS_ENABLED=false to build without showing any ads.
val adsEnabled = envOrProp("VIBELY_ADS_ENABLED") != "false"
// Test ads are always on in debug builds. For a release/CI build set VIBELY_TEST_ADS=true to keep test ads
// until you have verified everything (never tap your own live ads: Start.io can ban the account for it).
val releaseTestAds = envOrProp("VIBELY_TEST_ADS") == "true"

// Release signing: from environment variables (CI) or a local, git-ignored keystore.properties file.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun signingValue(envName: String, propName: String): String? =
    System.getenv(envName)?.takeIf { it.isNotBlank() }
        ?: keystoreProps.getProperty(propName)?.takeIf { it.isNotBlank() }

val releaseStoreFile = signingValue("VIBELY_KEYSTORE_FILE", "storeFile")
val releaseStorePassword = signingValue("VIBELY_KEYSTORE_PASSWORD", "storePassword")
val releaseKeyAlias = signingValue("VIBELY_KEY_ALIAS", "keyAlias")
val releaseKeyPassword = signingValue("VIBELY_KEY_PASSWORD", "keyPassword")
val hasReleaseSigning = listOf(releaseStoreFile, releaseStorePassword, releaseKeyAlias, releaseKeyPassword)
    .all { it != null }

android {
    namespace = "com.vibely.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vibely.app"
        minSdk = 23
        targetSdk = 35
        // CI passes a rising VIBELY_VERSION_CODE so every release can update the previous one.
        versionCode = envOrProp("VIBELY_VERSION_CODE")?.toIntOrNull() ?: 12
        versionName = "0.12.0"

        buildConfigField("String", "BACKEND_BASE_URL", "\"$backendUrl\"")
        buildConfigField("String", "PEXELS_API_KEY", "\"$pexelsKey\"")
        buildConfigField("String", "PIXABAY_API_KEY", "\"$pixabayKey\"")
        buildConfigField("String", "VIMEO_ACCESS_TOKEN", "\"$vimeoToken\"")
        buildConfigField("boolean", "ADS_ENABLED", "$adsEnabled")
        manifestPlaceholders["startioAppId"] = startioAppId
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseStoreFile!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            buildConfigField("boolean", "ADS_TEST_MODE", "true")
        }
        release {
            buildConfigField("boolean", "ADS_TEST_MODE", "$releaseTestAds")
            // Start.io keep rules (only used if R8/ProGuard is switched on below).
            proguardFiles("proguard-rules.pro")
            // Without signing details this produces an *unsigned* APK, which cannot be installed.
            if (hasReleaseSigning) signingConfig = signingConfigs.getByName("release")
            // R8 shrinking is intentionally off for now: it needs on-device testing of Room,
            // Firebase and Media3 before it is safe to enable.
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("org.jsoup:jsoup:1.18.1") // reads web pages for the scraped sources

    // Local database (history, likes, saved, playlists)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1") // PeerTube streams
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")

    // Firebase is optional until google-services.json is added (Auth: email/password, Firestore: library sync).
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")

    // Start.io (formerly StartApp) In-App Ads SDK. Resolved from mavenCentral(), which settings.gradle.kts already has.
    // noinspection GradleDynamicVersion
    implementation("com.startapp:inapp-sdk:5.+")

    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303") // real org.json so JSON parsers can be tested on the JVM
}
