# Start.io (StartApp) In-App Ads SDK — official keep rules.
# R8 is currently off (isMinifyEnabled = false), so these only matter once shrinking is enabled.
-keep class com.startapp.** {
    *;
}
-keep class com.truenet.** {
    *;
}
-keepattributes Exceptions, InnerClasses, Signature, Deprecated, SourceFile, LineNumberTable, *Annotation*, EnclosingMethod
-dontwarn android.webkit.JavascriptInterface
-dontwarn com.startapp.**
-dontwarn org.jetbrains.annotations.**
