package com.vibely.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FeedAdsTest {
    private fun videos(n: Int) = (1..n).map { MediaItem(id = "v$it", title = "t$it", uploader = "u", sourceId = "s") }

    @Test
    fun noAdsWhenDisabled() {
        val feed = buildFeed(videos(20), withAds = false)
        assertEquals(20, feed.size)
        assertTrue(feed.all { it is FeedEntry.Video })
    }

    @Test
    fun firstAdAfterThirdVideoThenEverySixth() {
        val feed = buildFeed(videos(10), withAds = true)
        val adPositions = feed.withIndex().filter { it.value is FeedEntry.Sponsored }.map { it.index }
        // video,video,video,AD(3) | v v v v v v | AD(10) ...
        assertEquals(listOf(3, 10), adPositions)
    }

    @Test
    fun slotsAreStableWhenMorePagesLoad() {
        val short = buildFeed(videos(9), withAds = true).filterIsInstance<FeedEntry.Sponsored>().map { it.slot }
        val long = buildFeed(videos(30), withAds = true).filterIsInstance<FeedEntry.Sponsored>().map { it.slot }
        assertEquals(long.take(short.size), short)
    }

    @Test
    fun feedKeysAreUnique() {
        val keys = buildFeed(videos(60), withAds = true).map { it.key }
        assertEquals(keys.size, keys.toSet().size)
    }

    @Test
    fun adSlotsAreCapped() {
        val ads = buildFeed(videos(500), withAds = true).count { it is FeedEntry.Sponsored }
        assertEquals(MAX_NATIVE_SLOTS, ads)
    }
}
