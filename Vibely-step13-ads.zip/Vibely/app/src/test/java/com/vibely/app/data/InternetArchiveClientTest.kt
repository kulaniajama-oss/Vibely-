package com.vibely.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class InternetArchiveClientTest {
    @Test
    fun cleanQueryStripsOperatorsAndKeepsLetters() {
        assertEquals("rock roll live", cleanQuery("  rock & roll!!  \"live\" "))
        assertEquals("foo bar baz x AND y", cleanQuery("foo:bar* \"baz\" (x) AND y"))
        assertEquals("Oromoo muuziqaa", cleanQuery("Oromoo, muuziqaa?"))
    }

    @Test
    fun searchQueryFiltersRestrictedItemsAndMediaType() {
        val q = buildSearchQuery("jazz")
        assertTrue(q.startsWith("(jazz) AND "))
        assertTrue(q.contains("-access-restricted-item:true"))
        assertTrue(q.contains("mediatype:(movies OR audio)"))
        assertEquals("mediatype:(movies OR audio) AND -access-restricted-item:true", buildSearchQuery("!!!"))
    }

    @Test
    fun runtimeFormattingAndSeconds() {
        assertEquals("2:05", formatRuntime("125"))
        assertEquals("1:02:05", formatRuntime("3725.4"))
        assertEquals("12:30", formatRuntime("12:30"))
        assertNull(formatRuntime(null))
        assertNull(formatRuntime("abc"))
        assertNull(formatRuntime("0"))
        assertEquals(205, runtimeSeconds("00:03:25"))
        assertEquals(205, runtimeSeconds("3:25"))
        assertEquals(205, runtimeSeconds("205.45"))
        assertNull(runtimeSeconds(""))
    }

    @Test
    fun picksDerivativesFirstSmallestFirstAndSkipsUnplayableFiles() {
        val files = listOf(
            IaFile("movie_512kb.mp4", 1_000_000, "derivative"),
            IaFile("movie.mp4", 5_000_000, "derivative"),
            IaFile("movie_orig.mp4", 500_000, "original"),
            IaFile("movie.ogv", 900_000, "derivative"),   // ExoPlayer cannot play Ogg Theora
            IaFile("tiny.mp4", 100, "derivative"),          // stub
            IaFile("_hidden.mp4", 90_000, "derivative"),    // internal file
            IaFile("song.mp3", 300_000, "original")         // video wins over audio
        )
        val picked = pickMediaFiles(files)
        assertEquals(listOf("movie_512kb.mp4", "movie.mp4", "movie_orig.mp4"), picked.map { it.name })
        assertTrue(picked.all { it.type == "video" })
    }

    @Test
    fun fallsBackToAudioAndReturnsEmptyWhenNothingPlays() {
        val audio = pickMediaFiles(listOf(IaFile("a.mp3", 90_000, "original")))
        assertEquals(listOf(PickedFile("a.mp3", "audio")), audio)
        assertTrue(pickMediaFiles(listOf(IaFile("notes.txt", 10, "original"))).isEmpty())
    }

    @Test
    fun neverReturnsMoreThanTheLimit() {
        val many = (1..10).map { IaFile("v$it.mp4", 100_000L + it, "derivative") }
        assertEquals(4, pickMediaFiles(many).size)
        assertEquals(2, pickMediaFiles(many, max = 2).size)
    }

    // ---- Step 10: categories, details, related, downloads ----

    @Test
    fun categoriesAreUniqueAndOnlyOpenlyAccessible() {
        assertNull(IaCategories.first().query) // "All" is the Featured feed
        assertEquals(IaCategories.size, IaCategories.map { it.id }.toSet().size)
        IaCategories.drop(1).forEach { c ->
            assertTrue(c.id, c.query!!.contains("-access-restricted-item:true"))
        }
    }

    @Test
    fun htmlBecomesReadablePlainText() {
        assertEquals(
            "Hello & welcome\nLine two\nThree \u00A9 \"ok\"",
            htmlToPlain("<p>Hello &amp; welcome</p><p>Line&nbsp;two<br/>Three &#169; &quot;ok&quot;</p>")
        )
        assertEquals("a\n\nb", htmlToPlain("a<br><br><br><br>b"))
        assertEquals("", htmlToPlain(null))
        assertEquals("", htmlToPlain("   "))
    }

    @Test
    fun subjectsAreSplitCleanedAndDeduplicated() {
        assertEquals(
            listOf("Cats", "dogs", "Birds", "Fish"),
            splitSubjects(listOf("Cats; dogs", "cats", "x", "Birds, Fish"))
        )
        assertEquals(listOf("Cats", "dogs"), splitSubjects(listOf("Cats; dogs", "Birds"), max = 2))
    }

    @Test
    fun licenseLabels() {
        assertEquals("CC BY-NC", licenseLabel("https://creativecommons.org/licenses/by-nc/4.0/"))
        assertEquals("CC0", licenseLabel("https://creativecommons.org/publicdomain/zero/1.0/"))
        assertEquals("Public domain", licenseLabel("http://creativecommons.org/publicdomain/mark/1.0/"))
        assertEquals("", licenseLabel(null))
        assertEquals("", licenseLabel("https://example.com/terms"))
    }

    @Test
    fun relatedQueryPrefersTopicsThenCollectionsAndExcludesTheItself() {
        val byTopic = buildRelatedQuery("abc-1", listOf("Space", "Moon landing", "Third"), listOf("nasa"))!!
        assertTrue(byTopic.startsWith("subject:(\"Space\" OR \"Moon landing\") AND "))
        assertTrue(byTopic.contains("-identifier:\"abc-1\""))
        assertTrue(byTopic.contains("-access-restricted-item:true"))

        val byCollection = buildRelatedQuery("abc-1", listOf("ab"), listOf("fav-bob", "opensource_movies", "prelinger"))!!
        assertTrue(byCollection.startsWith("collection:\"prelinger\" AND "))

        assertNull(buildRelatedQuery("abc-1", emptyList(), listOf("community", "fav-x")))
    }

    @Test
    fun downloadFileNamesAreSafe() {
        assertEquals("my-id_Big_Movie__HD_.mp4", downloadFileName("my-id", "Big Movie (HD).mp4"))
        assertEquals("a_noext", downloadFileName("a", "noext"))
        assertTrue(downloadFileName("id", "x".repeat(300) + ".mp4").length <= 105)
        assertTrue(downloadFileName("id", "../../etc/passwd.mp4").none { it == '/' })
    }

    // ---- Audio: albums, audiobooks, concerts ----

    @Test
    fun naturalOrderPutsTrack2BeforeTrack10() {
        val sorted = listOf("Track 10", "track 2", "Track 1").sortedWith { a, b -> naturalCompare(a, b) }
        assertEquals(listOf("Track 1", "track 2", "Track 10"), sorted)
        assertTrue(naturalCompare("a01", "a1") == 0)
    }

    @Test
    fun trackNumbersAndNames() {
        assertEquals(3, trackNumber("3/12"))
        assertEquals(7, trackNumber("07"))
        assertNull(trackNumber(""))
        assertNull(trackNumber("abc"))
        assertEquals("01 Hello World", friendlyTrackName("01_Hello_World.mp3"))
    }

    @Test
    fun albumGetsOneMp3PerTrackInTrackOrder() {
        val files = listOf(
            IaFile("02_second.flac", 30_000_000, "original", title = "Second Song", track = 2),
            IaFile("02_second.mp3", 4_000_000, "derivative", title = "Second Song", track = 2),
            IaFile("01_first.flac", 30_000_000, "original", title = "First Song", track = 1, length = "185.2"),
            IaFile("01_first.mp3", 4_000_000, "derivative", title = "First Song", track = 1, length = "185.2"),
            IaFile("01_first.ogg", 3_000_000, "derivative", track = 1),
            IaFile("cover.jpg", 50_000, "original"),
            IaFile("album_meta.xml", 2_000, "original")
        )
        val tracks = pickAudioTracks(files)
        assertEquals(listOf("01_first.mp3", "02_second.mp3"), tracks.map { it.name })
        assertEquals(listOf("First Song", "Second Song"), tracks.map { it.title })
        assertEquals(185, tracks.first().seconds)
    }

    @Test
    fun tracksWithoutNumbersFollowFileNames() {
        val files = listOf(
            IaFile("chapter10.mp3", 1_000_000, "original"),
            IaFile("chapter2.mp3", 1_000_000, "original"),
            IaFile("chapter1.mp3", 1_000_000, "original")
        )
        assertEquals(listOf("chapter1.mp3", "chapter2.mp3", "chapter10.mp3"), pickAudioTracks(files).map { it.name })
        assertEquals("chapter1", pickAudioTracks(files).first().title)
    }

    @Test
    fun noAudioFilesMeansNoTracks() {
        assertTrue(pickAudioTracks(listOf(IaFile("movie.mp4", 5_000_000, "derivative"))).isEmpty())
    }

    @Test
    fun audioCategoriesExist() {
        val ids = IaCategories.map { it.id }
        assertTrue(ids.containsAll(listOf("music", "audiobooks", "podcasts", "oldradio", "concerts")))
        assertTrue(IaCategories.first { it.id == "audiobooks" }.query!!.contains("mediatype:audio"))
    }
}

