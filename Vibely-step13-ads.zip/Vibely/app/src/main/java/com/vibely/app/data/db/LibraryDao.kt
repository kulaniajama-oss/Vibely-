package com.vibely.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    // ---- media snapshots ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMedia(media: MediaEntity)

    // ---- history ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHistory(entry: HistoryEntity)

    @Query(
        "SELECT m.* FROM media_items m INNER JOIN history h " +
            "ON m.sourceId = h.sourceId AND m.id = h.id ORDER BY h.watchedAt DESC LIMIT 200"
    )
    fun history(): Flow<List<MediaEntity>>

    @Query("DELETE FROM history")
    suspend fun clearHistory()

    @Query("DELETE FROM history WHERE sourceId = :sourceId AND id = :id")
    suspend fun removeHistory(sourceId: String, id: String)

    // ---- likes ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLike(like: LikeEntity)

    @Query("DELETE FROM likes WHERE sourceId = :sourceId AND id = :id")
    suspend fun deleteLike(sourceId: String, id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM likes WHERE sourceId = :sourceId AND id = :id)")
    fun isLiked(sourceId: String, id: String): Flow<Boolean>

    @Query(
        "SELECT m.* FROM media_items m INNER JOIN likes l " +
            "ON m.sourceId = l.sourceId AND m.id = l.id ORDER BY l.createdAt DESC"
    )
    fun liked(): Flow<List<MediaEntity>>

    // ---- saved ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaved(saved: SavedEntity)

    @Query("DELETE FROM saved WHERE sourceId = :sourceId AND id = :id")
    suspend fun deleteSaved(sourceId: String, id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved WHERE sourceId = :sourceId AND id = :id)")
    fun isSaved(sourceId: String, id: String): Flow<Boolean>

    @Query(
        "SELECT m.* FROM media_items m INNER JOIN saved s " +
            "ON m.sourceId = s.sourceId AND m.id = s.id ORDER BY s.createdAt DESC"
    )
    fun saved(): Flow<List<MediaEntity>>

    // ---- playlists ----
    @Insert
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query(
        "SELECT p.id AS id, p.name AS name, " +
            "(SELECT COUNT(*) FROM playlist_items i WHERE i.playlistId = p.id) AS itemCount " +
            "FROM playlists p ORDER BY p.createdAt DESC"
    )
    fun playlists(): Flow<List<PlaylistSummary>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistItem(item: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId AND sourceId = :sourceId AND id = :id")
    suspend fun deletePlaylistItem(playlistId: Long, sourceId: String, id: String)

    @Query(
        "SELECT m.* FROM media_items m INNER JOIN playlist_items pi " +
            "ON m.sourceId = pi.sourceId AND m.id = pi.id " +
            "WHERE pi.playlistId = :playlistId ORDER BY pi.addedAt DESC"
    )
    fun playlistItems(playlistId: Long): Flow<List<MediaEntity>>

    // ---- sync helpers (merge cloud data without overwriting local times) ----
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertHistoryIfAbsent(entry: HistoryEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLikeIfAbsent(like: LikeEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSavedIfAbsent(saved: SavedEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPlaylistItemIfAbsent(item: PlaylistItemEntity)

    @Query("SELECT * FROM playlists")
    suspend fun playlistsList(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :playlistId LIMIT 1")
    suspend fun playlistById(playlistId: Long): PlaylistEntity?

    @Query("SELECT * FROM playlists WHERE cloudId = :cloudId LIMIT 1")
    suspend fun playlistByCloudId(cloudId: String): PlaylistEntity?

    @Query(
        "SELECT m.*, h.watchedAt AS ts FROM media_items m INNER JOIN history h " +
            "ON m.sourceId = h.sourceId AND m.id = h.id"
    )
    suspend fun historyTimed(): List<TimedMedia>

    @Query(
        "SELECT m.*, l.createdAt AS ts FROM media_items m INNER JOIN likes l " +
            "ON m.sourceId = l.sourceId AND m.id = l.id"
    )
    suspend fun likesTimed(): List<TimedMedia>

    @Query(
        "SELECT m.*, s.createdAt AS ts FROM media_items m INNER JOIN saved s " +
            "ON m.sourceId = s.sourceId AND m.id = s.id"
    )
    suspend fun savedTimed(): List<TimedMedia>

    @Query(
        "SELECT m.*, pi.addedAt AS ts FROM media_items m INNER JOIN playlist_items pi " +
            "ON m.sourceId = pi.sourceId AND m.id = pi.id WHERE pi.playlistId = :playlistId"
    )
    suspend fun playlistItemsTimed(playlistId: Long): List<TimedMedia>

    // ---- wipe (account switch / sign-out & clear) ----
    @Query("DELETE FROM likes")
    suspend fun clearLikes()

    @Query("DELETE FROM saved")
    suspend fun clearSaved()

    @Query("DELETE FROM playlists")
    suspend fun clearPlaylists()

    @Query("DELETE FROM media_items")
    suspend fun clearMedia()
}
