package com.vibely.app.data

import com.vibely.app.BuildConfig
import com.vibely.app.MediaItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

data class SearchResult(
    val items: List<MediaItem>,
    val message: String,
    val hasMore: Boolean = false,
    /** True when nothing could be loaded and there was nothing saved to fall back on. */
    val failed: Boolean = false
)

/** One track of an audio item (album, audiobook, concert). */
data class MediaTrack(val title: String, val url: String, val seconds: Int?)

/**
 * Playable file URLs for an item, best first. If the player cannot decode one, it moves on to the next.
 * [type] is "video" or "audio".
 */
data class ResolvedMedia(
    val urls: List<String>,
    val type: String,
    /** Audio albums, audiobooks and concerts: every track in play order. Empty for single files and video. */
    val tracks: List<MediaTrack> = emptyList(),
    /**
     * A web player page (Dailymotion, Vimeo, Rumble, Odysee, PeerTube) shown inside the app. Used when there is no
     * direct file ([urls] empty), or as the automatic fallback when every direct file fails to play.
     */
    val embedUrl: String? = null
) {
    val url: String get() = urls.firstOrNull() ?: embedUrl.orEmpty()
}

/**
 * Where the app gets its content.
 *
 * Real data only (no demo catalog): the Internet Archive public API is called straight from the phone,
 * so everything works with no server at all. Search and the Home feed also mix in videos from the extra
 * sources in [ExtraSources] (PeerTube, Wikimedia Commons, Pexels, Pixabay, Mixkit, Rumble, Odysee, Dailymotion, Vimeo). If a Render backend URL is configured it is tried first
 * (it adds server-side caching and more sources later) and the direct API is the automatic fallback.
 */
object VibelyRepository {
    private val client get() = sharedHttpClient

    // Short-lived page cache: repeat searches are instant, and the last results stay readable offline.
    private val cache = TtlCache<String, SearchResult>(maxEntries = 40, ttlMs = 5 * 60_000L)
    private val resolveCache = TtlCache<String, ResolvedMedia>(maxEntries = 60, ttlMs = 30 * 60_000L)
    private val detailsCache = TtlCache<String, ItemDetails>(maxEntries = 40, ttlMs = 30 * 60_000L)
    private val relatedCache = TtlCache<String, List<MediaItem>>(maxEntries = 40, ttlMs = 30 * 60_000L)

    private val backendConfigured: Boolean
        get() = !BuildConfig.BACKEND_BASE_URL.contains("YOUR-RENDER-SERVICE")

    /** Internet Archive results (unchanged) with videos from the extra sources mixed in. */
    suspend fun search(query: String, page: Int = 1): SearchResult = loadMerged(
        cacheKey = "search|$query|$page",
        backendPath = "/api/search?q=" + enc(query) + "&page=$page",
        direct = { InternetArchiveClient.search(query, page) },
        extras = { ExtraSources.search(query, page) }
    )

    suspend fun featured(page: Int = 1): SearchResult = loadMerged(
        cacheKey = "featured|$page",
        backendPath = "/api/featured?page=$page",
        direct = { InternetArchiveClient.featured(page) },
        extras = { ExtraSources.latest(page) }
    )

    /**
     * Loads the Internet Archive page exactly as before ([load]) and, at the same time, asks the extra
     * sources (PeerTube, Wikimedia, Pexels, Mixkit, Rumble, ...). One extra item is mixed in after every
     * three Internet Archive items. If the extras fail or are empty, the Internet Archive page is shown alone;
     * if Internet Archive fails but extras answered, the extras are shown.
     */
    private suspend fun loadMerged(
        cacheKey: String,
        backendPath: String?,
        direct: suspend () -> List<MediaItem>,
        extras: suspend () -> List<MediaItem>
    ): SearchResult = coroutineScope {
        val key = "merged|$cacheKey"
        cache.get(key)?.let { return@coroutineScope it }
        val extraJob = async(Dispatchers.IO) {
            try {
                extras()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList<MediaItem>()
            }
        }
        val base = load(cacheKey, backendPath, direct)
        val more = extraJob.await()
        if (more.isEmpty()) return@coroutineScope base
        val items = mixIn(if (base.failed) emptyList() else base.items, more)
        val merged = base.copy(
            items = items,
            message = "${items.size} results.",
            failed = false
        )
        cache.put(key, merged)
        merged
    }

    /** One page of a Home category (Movies, Music, Kids, …), straight from Internet Archive collections. */
    suspend fun category(category: IaCategory, page: Int = 1): SearchResult = load(
        cacheKey = "category|${category.id}|$page",
        backendPath = null,
        direct = { InternetArchiveClient.category(category, page) }
    )

    /**
     * Description, topics, license and viewer reviews for the player screen.
     * Null when the item is not from Internet Archive or nothing could be loaded (e.g. offline);
     * the player simply shows less in that case.
     */
    suspend fun details(item: MediaItem): ItemDetails? = withContext(Dispatchers.IO) {
        if (item.sourceId != InternetArchiveClient.SOURCE_ID) return@withContext null
        detailsCache.get(item.id)?.let { return@withContext it }
        try {
            InternetArchiveClient.details(item.id).also { detailsCache.put(item.id, it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /** Other videos/audio on the same topic as [item]. Empty when none can be found or loaded. */
    suspend fun related(item: MediaItem, details: ItemDetails): List<MediaItem> = withContext(Dispatchers.IO) {
        relatedCache.get(item.id)?.let { return@withContext it }
        try {
            InternetArchiveClient.related(item.id, details).also { if (it.isNotEmpty()) relatedCache.put(item.id, it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Real short clips for the Shorts tab (one batch; loaded straight from the Internet Archive). */
    suspend fun shorts(): SearchResult = load(
        cacheKey = "shorts",
        backendPath = null,
        direct = { InternetArchiveClient.shorts() },
        paged = false
    )

    /**
     * Finds directly playable URLs for an item. Throws IllegalStateException with a user-readable message.
     * [fresh] skips the saved answer (used by Retry).
     */
    suspend fun resolve(item: MediaItem, fresh: Boolean = false): ResolvedMedia = withContext(Dispatchers.IO) {
        val direct = item.mediaUrl
        if (!direct.isNullOrBlank()) {
            return@withContext ResolvedMedia(listOf(direct), item.mediaType ?: "video")
        }
        if (item.sourceId.isBlank() || item.sourceId == "demo") {
            throw IllegalStateException("This item has no playable media.")
        }
        if (!fresh) resolveCache.get(item.key)?.let { return@withContext it }

        // Extra sources (PeerTube, Mixkit, Rumble, ...) are resolved on the phone; the backend only knows Internet Archive.
        ExtraSources.byId(item.sourceId)?.let { source ->
            try {
                val result = source.resolve(item.id)
                resolveCache.put(item.key, result)
                return@withContext result
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalStateException) {
                throw e
            } catch (e: IOException) {
                throw IllegalStateException("Could not reach ${source.name}: ${e.message ?: "network error"}. Tap Retry.")
            } catch (e: Exception) {
                throw IllegalStateException("${source.name} did not give a playable video. Tap Retry or try another video.")
            }
        }

        var backendError: String? = null
        if (backendConfigured) {
            try {
                val result = resolveViaBackend(item)
                resolveCache.put(item.key, result)
                return@withContext result
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                backendError = e.message // fall through to the direct API below
            }
        }

        if (item.sourceId == InternetArchiveClient.SOURCE_ID) {
            try {
                val result = InternetArchiveClient.resolve(item.id)
                resolveCache.put(item.key, result)
                return@withContext result
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                throw IllegalStateException("Could not reach Internet Archive: ${e.message ?: "network error"}")
            }
        }
        throw IllegalStateException(backendError ?: "This source can't be played yet.")
    }

    private fun resolveViaBackend(item: MediaItem): ResolvedMedia {
        val url = BuildConfig.BACKEND_BASE_URL.trimEnd('/') +
            "/api/resolve?source_id=" + enc(item.sourceId) + "&id=" + enc(item.id)
        return client.newCall(Request.Builder().url(url).get().build()).execute().use {
            val body = it.body?.string().orEmpty()
            if (!it.isSuccessful) {
                val detail = runCatching { JSONObject(body).optString("detail") }.getOrNull().orEmpty()
                throw IllegalStateException(detail.ifBlank { "Backend returned HTTP ${it.code}" })
            }
            val obj = JSONObject(body)
            ResolvedMedia(listOf(obj.getString("media_url")), obj.optString("media_type", "video"))
        }
    }

    /** Backend first (when configured), then the direct Internet Archive API, then the last saved copy. */
    private suspend fun load(
        cacheKey: String,
        backendPath: String?,
        direct: suspend () -> List<MediaItem>,
        paged: Boolean = true
    ): SearchResult = withContext(Dispatchers.IO) {
        cache.get(cacheKey)?.let { return@withContext it }

        var backendError: String? = null
        if (backendConfigured && backendPath != null) {
            try {
                val result = fetchFromBackend(backendPath)
                cache.put(cacheKey, result)
                return@withContext result
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                backendError = e.message
            }
        }

        try {
            val items = direct()
            val result = SearchResult(
                items = items,
                message = if (items.isEmpty()) "No results found." else "${items.size} results.",
                hasMore = paged && items.size >= InternetArchiveClient.PAGE_SIZE
            )
            // An empty answer is not worth keeping: the next try should ask again.
            if (items.isNotEmpty()) cache.put(cacheKey, result)
            result
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Offline or source down: fall back to the last copy of this page, if we have one.
            cache.getStale(cacheKey)?.copy(message = "You're offline — showing saved results.")
                ?: SearchResult(
                    emptyList(),
                    "Could not load videos: ${e.message ?: backendError ?: "network error"}. " +
                        "Check your connection and try again.",
                    failed = true
                )
        }
    }

    private fun fetchFromBackend(path: String): SearchResult {
        val url = BuildConfig.BACKEND_BASE_URL.trimEnd('/') + path
        return client.newCall(Request.Builder().url(url).get().build()).execute().use {
            if (!it.isSuccessful) throw IllegalStateException("Backend returned HTTP ${it.code}")
            parse(JSONObject(it.body?.string() ?: "{}"))
        }
    }

    private fun parse(root: JSONObject): SearchResult {
        val array = root.optJSONArray("items")
        val result = mutableListOf<MediaItem>()
        if (array != null) {
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result += MediaItem(
                    id = obj.optString("id", "item-$i"),
                    title = obj.optString("title", "Untitled"),
                    uploader = obj.optString("uploader", "Unknown"),
                    thumbnailUrl = obj.optStringOrNull("thumbnail_url"),
                    duration = obj.optStringOrNull("duration") ?: "",
                    source = obj.optString("source", "Unknown"),
                    sourceId = obj.optString("source_id", ""),
                    mediaType = obj.optStringOrNull("media_type"),
                    pageUrl = obj.optStringOrNull("page_url"),
                    mediaUrl = obj.optStringOrNull("media_url")
                )
            }
        }
        return SearchResult(
            items = result,
            message = root.optString("message", "Done."),
            hasMore = root.optBoolean("has_more", false)
        )
    }

    private fun enc(value: String): String = java.net.URLEncoder.encode(value, "UTF-8")

    // org.json returns the string "null" for JSON nulls via optString, so handle that explicitly.
    private fun JSONObject.optStringOrNull(key: String): String? {
        if (isNull(key)) return null
        return optString(key).takeIf { it.isNotBlank() }
    }
}
