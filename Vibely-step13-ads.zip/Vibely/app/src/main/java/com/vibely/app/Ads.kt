package com.vibely.app

import android.app.Activity
import android.content.Context
import android.os.SystemClock
import android.util.Log
import android.view.View
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.startapp.sdk.ads.banner.Banner
import com.startapp.sdk.ads.banner.Mrec
import com.startapp.sdk.ads.nativead.NativeAdDetails
import com.startapp.sdk.ads.nativead.NativeAdPreferences
import com.startapp.sdk.ads.nativead.StartAppNativeAd
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import java.lang.ref.WeakReference

/*
 * Start.io ads for Vibely — everything ad-related lives in this file.
 *
 *   Home feed ........ a native "Sponsored" card after the 3rd video, then after every 6th
 *   Player page ...... a banner under the details, and an MREC (300x250) inside "More like this"
 *   After a video .... a full-screen interstitial, at most once per 3 videos AND once per 3 minutes
 *
 * The SDK itself is initialised from the manifest (APPLICATION_ID meta-data). Ads that have no fill
 * simply take no space, so the app never shows empty boxes.
 */

// ---- Home-feed layout (pure numbers so they can be unit-tested) ----
internal const val NATIVE_FIRST_AFTER = 3
internal const val NATIVE_EVERY = 6
internal const val MAX_NATIVE_SLOTS = 12

/** One row of the Home feed: a real video or a sponsored native-ad slot. */
sealed interface FeedEntry {
    val key: String

    data class Video(val item: MediaItem) : FeedEntry {
        override val key: String get() = item.key
    }

    data class Sponsored(val slot: Int) : FeedEntry {
        override val key: String get() = "ad:$slot"
    }
}

/** Interleaves sponsored slots into [videos]. The slot number depends only on the position, so it stays stable as pages load. */
internal fun buildFeed(videos: List<MediaItem>, withAds: Boolean): List<FeedEntry> {
    val out = ArrayList<FeedEntry>(videos.size + videos.size / NATIVE_EVERY + 1)
    var slot = 0
    videos.forEachIndexed { index, item ->
        out += FeedEntry.Video(item)
        val position = index + 1
        if (withAds && slot < MAX_NATIVE_SLOTS &&
            position >= NATIVE_FIRST_AFTER && (position - NATIVE_FIRST_AFTER) % NATIVE_EVERY == 0
        ) {
            out += FeedEntry.Sponsored(slot++)
        }
    }
    return out
}

object VibelyAds {
    private const val TAG = "VibelyAds"
    private const val MIN_MS_BETWEEN_INTERSTITIALS = 3 * 60 * 1000L
    private const val PLAYER_CLOSES_BETWEEN_INTERSTITIALS = 3
    private const val RETRY_NATIVE_AFTER_MS = 60 * 1000L

    /** Master switch (build with VIBELY_ADS_ENABLED=false to turn every ad off). */
    val enabled: Boolean get() = BuildConfig.ADS_ENABLED

    // ---- Interstitial ----
    private var activityRef: WeakReference<Activity>? = null
    private var interstitial: StartAppAd? = null
    private var interstitialLoading = false
    private var lastInterstitialAt = 0L
    private var playerCloses = 0

    // ---- Native ads (one per feed slot, loaded once and kept for the session) ----
    private val nativeAds = mutableStateMapOf<Int, NativeAdDetails>()
    private val nativeLoading = HashSet<Int>()
    private val nativeFailedAt = HashMap<Int, Long>()

    /** Call from MainActivity.onCreate. */
    fun onActivityCreate(activity: Activity) {
        // Test ads: always in debug builds; in release only when VIBELY_TEST_ADS=true.
        if (BuildConfig.ADS_TEST_MODE) StartAppSDK.setTestAdsEnabled(true)
        activityRef = WeakReference(activity)
        // The first interstitial may not appear until 3 minutes after launch.
        if (lastInterstitialAt == 0L) lastInterstitialAt = SystemClock.elapsedRealtime()
        if (enabled) loadInterstitial(activity)
    }

    /** Call from MainActivity.onDestroy so the Activity is not kept alive by the ad object. */
    fun onActivityDestroy() {
        activityRef = null
        interstitial = null
        interstitialLoading = false
    }

    private fun loadInterstitial(activity: Activity) {
        if (interstitial != null || interstitialLoading) return
        interstitialLoading = true
        val ad = StartAppAd(activity)
        ad.loadAd(object : AdEventListener {
            override fun onReceiveAd(received: Ad) {
                interstitialLoading = false
                interstitial = ad
            }

            override fun onFailedToReceiveAd(failed: Ad?) {
                interstitialLoading = false
                Log.w(TAG, "Interstitial failed to load")
            }
        })
    }

    /**
     * Call when the user leaves the player screen. Shows an interstitial only if enough videos AND
     * enough time have passed since the last one, so ads never feel constant.
     */
    fun onPlayerClosed() {
        if (!enabled) return
        playerCloses++
        val activity = activityRef?.get() ?: return
        val now = SystemClock.elapsedRealtime()
        val due = playerCloses >= PLAYER_CLOSES_BETWEEN_INTERSTITIALS &&
            now - lastInterstitialAt >= MIN_MS_BETWEEN_INTERSTITIALS
        if (!due) {
            loadInterstitial(activity) // keep one ready for later
            return
        }
        val ad = interstitial
        if (ad == null) {
            loadInterstitial(activity)
            return
        }
        interstitial = null // each StartAppAd instance is shown once
        if (ad.showAd()) {
            lastInterstitialAt = now
            playerCloses = 0
        }
        loadInterstitial(activity)
    }

    // ---- Native ----

    internal fun nativeAd(slot: Int): NativeAdDetails? = nativeAds[slot]

    internal fun requestNative(context: Context, slot: Int) {
        if (!enabled || slot >= MAX_NATIVE_SLOTS) return
        if (nativeAds.containsKey(slot) || slot in nativeLoading) return
        val now = SystemClock.elapsedRealtime()
        val failedAt = nativeFailedAt[slot]
        if (failedAt != null && now - failedAt < RETRY_NATIVE_AFTER_MS) return

        nativeLoading += slot
        val preferences = NativeAdPreferences()
        preferences.setAutoBitmapDownload(true)
        val nativeAd = StartAppNativeAd(context.applicationContext)
        nativeAd.setPreferences(preferences)
        nativeAd.loadAd(object : AdEventListener {
            override fun onReceiveAd(received: Ad) {
                nativeLoading -= slot
                val details = nativeAd.nativeAds?.firstOrNull()
                if (details != null) {
                    nativeAds[slot] = details
                } else {
                    nativeFailedAt[slot] = SystemClock.elapsedRealtime()
                }
            }

            override fun onFailedToReceiveAd(failed: Ad?) {
                nativeLoading -= slot
                nativeFailedAt[slot] = SystemClock.elapsedRealtime()
                Log.w(TAG, "Native ad $slot failed to load")
            }
        })
    }
}

// ------------------------------------------------------------------------------------------------
// Composables
// ------------------------------------------------------------------------------------------------

/** Standard 320x50 banner, centred. Takes no space until an ad arrives. */
@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    if (!VibelyAds.enabled) return
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        AndroidView(factory = { context -> Banner(context) })
    }
}

/** 300x250 rectangle, centred, for spots next to content. */
@Composable
fun MrecAd(modifier: Modifier = Modifier) {
    if (!VibelyAds.enabled) return
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        AndroidView(factory = { context -> Mrec(context) })
    }
}

/** A native ad styled like a Vibely card. Draws nothing until the ad for this slot has loaded. */
@Composable
fun NativeAdCard(slot: Int) {
    if (!VibelyAds.enabled) return
    val context = LocalContext.current
    LaunchedEffect(slot) { VibelyAds.requestNative(context, slot) }
    val ad = VibelyAds.nativeAd(slot)
    if (ad != null) NativeAdContent(ad)
}

@Composable
private fun NativeAdContent(ad: NativeAdDetails) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 12.dp, bottom = 18.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceDark)
            // Required by Start.io: without a fixed intrinsic height the transparent click layer below cannot cover the card.
            .height(IntrinsicSize.Max)
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            val bitmap = ad.imageBitmap
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(84.dp).clip(RoundedCornerShape(12.dp))
                )
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text("Sponsored", color = Color.Gray, fontSize = 10.sp)
                Text(
                    ad.title ?: "",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    ad.description ?: "",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                val action = ad.callToAction
                if (!action.isNullOrBlank()) {
                    Text(
                        action,
                        color = Accent,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
        // Transparent view on top: Start.io handles the tap (impression + click) through it.
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                View(context).also { ad.registerViewForInteraction(it) }
            }
        )
    }
}
