package com.vibely.app.data

import android.net.Uri
import com.vibely.app.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

/*
 * Real Internet Archive client (public, documented advancedsearch + metadata APIs).
 *
 * The app uses this directly, so videos load and play even when no Render backend is configured.
 * Only openly accessible items are returned (borrow-only / restricted items are filtered out).
 * The pure helpers below do not touch Android or the network, so they are unit-tested.
 */

/** One file of an archive.org item, as listed by /metadata/{id}. */
data class IaFile(
    val name: String,
    val sizeBytes: Long,
    val source: String,
    /** Track title / number / length (seconds or mm:ss) as archive.org lists them for audio files. */
    val title: String = "",
    val track: Int? = null,
    val length: String = ""
)

/** One track of an audio item: the file to play plus a readable title. */
data class AudioTrack(val name: String, val title: String, val seconds: Int?)

/** A playable file chosen for an item. [type] is "video" or "audio". */
data class PickedFile(val name: String, val type: String)

// ExoPlayer cannot play Ogg Theora (.ogv), so it is deliberately not listed.
private val VIDEO_EXT = listOf(".mp4", ".m4v", ".webm", ".mkv")
private val AUDIO_EXT = listOf(".mp3", ".m4a", ".ogg", ".opus", ".flac", ".wav")

private val NON_QUERY_CHARS = Regex("[^\\p{L}\\p{N}_\\s-]")
private val WHITESPACE = Regex("\\s+")

/** Strips Lucene operators so user text is treated as plain keywords. */
fun cleanQuery(q: String): String =
    q.replace(NON_QUERY_CHARS, " ").replace(WHITESPACE, " ").trim()

fun buildSearchQuery(q: String): String {
    val base = "mediatype:(movies OR audio) AND -access-restricted-item:true"
    val cleaned = cleanQuery(q)
    return if (cleaned.isEmpty()) base else "($cleaned) AND $base"
}

/** Accepts seconds ("123.4"), "mm:ss" or "hh:mm:ss". Returns whole seconds, or null if unknown. */
fun runtimeSeconds(raw: String?): Int? {
    val text = raw?.trim().orEmpty()
    if (text.isEmpty()) return null
    if (text.contains(':')) {
        val parts = text.split(':').map { it.trim().toDoubleOrNull() ?: return null }
        if (parts.size !in 2..3) return null
        var total = 0.0
        for (p in parts) total = total * 60 + p
        return total.toInt().takeIf { it > 0 }
    }
    return text.toDoubleOrNull()?.toInt()?.takeIf { it > 0 }
}

/** "125" -> "2:05", "3725.4" -> "1:02:05", "12:30" stays "12:30"; null when unknown. */
fun formatRuntime(raw: String?): String? {
    val text = raw?.trim().orEmpty()
    if (text.contains(':')) return text.takeIf { runtimeSeconds(it) != null }
    val total = runtimeSeconds(text) ?: return null
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(Locale.ROOT, h, m, s) else "%d:%02d".format(Locale.ROOT, m, s)
}

/**
 * Orders the directly playable files of an item, best first (at most [max]).
 * Video wins over audio; derivatives (smaller, streamable) come before originals, smaller before larger.
 * The player tries them in order, so a file the device cannot decode is not the end of the road.
 */
fun pickMediaFiles(files: List<IaFile>, max: Int = 4): List<PickedFile> {
    val usable = files.filter { f ->
        f.name.isNotEmpty() && !f.name.startsWith("_") && !f.name.contains('/') &&
            (f.sizeBytes == 0L || f.sizeBytes > 20_000L) // ignore stubs
    }

    fun ordered(exts: List<String>, type: String): List<PickedFile> =
        exts.flatMap { ext ->
            usable
                .filter { it.name.lowercase().endsWith(ext) }
                .sortedWith(compareBy<IaFile>({ it.source == "original" }, { it.sizeBytes }))
                .map { PickedFile(it.name, type) }
        }

    val video = ordered(VIDEO_EXT, "video")
    val picked = if (video.isNotEmpty()) video else ordered(AUDIO_EXT, "audio")
    return picked.distinctBy { it.name }.take(max)
}

/** Compares "Track 2" before "Track 10" (digits as numbers, letters ignoring case). */
fun naturalCompare(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        if (a[i].isDigit() && b[j].isDigit()) {
            val si = i
            while (i < a.length && a[i].isDigit()) i++
            val sj = j
            while (j < b.length && b[j].isDigit()) j++
            val na = a.substring(si, i).trimStart('0')
            val nb = b.substring(sj, j).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
        } else {
            val c = a[i].lowercaseChar().compareTo(b[j].lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

/** "3/12" or "03" -> 3; null when unknown. */
fun trackNumber(raw: String?): Int? = raw?.substringBefore('/')?.trim()?.toIntOrNull()?.takeIf { it > 0 }

/** "01_Hello_World.mp3" -> "01 Hello World" */
fun friendlyTrackName(fileName: String): String =
    fileName.substringBeforeLast('.').replace('_', ' ').replace(WHITESPACE, " ").trim()

/**
 * The tracks of an audio item in play order, one file per track.
 * IA stores the same track in several formats (original FLAC plus MP3/Ogg copies): MP3 is preferred
 * (small, plays everywhere), then derivatives before originals. Order follows the track number when
 * known, otherwise the file names ("Track 2" before "Track 10").
 */
fun pickAudioTracks(files: List<IaFile>, max: Int = 200): List<AudioTrack> {
    val audio = files.filter { f ->
        f.name.isNotEmpty() && !f.name.startsWith("_") && !f.name.contains('/') &&
            (f.sizeBytes == 0L || f.sizeBytes > 20_000L) &&
            AUDIO_EXT.any { f.name.lowercase().endsWith(it) }
    }
    fun extRank(f: IaFile) = AUDIO_EXT.indexOfFirst { f.name.lowercase().endsWith(it) }
    val bestPerTrack = audio.groupBy { it.name.substringBeforeLast('.').lowercase() }.values.map { group ->
        group.minWithOrNull(compareBy<IaFile>({ extRank(it) }, { it.source == "original" }, { it.sizeBytes }))!!
    }
    return bestPerTrack
        .sortedWith(
            Comparator<IaFile> { a, b -> (a.track ?: Int.MAX_VALUE).compareTo(b.track ?: Int.MAX_VALUE) }
                .thenComparator { a, b -> naturalCompare(a.name, b.name) }
        )
        .take(max)
        .map { AudioTrack(it.name, it.title.ifBlank { friendlyTrackName(it.name) }, runtimeSeconds(it.length)) }
}

/** A browsable Home category. [query] is an Internet Archive search; null means the Featured feed. */
data class IaCategory(val id: String, val label: String, val query: String?)

private const val OPEN = "-access-restricted-item:true"

/** Home categories, all served by the Internet Archive's own collections (openly accessible items only). */
val IaCategories: List<IaCategory> = listOf(
    IaCategory("all", "All", null),
    IaCategory("movies", "Movies", "mediatype:movies AND collection:(feature_films) AND $OPEN"),
    IaCategory("music", "Music", "mediatype:audio AND collection:(audio_music) AND $OPEN"),
    IaCategory("audiobooks", "Audiobooks", "mediatype:audio AND collection:(librivoxaudio) AND $OPEN"),
    IaCategory("podcasts", "Podcasts", "mediatype:audio AND collection:(audio_podcast) AND $OPEN"),
    IaCategory("oldradio", "Old radio", "mediatype:audio AND collection:(oldtimeradio) AND $OPEN"),
    IaCategory("concerts", "Live concerts", "mediatype:audio AND collection:(etree) AND $OPEN"),
    IaCategory("kids", "Kids", "mediatype:movies AND collection:(animationandcartoons OR youth_media) AND $OPEN"),
    IaCategory("news", "News", "mediatype:movies AND collection:(newsandpublicaffairs) AND $OPEN"),
    IaCategory("tech", "Technology", "mediatype:movies AND collection:(computersandtechvideos) AND $OPEN"),
    IaCategory("education", "Education", "mediatype:movies AND subject:(education OR educational OR lecture) AND $OPEN"),
    IaCategory("sports", "Sports", "mediatype:movies AND collection:(sports) AND $OPEN")
)

/** One viewer review of an item on archive.org; shown in the app as a comment. */
data class IaReview(val author: String, val title: String, val body: String, val stars: Int, val date: String)

/** Everything archive.org knows about an item beyond its playable files. */
data class ItemDetails(
    val description: String,
    val creator: String,
    val date: String,
    val license: String,
    val subjects: List<String>,
    val collections: List<String>,
    val reviews: List<IaReview>
)

private val TAGS = Regex("<[^>]+>")
private val LINE_BREAKS = Regex("(?i)<br\\s*/?>|</p>|</div>|</li>|</h[1-6]>")
private val NUMERIC_ENTITY = Regex("&#(\\d{1,6});")
private val MANY_BLANK_LINES = Regex("\\n{3,}")
private val SPACES = Regex("[ \\t\\u00A0]+")

/** Archive.org descriptions and reviews are small HTML snippets; this turns them into readable plain text. */
fun htmlToPlain(html: String?): String {
    if (html.isNullOrBlank()) return ""
    var text = html.replace(LINE_BREAKS, "\n").replace(TAGS, "")
    text = NUMERIC_ENTITY.replace(text) { m ->
        val code = m.groupValues[1].toIntOrNull()
        if (code != null && code in 1..0x10FFFF) String(Character.toChars(code)) else ""
    }
    text = text.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    return text.lines().joinToString("\n") { it.replace(SPACES, " ").trim() }
        .replace(MANY_BLANK_LINES, "\n\n").trim()
}

/** Subjects arrive as strings or lists, often "a; b; c". Returns clean, distinct topics (at most [max]). */
fun splitSubjects(raw: List<String>, max: Int = 8): List<String> =
    raw.flatMap { it.split(';', ',') }.map { it.trim() }.filter { it.length in 2..40 }
        .distinctBy { it.lowercase() }.take(max)

/** "https://creativecommons.org/licenses/by-nc/4.0/" -> "CC BY-NC"; blank when unknown. */
fun licenseLabel(url: String?): String {
    val u = url?.lowercase().orEmpty()
    if (u.isBlank()) return ""
    if (u.contains("creativecommons.org/publicdomain/zero")) return "CC0"
    if (u.contains("publicdomain")) return "Public domain"
    val m = Regex("creativecommons\\.org/licenses/([a-z-]+)/").find(u) ?: return ""
    return "CC " + m.groupValues[1].uppercase()
}

private val BORING_COLLECTIONS = setOf(
    "community", "additional_collections", "opensource", "opensource_movies", "opensource_audio",
    "movies", "audio", "texts", "web"
)
private val COLLECTION_RE = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$")

/**
 * Search that finds items related to [id]: same topics first, otherwise the same collection.
 * Null when there is nothing to relate on.
 */
fun buildRelatedQuery(id: String, subjects: List<String>, collections: List<String>): String? {
    val base = "mediatype:(movies OR audio) AND $OPEN AND -identifier:\"$id\""
    val terms = subjects.map { cleanQuery(it) }.filter { it.length >= 3 }.take(2)
    if (terms.isNotEmpty()) {
        return "subject:(" + terms.joinToString(" OR ") { "\"$it\"" } + ") AND $base"
    }
    val collection = collections.firstOrNull {
        COLLECTION_RE.matches(it) && !it.startsWith("fav-") && it !in BORING_COLLECTIONS
    } ?: return null
    return "collection:\"$collection\" AND $base"
}

/** A safe, unique file name for a download: "<id>_<remote name>" with only letters, digits and . _ - */
fun downloadFileName(id: String, remoteName: String): String {
    val ext = remoteName.substringAfterLast('.', "").filter { it.isLetterOrDigit() }.take(5)
    val base = (id + "_" + remoteName.substringBeforeLast('.'))
        .replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
    return if (ext.isEmpty()) base else "$base.$ext"
}

internal val sharedHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        // Free Render instances sleep when idle; the first request can take ~50 s to wake up.
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
}

object InternetArchiveClient {
    const val SOURCE_ID = "internetarchive"
    const val PAGE_SIZE = 24

    private const val BASE = "https://archive.org"
    private const val USER_AGENT = "Vibely/0.11 (Android)"
    private val ID_RE = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")

    /** Collections of short clips, used for the Shorts tab. */
    private const val SHORTS_QUERY =
        "mediatype:movies AND -access-restricted-item:true AND collection:(nasa OR stock_footage OR prelinger)"

    suspend fun search(query: String, page: Int): List<MediaItem> = withContext(Dispatchers.IO) {
        if (cleanQuery(query).isEmpty()) emptyList()
        else advancedSearch(buildSearchQuery(query), page, "downloads desc", PAGE_SIZE)
    }

    suspend fun featured(page: Int): List<MediaItem> = withContext(Dispatchers.IO) {
        advancedSearch(
            "collection:(prelinger) AND mediatype:movies AND -access-restricted-item:true",
            page, "downloads desc", PAGE_SIZE
        )
    }

    /** Real short clips (3 minutes or less; if there are too few, up to 10 minutes). */
    suspend fun shorts(): List<MediaItem> = withContext(Dispatchers.IO) {
        val pool = mutableListOf<MediaItem>()
        for (page in 1..3) {
            try {
                pool += advancedSearch(SHORTS_QUERY, page, "downloads desc", 50)
            } catch (e: IOException) {
                if (page == 1) throw e // later pages are a bonus; keep what we already have
                break
            }
        }
        fun within(limit: Int) = pool.filter { (runtimeSeconds(it.duration) ?: Int.MAX_VALUE) <= limit }
        val quick = within(180)
        (if (quick.size >= 5) quick else within(600)).distinctBy { it.key }.take(30)
    }

    // resolve() and details() both need /metadata/{id}; one request serves both.
    private val metaCache = TtlCache<String, JSONObject>(maxEntries = 30, ttlMs = 30 * 60_000L)

    private fun fetchMetadata(id: String): JSONObject {
        metaCache.get(id)?.let { return it }
        val meta = getJson("$BASE/metadata/$id".toHttpUrl())
        if (meta.length() > 0) metaCache.put(id, meta)
        return meta
    }

    /** One page of a Home category (see [IaCategories]). */
    suspend fun category(category: IaCategory, page: Int): List<MediaItem> = withContext(Dispatchers.IO) {
        val q = category.query ?: return@withContext emptyList()
        advancedSearch(q, page, "downloads desc", PAGE_SIZE)
    }

    /** Finds playable file URLs for an item. Throws IllegalStateException with a user-readable message. */
    suspend fun resolve(id: String): ResolvedMedia = withContext(Dispatchers.IO) {
        if (!ID_RE.matches(id)) throw IllegalStateException("Invalid item id.")
        val meta = fetchMetadata(id)
        val filesJson = meta.optJSONArray("files")
            ?: throw IllegalStateException("This item has no files on Internet Archive.")
        val files = ArrayList<IaFile>()
        for (i in 0 until filesJson.length()) {
            val f = filesJson.optJSONObject(i) ?: continue
            files += IaFile(
                name = f.optString("name"),
                sizeBytes = f.optString("size").toLongOrNull() ?: 0L,
                source = f.optString("source"),
                title = f.optString("title"),
                track = trackNumber(f.optString("track")),
                length = f.optString("length")
            )
        }
        val picks = pickMediaFiles(files)
        if (picks.isEmpty()) {
            throw IllegalStateException("No directly playable file found for this item.")
        }
        val type = picks.first().type
        // Albums, audiobooks and concerts play as a queue; a single recording stays a single file.
        val tracks = if (type == "audio") {
            pickAudioTracks(files).map { MediaTrack(it.title, "$BASE/download/$id/" + Uri.encode(it.name), it.seconds) }
        } else emptyList()
        ResolvedMedia(
            urls = picks.map { "$BASE/download/$id/" + Uri.encode(it.name) },
            type = type,
            tracks = if (tracks.size > 1) tracks else emptyList()
        )
    }

    /** Description, topics, license and viewer reviews of an item. Throws IOException when offline. */
    suspend fun details(id: String): ItemDetails = withContext(Dispatchers.IO) {
        if (!ID_RE.matches(id)) throw IllegalStateException("Invalid item id.")
        val root = fetchMetadata(id)
        val meta = root.optJSONObject("metadata") ?: JSONObject()
        val reviewsJson = root.optJSONArray("reviews")
        val reviews = ArrayList<IaReview>()
        if (reviewsJson != null) {
            for (i in 0 until reviewsJson.length()) {
                val r = reviewsJson.optJSONObject(i) ?: continue
                val body = htmlToPlain(firstString(r.opt("reviewbody")))
                if (body.isBlank()) continue
                reviews += IaReview(
                    author = firstString(r.opt("reviewer")).ifBlank { "Anonymous" },
                    title = htmlToPlain(firstString(r.opt("reviewtitle"))),
                    body = body,
                    stars = firstString(r.opt("stars")).toIntOrNull()?.coerceIn(0, 5) ?: 0,
                    date = (firstString(r.opt("reviewdate")).ifBlank { firstString(r.opt("createdate")) }).take(10)
                )
            }
        }
        ItemDetails(
            description = htmlToPlain(allStrings(meta.opt("description")).joinToString("\n\n")),
            creator = allStrings(meta.opt("creator")).joinToString(", "),
            date = firstString(meta.opt("date")).ifBlank { firstString(meta.opt("publicdate")) }.take(10),
            license = licenseLabel(firstString(meta.opt("licenseurl"))),
            subjects = splitSubjects(allStrings(meta.opt("subject"))),
            collections = allStrings(meta.opt("collection")),
            reviews = reviews.sortedByDescending { it.date }
        )
    }

    /** Up to [limit] other items on the same topic or in the same collection. */
    suspend fun related(id: String, details: ItemDetails, limit: Int = 12): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val q = buildRelatedQuery(id, details.subjects, details.collections) ?: return@withContext emptyList()
            advancedSearch(q, 1, "downloads desc", limit)
        }

    private fun advancedSearch(q: String, page: Int, sort: String, rows: Int): List<MediaItem> {
        val builder = "$BASE/advancedsearch.php".toHttpUrl().newBuilder()
            .addQueryParameter("q", q)
        for (field in listOf("identifier", "title", "creator", "mediatype", "runtime")) {
            builder.addQueryParameter("fl[]", field)
        }
        val url = builder
            .addQueryParameter("sort[]", sort)
            .addQueryParameter("rows", rows.toString())
            .addQueryParameter("page", maxOf(1, page).toString())
            .addQueryParameter("output", "json")
            .build()
        val docs = getJson(url).optJSONObject("response")?.optJSONArray("docs") ?: return emptyList()
        val items = ArrayList<MediaItem>()
        for (i in 0 until docs.length()) {
            val doc = docs.optJSONObject(i) ?: continue
            docToItem(doc)?.let { items += it }
        }
        return items
    }

    private fun docToItem(doc: JSONObject): MediaItem? {
        val id = firstString(doc.opt("identifier"))
        if (!ID_RE.matches(id)) return null
        val mediaType = firstString(doc.opt("mediatype"))
        return MediaItem(
            id = id,
            title = firstString(doc.opt("title")).ifBlank { id },
            uploader = firstString(doc.opt("creator")).ifBlank { "Internet Archive" },
            thumbnailUrl = "$BASE/services/img/$id",
            duration = formatRuntime(firstString(doc.opt("runtime"))) ?: "",
            source = "Internet Archive",
            sourceId = SOURCE_ID,
            mediaType = if (mediaType == "audio") "audio" else "video",
            pageUrl = "$BASE/details/$id"
        )
    }

    /** Internet Archive fields are sometimes a string and sometimes a list of strings. */
    private fun firstString(value: Any?): String = when (value) {
        null -> ""
        JSONObject.NULL -> ""
        is JSONArray -> if (value.length() > 0) firstString(value.opt(0)) else ""
        else -> value.toString()
    }

    /** Every string of a field that may be a string or a list of strings. */
    private fun allStrings(value: Any?): List<String> = when (value) {
        null -> emptyList()
        JSONObject.NULL -> emptyList()
        is JSONArray -> (0 until value.length()).flatMap { allStrings(value.opt(it)) }
        else -> listOf(value.toString()).filter { it.isNotBlank() }
    }

    private fun getJson(url: HttpUrl): JSONObject {
        val request = Request.Builder().url(url).header("User-Agent", USER_AGENT).get().build()
        return sharedHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Internet Archive returned HTTP ${response.code}")
            val body = response.body?.string().orEmpty()
            JSONObject(body.ifBlank { "{}" })
        }
    }
}
