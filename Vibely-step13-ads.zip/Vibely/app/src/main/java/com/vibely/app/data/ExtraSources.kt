package com.vibely.app.data

import com.vibely.app.BuildConfig
import com.vibely.app.MediaItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/*
 * Extra video sources that sit NEXT TO Internet Archive (Internet Archive code is untouched).
 *
 * Every source below is read straight from the phone. Where a site offers a public API we use it;
 * where it does not (Mixkit, Rumble) the page HTML is read ("web scraping"). All scraping is polite:
 * robots.txt is honoured, requests to one site are spaced out, answers are cached by VibelyRepository,
 * and one site failing never breaks the others.
 *
 * Some sites give no direct video file (Dailymotion, Vimeo, and Rumble/Odysee/PeerTube when no file is exposed).
 * Those videos are played INSIDE Vibely through the site's own web player (see EmbedPlayer.kt); nothing opens
 * in the browser. For Rumble, Odysee and PeerTube the web player is also the automatic fallback when the
 * direct file does not play.
 */

private const val PER_SOURCE = 5
private const val EXTRA_UA =
    "Mozilla/5.0 (Linux; Android 14; Vibely) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36 Vibely/0.12"

private val DEFAULT_TOPICS = listOf(
    "nature", "music", "science", "travel", "animals", "art", "technology", "documentary", "city", "food"
)

/** Home has no search text; sources without a "newest" feed are asked about a rotating topic instead. */
internal fun defaultTopic(page: Int): String = DEFAULT_TOPICS[(maxOf(1, page) - 1) % DEFAULT_TOPICS.size]

private val extraClient: OkHttpClient by lazy {
    sharedHttpClient.newBuilder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()
}

private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

// ---------------------------------------------------------------------------------------------
// Polite fetching: robots.txt + spacing between requests to the same site
// ---------------------------------------------------------------------------------------------

private object Politeness {
    private val last = HashMap<String, Long>()
    private val robots = HashMap<String, String>() // "" = no robots.txt / unreachable (everything allowed)

    fun waitTurn(host: String) {
        val delay = synchronized(this) {
            val now = System.currentTimeMillis()
            val next = maxOf(now, (last[host] ?: 0L) + 400L)
            last[host] = next
            next - now
        }
        if (delay > 0) Thread.sleep(delay)
    }

    fun allowed(url: HttpUrl): Boolean {
        val host = url.host
        val cached = synchronized(this) { robots[host] }
        val text = cached ?: run {
            val fetched = try {
                extraClient.newCall(
                    Request.Builder().url("https://$host/robots.txt").header("User-Agent", EXTRA_UA).get().build()
                ).execute().use { r -> if (r.isSuccessful) r.body?.string().orEmpty().take(200_000) else "" }
            } catch (e: Exception) {
                ""
            }
            synchronized(this) { robots[host] = fetched }
            fetched
        }
        val path = url.encodedPath + (url.encodedQuery?.let { "?$it" } ?: "")
        return robotsAllows(text, path)
    }
}

/** Minimal robots.txt reader: rules of "User-agent: *", longest matching rule wins, Allow beats Disallow on a tie. */
internal fun robotsAllows(robotsTxt: String, path: String): Boolean {
    var inStar = false
    var prevWasAgent = false
    val rules = ArrayList<Pair<Boolean, String>>() // (allow?, pattern)
    for (raw in robotsTxt.lines()) {
        val line = raw.substringBefore('#').trim()
        val idx = line.indexOf(':')
        if (line.isEmpty() || idx < 0) continue
        val key = line.substring(0, idx).trim().lowercase()
        val value = line.substring(idx + 1).trim()
        when (key) {
            "user-agent" -> {
                if (!prevWasAgent) inStar = false
                if (value == "*") inStar = true
                prevWasAgent = true
            }
            "allow", "disallow" -> {
                prevWasAgent = false
                if (inStar && value.isNotEmpty()) rules += Pair(key == "allow", value)
            }
            else -> prevWasAgent = false
        }
    }
    var best: Pair<Boolean, String>? = null
    for (rule in rules) {
        if (!robotsPatternMatches(rule.second, path)) continue
        val current = best
        if (current == null || rule.second.length > current.second.length ||
            (rule.second.length == current.second.length && rule.first)
        ) best = rule
    }
    return best?.first ?: true
}

private fun robotsPatternMatches(pattern: String, path: String): Boolean {
    val anchored = pattern.endsWith("$")
    val body = if (anchored) pattern.dropLast(1) else pattern
    val regex = "^" + body.split("*").joinToString(".*") { Regex.escape(it) } + (if (anchored) "\$" else "")
    return Regex(regex).containsMatchIn(path)
}

/** GET (or POST json) as text. [scrape] = true means "this is a web page, check robots.txt first". */
internal fun fetchText(
    url: String,
    scrape: Boolean = false,
    headers: Map<String, String> = emptyMap(),
    jsonBody: String? = null
): String {
    val http = url.toHttpUrl()
    if (scrape && !Politeness.allowed(http)) throw IOException("${http.host} does not allow automatic reading of this page")
    Politeness.waitTurn(http.host)
    val builder = Request.Builder().url(http).header("User-Agent", EXTRA_UA).header("Accept-Language", "en")
    headers.forEach { (k, v) -> builder.header(k, v) }
    if (jsonBody != null) builder.post(jsonBody.toRequestBody("application/json".toMediaType())) else builder.get()
    return extraClient.newCall(builder.build()).execute().use { r ->
        if (!r.isSuccessful) throw IOException("${http.host} returned HTTP ${r.code}")
        r.body?.string().orEmpty()
    }
}

// ---------------------------------------------------------------------------------------------
// Shared pieces
// ---------------------------------------------------------------------------------------------

internal interface ExtraSource {
    val id: String
    val name: String
    /** Sources that need a (free) key are switched off until the key is present in the build. */
    val enabled: Boolean get() = true

    fun search(query: String, page: Int): List<MediaItem>
    fun latest(page: Int): List<MediaItem>

    /** Direct playable URLs, best first. Throws IllegalStateException (readable message) when not possible. */
    fun resolve(id: String): ResolvedMedia
}

/** Web player pages that are shown inside Vibely (WebView) when a site gives no direct video file. */
internal fun dailymotionEmbed(id: String) = "https://www.dailymotion.com/embed/video/$id?autoplay=1"
internal fun vimeoEmbed(id: String) = "https://player.vimeo.com/video/$id?autoplay=1"
internal fun rumbleEmbed(embedId: String) = "https://rumble.com/embed/$embedId/"
internal fun odyseeEmbed(name: String, claimId: String) = "https://odysee.com/\$/embed/${enc(name)}/$claimId"
internal fun peerTubeEmbed(host: String, uuid: String) = "https://$host/videos/embed/$uuid?autoplay=1"

private fun embedOnly(embedUrl: String) = ResolvedMedia(emptyList(), "video", embedUrl = embedUrl)

private fun mediaItem(
    sourceId: String,
    source: String,
    id: String,
    title: String,
    uploader: String,
    thumbnail: String?,
    seconds: Int?,
    pageUrl: String?,
    mediaUrl: String? = null,
    durationText: String? = null
) = MediaItem(
    id = id,
    title = title.trim().ifBlank { "Untitled" },
    uploader = uploader.trim().ifBlank { source },
    thumbnailUrl = thumbnail?.takeIf { it.startsWith("http") },
    duration = durationText ?: seconds?.takeIf { it > 0 }?.let { formatRuntime(it.toString()) } ?: "",
    source = source,
    sourceId = sourceId,
    mediaType = "video",
    pageUrl = pageUrl,
    mediaUrl = mediaUrl
)

internal fun titleFromSlug(slug: String): String {
    val s = slug.trim('/').substringAfterLast('/').replace(Regex("-\\d+$"), "").replace('-', ' ').trim()
    return s.replaceFirstChar { it.uppercase() }
}

/** Round-robin merge, so one busy site cannot fill the whole screen. Duplicates are dropped. */
internal fun interleave(lists: List<List<MediaItem>>): List<MediaItem> {
    val out = ArrayList<MediaItem>()
    val seen = HashSet<String>()
    var i = 0
    while (lists.any { i < it.size }) {
        for (l in lists) if (i < l.size && seen.add(l[i].key)) out += l[i]
        i++
    }
    return out
}

/** Puts one extra item after every [every] Internet Archive items (extras left over go at the end). */
internal fun mixIn(base: List<MediaItem>, extras: List<MediaItem>, every: Int = 3): List<MediaItem> {
    if (extras.isEmpty()) return base
    val out = ArrayList<MediaItem>()
    val seen = HashSet<String>()
    var next = 0
    base.forEachIndexed { index, item ->
        if (seen.add(item.key)) out += item
        if ((index + 1) % every == 0 && next < extras.size) {
            val e = extras[next++]
            if (seen.add(e.key)) out += e
        }
    }
    while (next < extras.size) {
        val e = extras[next++]
        if (seen.add(e.key)) out += e
    }
    return out
}

/** Sorts quality numbers so that the best one up to 720p comes first, then the bigger ones. */
private fun qualityOrder(height: Int): Int = if (height in 1..720) 720 - height else 10_000 + height

// ---------------------------------------------------------------------------------------------
// The registry
// ---------------------------------------------------------------------------------------------

object ExtraSources {
    internal val all: List<ExtraSource> = listOf(
        PeerTubeSource(),
        WikimediaSource(),
        // With a key the official API is used (more reliable); without a key the website is read instead.
        if (BuildConfig.PEXELS_API_KEY.isNotBlank()) PexelsSource(BuildConfig.PEXELS_API_KEY) else PexelsWebSource(),
        if (BuildConfig.PIXABAY_API_KEY.isNotBlank()) PixabaySource(BuildConfig.PIXABAY_API_KEY) else PixabayWebSource(),
        MixkitSource(),
        RumbleSource(),
        OdyseeSource(),
        DailymotionSource(),
        if (BuildConfig.VIMEO_ACCESS_TOKEN.isNotBlank()) VimeoSource(BuildConfig.VIMEO_ACCESS_TOKEN) else VimeoWebSource()
    )

    internal fun byId(id: String): ExtraSource? = all.firstOrNull { it.id == id }

    suspend fun search(query: String, page: Int): List<MediaItem> {
        val q = query.trim().take(100)
        return if (q.isEmpty()) emptyList() else fanOut { it.search(q, page) }
    }

    suspend fun latest(page: Int): List<MediaItem> = fanOut { it.latest(page) }

    /** Asks every enabled source at the same time. A source that fails or is slow is simply left out. */
    private suspend fun fanOut(call: (ExtraSource) -> List<MediaItem>): List<MediaItem> = coroutineScope {
        val results = all.filter { it.enabled }.map { source ->
            async(Dispatchers.IO) {
                try {
                    call(source)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    emptyList<MediaItem>()
                }
            }
        }.awaitAll()
        interleave(results)
    }
}

// ---------------------------------------------------------------------------------------------
// PeerTube (diode.zone) - official public API, plays directly (mp4 or HLS)
// ---------------------------------------------------------------------------------------------

private val PEERTUBE_ID = Regex("^[A-Za-z0-9-]{8,40}$")

internal fun parsePeerTube(json: String, host: String): List<MediaItem> {
    val data = JSONObject(json).optJSONArray("data") ?: return emptyList()
    val out = ArrayList<MediaItem>()
    for (i in 0 until data.length()) {
        val v = data.optJSONObject(i) ?: continue
        if (v.optBoolean("isLive", false)) continue
        val uuid = v.optString("uuid")
        if (!PEERTUBE_ID.matches(uuid)) continue
        val channel = v.optJSONObject("channel")?.optString("displayName").orEmpty()
        val account = v.optJSONObject("account")?.optString("displayName").orEmpty()
        val thumb = v.optString("thumbnailPath").takeIf { it.startsWith("/") }?.let { "https://$host$it" }
        out += mediaItem(
            "peertube", "PeerTube", uuid, v.optString("name"), channel.ifBlank { account }, thumb,
            v.optInt("duration", 0), v.optString("url").ifBlank { "https://$host/w/$uuid" }
        )
    }
    return out
}

internal fun peerTubeStreamUrls(json: String): List<String> {
    val root = JSONObject(json)
    val urls = ArrayList<String>()
    val files = root.optJSONArray("files")
    if (files != null) {
        (0 until files.length()).mapNotNull { files.optJSONObject(it) }
            .filter { it.optString("fileUrl").startsWith("https://") }
            .sortedBy { qualityOrder(it.optJSONObject("resolution")?.optInt("id", 0) ?: 0) }
            .forEach { urls += it.optString("fileUrl") }
    }
    val playlists = root.optJSONArray("streamingPlaylists")
    if (playlists != null) {
        for (i in 0 until playlists.length()) {
            val p = playlists.optJSONObject(i)?.optString("playlistUrl").orEmpty()
            if (p.startsWith("https://")) urls += p
        }
    }
    return urls
}

internal class PeerTubeSource(private val host: String = "diode.zone") : ExtraSource {
    override val id = "peertube"
    override val name = "PeerTube"
    private val base get() = "https://$host"

    override fun search(query: String, page: Int): List<MediaItem> = parsePeerTube(
        fetchText("$base/api/v1/search/videos?search=${enc(query)}&start=${(page - 1) * PER_SOURCE}&count=$PER_SOURCE&nsfw=false&sort=-match"),
        host
    )

    override fun latest(page: Int): List<MediaItem> = parsePeerTube(
        fetchText("$base/api/v1/videos?start=${(page - 1) * PER_SOURCE}&count=$PER_SOURCE&sort=-publishedAt&nsfw=false"),
        host
    )

    override fun resolve(id: String): ResolvedMedia {
        if (!PEERTUBE_ID.matches(id)) throw IllegalStateException("Invalid PeerTube video.")
        val urls = peerTubeStreamUrls(fetchText("$base/api/v1/videos/$id"))
        return ResolvedMedia(urls, "video", embedUrl = peerTubeEmbed(host, id))
    }
}

// ---------------------------------------------------------------------------------------------
// Wikimedia Commons - official MediaWiki API, direct .webm/.mp4 files
// ---------------------------------------------------------------------------------------------

internal fun parseWikimedia(json: String): List<MediaItem> {
    val pages = JSONObject(json).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
    val entries = pages.keys().asSequence().mapNotNull { pages.optJSONObject(it) }.sortedBy { it.optInt("index", 0) }.toList()
    val out = ArrayList<MediaItem>()
    for (p in entries) {
        val title = p.optString("title")
        val info = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
        val mime = info.optString("mime")
        val url = info.optString("url")
        // ExoPlayer on Android plays webm/mp4; Ogg Theora (.ogv) is skipped.
        if ((mime != "video/webm" && mime != "video/mp4") || !url.startsWith("https://")) continue
        val artist = Jsoup.parse(info.optJSONObject("extmetadata")?.optJSONObject("Artist")?.optString("value").orEmpty()).text()
        val page = "https://commons.wikimedia.org/wiki/" + enc(title.replace(' ', '_'))
        out += mediaItem(
            "wikimedia", "Wikimedia Commons", title,
            title.removePrefix("File:").substringBeforeLast('.').replace('_', ' '),
            artist, info.optString("thumburl"), null, page, mediaUrl = url
        )
    }
    return out
}

internal class WikimediaSource : ExtraSource {
    override val id = "wikimedia"
    override val name = "Wikimedia Commons"
    private val api = "https://commons.wikimedia.org/w/api.php"

    private fun fetchPage(search: String, page: Int, sort: String): String =
        fetchText(
            "$api?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=15&gsroffset=${(page - 1) * 15}" +
                "&gsrsort=$sort&gsrsearch=${enc("$search filetype:video")}" +
                "&prop=imageinfo&iiprop=${enc("url|mime|extmetadata")}&iiurlwidth=480&iiextmetadatafilter=Artist"
        )

    override fun search(query: String, page: Int) = parseWikimedia(fetchPage(query, page, "relevance")).take(PER_SOURCE)

    override fun latest(page: Int) = parseWikimedia(fetchPage("", page, "create_timestamp_desc")).take(PER_SOURCE)

    override fun resolve(id: String): ResolvedMedia {
        val json = fetchText(
            "$api?action=query&format=json&prop=imageinfo&iiprop=${enc("url|mime")}&titles=${enc(id)}"
        )
        val pages = JSONObject(json).optJSONObject("query")?.optJSONObject("pages")
            ?: throw IllegalStateException("This Wikimedia video has no playable file.")
        val first = pages.keys().asSequence().firstOrNull()?.let { pages.optJSONObject(it) }
        val url = first?.optJSONArray("imageinfo")?.optJSONObject(0)?.optString("url").orEmpty()
        if (!url.startsWith("https://")) throw IllegalStateException("This Wikimedia video has no playable file.")
        return ResolvedMedia(listOf(url), "video")
    }
}

// ---------------------------------------------------------------------------------------------
// Pexels and Pixabay - official APIs, free key needed (see README), direct mp4
// ---------------------------------------------------------------------------------------------

internal fun parsePexels(json: String): List<MediaItem> {
    val videos = JSONObject(json).optJSONArray("videos") ?: return emptyList()
    val out = ArrayList<MediaItem>()
    for (i in 0 until videos.length()) {
        val v = videos.optJSONObject(i) ?: continue
        val files = v.optJSONArray("video_files") ?: continue
        val best = (0 until files.length()).mapNotNull { files.optJSONObject(it) }
            .filter { it.optString("file_type") == "video/mp4" && it.optString("link").startsWith("https://") }
            .sortedBy { qualityOrder(it.optInt("height", 0)) }
            .firstOrNull() ?: continue
        val page = v.optString("url")
        out += mediaItem(
            "pexels", "Pexels", v.optLong("id").toString(), titleFromSlug(page),
            v.optJSONObject("user")?.optString("name").orEmpty(), v.optString("image"),
            v.optInt("duration", 0), page, mediaUrl = best.optString("link")
        )
    }
    return out
}

internal class PexelsSource(private val key: String) : ExtraSource {
    override val id = "pexels"
    override val name = "Pexels"
    override val enabled get() = key.isNotBlank()
    private val auth get() = mapOf("Authorization" to key)

    override fun search(query: String, page: Int) = parsePexels(
        fetchText("https://api.pexels.com/videos/search?query=${enc(query)}&per_page=$PER_SOURCE&page=$page", headers = auth)
    )

    override fun latest(page: Int) = parsePexels(
        fetchText("https://api.pexels.com/videos/popular?per_page=$PER_SOURCE&page=$page", headers = auth)
    )

    override fun resolve(id: String): ResolvedMedia {
        if (!id.all { it.isDigit() }) throw IllegalStateException("Invalid Pexels video.")
        val v = JSONObject(fetchText("https://api.pexels.com/videos/videos/$id", headers = auth))
        val item = parsePexels(JSONObject().put("videos", JSONArray().put(v)).toString()).firstOrNull()
        val url = item?.mediaUrl ?: throw IllegalStateException("This Pexels video has no playable file.")
        return ResolvedMedia(listOf(url), "video")
    }
}

internal fun parsePixabay(json: String): List<MediaItem> {
    val hits = JSONObject(json).optJSONArray("hits") ?: return emptyList()
    val out = ArrayList<MediaItem>()
    for (i in 0 until hits.length()) {
        val h = hits.optJSONObject(i) ?: continue
        val sizes = h.optJSONObject("videos") ?: continue
        val pick = listOf("medium", "small", "tiny", "large").mapNotNull { sizes.optJSONObject(it) }
            .firstOrNull { it.optString("url").startsWith("https://") } ?: continue
        val title = h.optString("tags").split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(3)
            .joinToString(", ").replaceFirstChar { it.uppercase() }
        out += mediaItem(
            "pixabay", "Pixabay", h.optLong("id").toString(), title, h.optString("user"),
            pick.optString("thumbnail"), h.optInt("duration", 0), h.optString("pageURL"),
            mediaUrl = pick.optString("url")
        )
    }
    return out
}

internal class PixabaySource(private val key: String) : ExtraSource {
    override val id = "pixabay"
    override val name = "Pixabay"
    override val enabled get() = key.isNotBlank()

    private fun call(query: String, page: Int, order: String) = parsePixabay(
        fetchText(
            "https://pixabay.com/api/videos/?key=${enc(key)}&q=${enc(query)}&per_page=${maxOf(PER_SOURCE, 3)}" +
                "&page=$page&order=$order&safesearch=true"
        )
    )

    override fun search(query: String, page: Int) = call(query, page, "popular")
    override fun latest(page: Int) = call("", page, "latest")

    override fun resolve(id: String): ResolvedMedia {
        if (!id.all { it.isDigit() }) throw IllegalStateException("Invalid Pixabay video.")
        val url = parsePixabay(fetchText("https://pixabay.com/api/videos/?key=${enc(key)}&id=$id"))
            .firstOrNull()?.mediaUrl ?: throw IllegalStateException("This Pixabay video has no playable file.")
        return ResolvedMedia(listOf(url), "video")
    }
}

// ---------------------------------------------------------------------------------------------
// Mixkit - web scraping (no API). Item pages expose an assets.mixkit.co mp4.
// ---------------------------------------------------------------------------------------------

private val MIXKIT_ITEM = Regex("^/free-stock-video/([a-z0-9-]+-\\d+)/?$")
private val MIXKIT_MP4 = Regex("https?://assets\\.mixkit\\.co/[^\"'\\s<>\\\\]+\\.mp4")

internal fun slugify(text: String): String =
    text.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')

internal fun parseMixkit(html: String): List<MediaItem> {
    val doc = Jsoup.parse(html, "https://mixkit.co/")
    val seen = LinkedHashMap<String, MediaItem>()
    for (a in doc.select("a[href]")) {
        val path = a.attr("href").substringBefore('?').substringBefore('#').removePrefix("https://mixkit.co")
        val id = MIXKIT_ITEM.matchEntire(path)?.groupValues?.get(1) ?: continue
        if (seen.containsKey(id)) continue
        val img = a.selectFirst("img") ?: a.parent()?.selectFirst("img")
        val poster = a.selectFirst("video[poster]")?.absUrl("poster")
        val thumb = listOf(img?.absUrl("src"), img?.absUrl("data-src"), poster).firstOrNull { !it.isNullOrBlank() }
        seen[id] = mediaItem("mixkit", "Mixkit", id, titleFromSlug(id), "Mixkit", thumb, null, "https://mixkit.co$path")
    }
    return seen.values.toList()
}

/** Picks the mp4 of an item page: prefers 720p, then anything but tiny previews. */
internal fun extractMixkitMp4(html: String): List<String> {
    val all = MIXKIT_MP4.findAll(html).map { it.value.replace("\\/", "/") }.distinct().toList()
    return all.sortedBy { u ->
        when {
            u.contains("720") -> 0
            u.contains("1080") -> 1
            u.contains("480") -> 2
            else -> 3
        }
    }
}

internal class MixkitSource : ExtraSource {
    override val id = "mixkit"
    override val name = "Mixkit"

    override fun search(query: String, page: Int): List<MediaItem> {
        val slug = slugify(query)
        if (slug.isEmpty()) return emptyList()
        return parseMixkit(fetchText("https://mixkit.co/free-stock-video/$slug/?page=$page", scrape = true)).take(PER_SOURCE)
    }

    override fun latest(page: Int) =
        parseMixkit(fetchText("https://mixkit.co/free-stock-video/?page=$page", scrape = true)).take(PER_SOURCE)

    override fun resolve(id: String): ResolvedMedia {
        if (!Regex("^[a-z0-9-]+$").matches(id)) throw IllegalStateException("Invalid Mixkit video.")
        val urls = extractMixkitMp4(fetchText("https://mixkit.co/free-stock-video/$id/", scrape = true))
        if (urls.isEmpty()) throw IllegalStateException("Could not find the video file on Mixkit. Tap Retry or try another video.")
        return ResolvedMedia(urls, "video")
    }
}

// ---------------------------------------------------------------------------------------------
// Rumble - web scraping. Page listing -> embed id -> embedJS gives mp4 links when available.
// ---------------------------------------------------------------------------------------------

private val RUMBLE_LINK = Regex("^/(v[a-z0-9]{4,}-[^/\\s]*)\\.html$")
private val RUMBLE_EMBED = Regex("https://rumble\\.com/embed/([0-9a-z]+)/?")
private val DURATION_TEXT = Regex("^\\d{1,2}(:\\d{2}){1,2}$")

internal fun parseRumble(html: String): List<MediaItem> {
    val doc = Jsoup.parse(html, "https://rumble.com/")
    val seen = LinkedHashMap<String, MediaItem>()
    for (a in doc.select("a[href]")) {
        val path = a.attr("href").substringBefore('?').removePrefix("https://rumble.com")
        val id = RUMBLE_LINK.matchEntire(path)?.groupValues?.get(1) ?: continue
        if (seen.containsKey(id)) continue
        val card = a.closest(".videostream, .video-listing-entry, li") ?: a.parent() ?: a
        val title = card.selectFirst("h3")?.text().orEmpty().ifBlank { a.attr("title") }
            .ifBlank { titleFromSlug(id.substringAfter('-')) }
        val thumb = card.selectFirst("img")?.absUrl("src")
        val duration = card.selectFirst(".videostream__badge, [class*=duration]")?.text()?.trim()
            ?.takeIf { DURATION_TEXT.matches(it) }
        val channel = card.selectFirst("address")?.text().orEmpty()
        seen[id] = mediaItem("rumble", "Rumble", id, title, channel, thumb, null, "https://rumble.com/$id.html", durationText = duration)
    }
    return seen.values.toList()
}

/** Reads the mp4 links out of Rumble's embed JSON (both the "u" and the "ua" layouts). */
internal fun rumbleMp4Urls(json: String): List<String> {
    val root = JSONObject(json)
    val found = ArrayList<Pair<Int, String>>()
    for (key in listOf("ua", "u")) {
        val mp4 = root.optJSONObject(key)?.optJSONObject("mp4") ?: continue
        val single = mp4.optString("url")
        if (single.startsWith("https://")) found += Pair(mp4.optJSONObject("meta")?.optInt("h", 0) ?: 0, single)
        for (k in mp4.keys()) {
            val e = mp4.optJSONObject(k) ?: continue
            val u = e.optString("url")
            if (u.startsWith("https://")) found += Pair(k.toIntOrNull() ?: e.optJSONObject("meta")?.optInt("h", 0) ?: 0, u)
        }
    }
    return found.sortedBy { qualityOrder(it.first) }.map { it.second }.distinct()
}

internal class RumbleSource : ExtraSource {
    override val id = "rumble"
    override val name = "Rumble"

    private fun list(query: String, page: Int, newest: Boolean) = parseRumble(
        fetchText("https://rumble.com/search/video?q=${enc(query)}&page=$page" + (if (newest) "&sort=date" else ""), scrape = true)
    ).take(PER_SOURCE)

    override fun search(query: String, page: Int) = list(query, page, newest = false)
    override fun latest(page: Int) = list(defaultTopic(page), 1, newest = true)

    override fun resolve(id: String): ResolvedMedia {
        if (!Regex("^v[a-z0-9]{4,}-[^/\\s]*$").matches(id)) throw IllegalStateException("Invalid Rumble video.")
        val embedId = RUMBLE_EMBED.find(fetchText("https://rumble.com/$id.html", scrape = true))?.groupValues?.get(1)
            ?: throw IllegalStateException("Could not find the Rumble player for this video.")
        val urls = try {
            rumbleMp4Urls(fetchText("https://rumble.com/embedJS/u3/?request=video&ver=2&v=$embedId", scrape = true))
        } catch (e: Exception) {
            emptyList() // the web player below still works
        }
        return ResolvedMedia(urls, "video", embedUrl = rumbleEmbed(embedId))
    }
}

// ---------------------------------------------------------------------------------------------
// Odysee - public search (lighthouse) + LBRY resolve API; the mp4 stream is built from the claim
// ---------------------------------------------------------------------------------------------

private const val ODYSEE_API = "https://api.na-backend.odysee.com/api/v1/proxy?m=resolve"
private val CLAIM_ID = Regex("^[0-9a-f]{40}$")

internal fun parseOdyseeResolve(json: String): List<MediaItem> {
    val result = JSONObject(json).optJSONObject("result") ?: return emptyList()
    val out = ArrayList<MediaItem>()
    for (key in result.keys()) {
        val c = result.optJSONObject(key) ?: continue
        val claimId = c.optString("claim_id")
        val name = c.optString("name")
        if (!CLAIM_ID.matches(claimId) || name.isEmpty()) continue
        val value = c.optJSONObject("value") ?: continue
        val channel = c.optJSONObject("signing_channel")
        val uploader = channel?.optJSONObject("value")?.optString("title").orEmpty()
            .ifBlank { channel?.optString("name").orEmpty() }
        out += mediaItem(
            "odysee", "Odysee", "$claimId:$name", value.optString("title").ifBlank { name }, uploader,
            value.optJSONObject("thumbnail")?.optString("url"),
            value.optJSONObject("video")?.optInt("duration", 0), "https://odysee.com/$name:${claimId.take(6)}"
        )
    }
    return out
}

internal fun odyseeStreamUrl(name: String, claimId: String, sdHash: String): String =
    "https://player.odycdn.com/api/v3/streams/free/${enc(name)}/$claimId/${sdHash.take(6)}.mp4"

internal class OdyseeSource : ExtraSource {
    override val id = "odysee"
    override val name = "Odysee"

    private fun resolveClaims(pairs: List<Pair<String, String>>): String {
        val urls = JSONArray().also { arr -> pairs.forEach { (claimId, claimName) -> arr.put("lbry://$claimName#$claimId") } }
        val body = JSONObject().put("jsonrpc", "2.0").put("method", "resolve").put("id", 1)
            .put("params", JSONObject().put("urls", urls)).toString()
        return fetchText(ODYSEE_API, jsonBody = body)
    }

    private fun find(query: String, page: Int): List<MediaItem> {
        val hits = JSONArray(
            fetchText(
                "https://lighthouse.odysee.tv/search?s=${enc(query)}&size=$PER_SOURCE&from=${(page - 1) * PER_SOURCE}" +
                    "&claimType=file&mediaType=video&nsfw=false&free_only=true"
            )
        )
        val pairs = (0 until hits.length()).mapNotNull { hits.optJSONObject(it) }
            .map { it.optString("claimId") to it.optString("name") }
            .filter { CLAIM_ID.matches(it.first) && it.second.isNotEmpty() }
        return if (pairs.isEmpty()) emptyList() else parseOdyseeResolve(resolveClaims(pairs))
    }

    override fun search(query: String, page: Int) = find(query, page)
    override fun latest(page: Int) = find(defaultTopic(page), 1)

    override fun resolve(id: String): ResolvedMedia {
        val claimId = id.substringBefore(':')
        val claimName = id.substringAfter(':', "")
        if (!CLAIM_ID.matches(claimId) || claimName.isEmpty()) throw IllegalStateException("Invalid Odysee video.")
        val claim = JSONObject(resolveClaims(listOf(claimId to claimName))).optJSONObject("result")
            ?.optJSONObject("lbry://$claimName#$claimId")
        val sdHash = claim?.optJSONObject("value")?.optJSONObject("source")?.optString("sd_hash").orEmpty()
        val urls = if (sdHash.length >= 6) listOf(odyseeStreamUrl(claimName, claimId, sdHash)) else emptyList()
        return ResolvedMedia(urls, "video", embedUrl = odyseeEmbed(claimName, claimId))
    }
}

// ---------------------------------------------------------------------------------------------
// Dailymotion - public API for listing; videos play on dailymotion.com
// ---------------------------------------------------------------------------------------------

private val DAILYMOTION_ID = Regex("^[a-z0-9]{5,12}$")

internal fun parseDailymotion(json: String): List<MediaItem> {
    val list = JSONObject(json).optJSONArray("list") ?: return emptyList()
    val out = ArrayList<MediaItem>()
    for (i in 0 until list.length()) {
        val v = list.optJSONObject(i) ?: continue
        val id = v.optString("id")
        if (!DAILYMOTION_ID.matches(id)) continue
        out += mediaItem(
            "dailymotion", "Dailymotion", id, v.optString("title"), v.optString("owner.screenname"),
            v.optString("thumbnail_360_url"), v.optInt("duration", 0),
            v.optString("url").ifBlank { "https://www.dailymotion.com/video/$id" }
        )
    }
    return out
}

internal class DailymotionSource : ExtraSource {
    override val id = "dailymotion"
    override val name = "Dailymotion"
    private val fields = "id,title,owner.screenname,thumbnail_360_url,duration,url"

    private fun call(extra: String, page: Int) = parseDailymotion(
        fetchText("https://api.dailymotion.com/videos?fields=${enc(fields)}&limit=$PER_SOURCE&page=$page&family_filter=true$extra")
    )

    override fun search(query: String, page: Int) = call("&sort=relevance&search=${enc(query)}", page)
    override fun latest(page: Int) = call("&sort=recent", page)
    override fun resolve(id: String): ResolvedMedia {
        if (!DAILYMOTION_ID.matches(id)) throw IllegalStateException("Invalid Dailymotion video.")
        return embedOnly(dailymotionEmbed(id))
    }
}

// ---------------------------------------------------------------------------------------------
// Vimeo - official API, needs a free access token; videos play on vimeo.com
// ---------------------------------------------------------------------------------------------

internal fun parseVimeo(json: String): List<MediaItem> {
    val data = JSONObject(json).optJSONArray("data") ?: return emptyList()
    val out = ArrayList<MediaItem>()
    for (i in 0 until data.length()) {
        val v = data.optJSONObject(i) ?: continue
        val id = v.optString("uri").substringAfterLast('/')
        if (id.isEmpty() || !id.all { it.isDigit() }) continue
        val sizes = v.optJSONObject("pictures")?.optJSONArray("sizes")
        val thumb = sizes?.let { arr ->
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                .sortedBy { kotlin.math.abs(it.optInt("width", 0) - 640) }.firstOrNull()?.optString("link")
        }
        out += mediaItem(
            "vimeo", "Vimeo", id, v.optString("name"), v.optJSONObject("user")?.optString("name").orEmpty(),
            thumb, v.optInt("duration", 0), v.optString("link").ifBlank { "https://vimeo.com/$id" }
        )
    }
    return out
}

internal class VimeoSource(private val token: String) : ExtraSource {
    override val id = "vimeo"
    override val name = "Vimeo"
    override val enabled get() = token.isNotBlank()
    private val headers get() = mapOf("Authorization" to "bearer $token", "Accept" to "application/vnd.vimeo.*+json;version=3.4")

    private fun call(query: String, page: Int, sort: String) = parseVimeo(
        fetchText("https://api.vimeo.com/videos?query=${enc(query)}&per_page=$PER_SOURCE&page=$page&sort=$sort", headers = headers)
    )

    override fun search(query: String, page: Int) = call(query, page, "relevant")
    override fun latest(page: Int) = call(defaultTopic(page), 1, "date")
    override fun resolve(id: String): ResolvedMedia {
        if (id.isEmpty() || !id.all { it.isDigit() }) throw IllegalStateException("Invalid Vimeo video.")
        return embedOnly(vimeoEmbed(id))
    }
}


// ---------------------------------------------------------------------------------------------
// Keyless web scraping for Pexels, Pixabay and Vimeo (used only when no API key is in the build).
// These pages are not documented for apps, so the readers are defensive: if a site changes its
// layout, blocks bots, or its robots.txt says no, that source just returns nothing.
// ---------------------------------------------------------------------------------------------

private val PEXELS_VIDEO = Regex("^/video/([a-z0-9-]+-\\d+)/?$")
private val PEXELS_MP4 =
    Regex("https://(?:videos\\.pexels\\.com/video-files|player\\.vimeo\\.com/external)/[^\"'\\s<>\\\\]+?\\.mp4[^\"'\\s<>\\\\]*")
private val PIXABAY_VIDEO = Regex("^/videos/([a-z0-9-]+-\\d+)/?$")
private val PIXABAY_MP4 = Regex("https://cdn\\.pixabay\\.com/video/[^\"'\\s<>\\\\]+?\\.mp4")
private val VIMEO_HREF = Regex("^(?:https://vimeo\\.com)?(?:/channels/[A-Za-z0-9_-]+)?/(\\d{6,12})/?$")

private fun unescapeJsonUrls(html: String): String =
    html.replace("\\u002F", "/").replace("\\/", "/").replace("&amp;", "&")

private fun linkedThumbnail(a: org.jsoup.nodes.Element): String? {
    val img = a.selectFirst("img") ?: a.parent()?.selectFirst("img")
    return listOf(img?.absUrl("src"), img?.absUrl("data-src"), a.selectFirst("video[poster]")?.absUrl("poster"))
        .firstOrNull { !it.isNullOrBlank() }
}

internal fun parsePexelsPage(html: String): List<MediaItem> {
    val doc = Jsoup.parse(html, "https://www.pexels.com/")
    val seen = LinkedHashMap<String, MediaItem>()
    for (a in doc.select("a[href]")) {
        val path = a.attr("href").substringBefore('?').substringBefore('#').removePrefix("https://www.pexels.com")
        val id = PEXELS_VIDEO.matchEntire(path)?.groupValues?.get(1) ?: continue
        if (seen.containsKey(id)) continue
        seen[id] = mediaItem("pexels", "Pexels", id, titleFromSlug(id), "Pexels", linkedThumbnail(a), null, "https://www.pexels.com/video/$id/")
    }
    return seen.values.toList()
}

/** mp4 links found on a Pexels video page: about 720p first, 4K last. */
internal fun extractPexelsMp4(html: String): List<String> =
    PEXELS_MP4.findAll(unescapeJsonUrls(html)).map { it.value }.distinct().sortedBy { u ->
        when {
            u.contains("1280") || u.contains("720") || u.contains(".hd.") -> 0
            u.contains("960") || u.contains("640") || u.contains(".sd.") -> 1
            u.contains("1920") || u.contains("1080") -> 2
            else -> 3
        }
    }.toList()

internal fun parsePixabayPage(html: String): List<MediaItem> {
    val doc = Jsoup.parse(html, "https://pixabay.com/")
    val seen = LinkedHashMap<String, MediaItem>()
    for (a in doc.select("a[href]")) {
        val path = a.attr("href").substringBefore('?').substringBefore('#').removePrefix("https://pixabay.com")
        val id = PIXABAY_VIDEO.matchEntire(path)?.groupValues?.get(1) ?: continue
        if (seen.containsKey(id)) continue
        seen[id] = mediaItem("pixabay", "Pixabay", id, titleFromSlug(id), "Pixabay", linkedThumbnail(a), null, "https://pixabay.com/videos/$id/")
    }
    return seen.values.toList()
}

/** mp4 links on a Pixabay video page: medium first (good on phones), then small, large, tiny. */
internal fun extractPixabayMp4(html: String): List<String> =
    PIXABAY_MP4.findAll(unescapeJsonUrls(html)).map { it.value }.distinct().sortedBy { u ->
        when {
            u.contains("medium") -> 0
            u.contains("small") -> 1
            u.contains("large") -> 2
            else -> 3
        }
    }.toList()

internal fun parseVimeoIds(html: String): List<String> =
    Jsoup.parse(html, "https://vimeo.com/").select("a[href]").mapNotNull { a ->
        VIMEO_HREF.matchEntire(a.attr("href").substringBefore('?').substringBefore('#'))?.groupValues?.get(1)
    }.distinct()

internal fun parseVimeoOembed(json: String, id: String): MediaItem? {
    val o = JSONObject(json)
    val title = o.optString("title")
    if (title.isBlank()) return null
    return mediaItem(
        "vimeo", "Vimeo", id, title, o.optString("author_name"), o.optString("thumbnail_url"),
        o.optInt("duration", 0), "https://vimeo.com/$id"
    )
}

internal class PexelsWebSource : ExtraSource {
    override val id = "pexels"
    override val name = "Pexels"

    override fun search(query: String, page: Int): List<MediaItem> {
        val slug = slugify(query)
        if (slug.isEmpty()) return emptyList()
        return parsePexelsPage(fetchText("https://www.pexels.com/search/videos/$slug/?page=$page", scrape = true)).take(PER_SOURCE)
    }

    override fun latest(page: Int) = search(defaultTopic(page), 1)

    override fun resolve(id: String): ResolvedMedia {
        if (!Regex("^[a-z0-9-]*\\d+$").matches(id)) throw IllegalStateException("Invalid Pexels video.")
        val urls = extractPexelsMp4(fetchText("https://www.pexels.com/video/$id/", scrape = true))
        if (urls.isEmpty()) throw IllegalStateException("Could not find the video file on Pexels. Tap Retry or try another video.")
        return ResolvedMedia(urls, "video")
    }
}

internal class PixabayWebSource : ExtraSource {
    override val id = "pixabay"
    override val name = "Pixabay"

    override fun search(query: String, page: Int): List<MediaItem> {
        val slug = slugify(query)
        if (slug.isEmpty()) return emptyList()
        return parsePixabayPage(fetchText("https://pixabay.com/videos/search/$slug/?pagi=$page", scrape = true)).take(PER_SOURCE)
    }

    override fun latest(page: Int) = search(defaultTopic(page), 1)

    override fun resolve(id: String): ResolvedMedia {
        if (!Regex("^[a-z0-9-]*\\d+$").matches(id)) throw IllegalStateException("Invalid Pixabay video.")
        val urls = extractPixabayMp4(fetchText("https://pixabay.com/videos/$id/", scrape = true))
        if (urls.isEmpty()) throw IllegalStateException("Could not find the video file on Pixabay. Tap Retry or try another video.")
        return ResolvedMedia(urls, "video")
    }
}

/** Vimeo without a token: video ids are read from a Vimeo page, details come from Vimeo's public oEmbed endpoint. */
internal class VimeoWebSource : ExtraSource {
    override val id = "vimeo"
    override val name = "Vimeo"

    private fun describe(ids: List<String>): List<MediaItem> = ids.take(PER_SOURCE).mapNotNull { vid ->
        try {
            parseVimeoOembed(fetchText("https://vimeo.com/api/oembed.json?url=${enc("https://vimeo.com/$vid")}"), vid)
        } catch (e: Exception) {
            null // private video, embedding switched off, odd answer, or Vimeo said no
        }
    }

    override fun search(query: String, page: Int): List<MediaItem> {
        val html = fetchText("https://vimeo.com/search" + (if (page > 1) "/page:$page" else "") + "?q=${enc(query)}", scrape = true)
        return describe(parseVimeoIds(html))
    }

    override fun latest(page: Int): List<MediaItem> =
        describe(parseVimeoIds(fetchText("https://vimeo.com/channels/staffpicks/videos?page=$page", scrape = true)))

    override fun resolve(id: String): ResolvedMedia {
        if (id.isEmpty() || !id.all { it.isDigit() }) throw IllegalStateException("Invalid Vimeo video.")
        return embedOnly(vimeoEmbed(id))
    }
}
