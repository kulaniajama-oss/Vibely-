package com.vibely.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibely.app.data.CloudSync
import com.vibely.app.data.IaCategories
import com.vibely.app.data.IaCategory
import com.vibely.app.data.VibelyRepository
import com.vibely.app.data.LibraryRepository
import com.vibely.app.data.PlaybackPrefs
import com.vibely.app.data.mergePage
import com.vibely.app.data.db.VibelyDatabase
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

internal val Bg = Color(0xFF101114)
internal val SurfaceDark = Color(0xFF202126)
internal val Accent = Color(0xFFFF4545)

data class MediaItem(
    val id: String,
    val title: String,
    val uploader: String,
    val thumbnailUrl: String? = null,
    val duration: String = "",
    val source: String = "",
    val sourceId: String = "",
    val mediaType: String? = null,
    val pageUrl: String? = null,
    val mediaUrl: String? = null
) {
    /** Unique key across sources. */
    val key: String get() = "$sourceId:$id"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VibelyAds.onActivityCreate(this) // Start.io: test-ad switch + preload the first interstitial
        setContent {
            VibelyTheme {
                VibelyApp()
            }
        }
    }

    override fun onDestroy() {
        VibelyAds.onActivityDestroy()
        super.onDestroy()
    }
}

@Composable
private fun VibelyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = SurfaceDark
        ),
        content = content
    )
}

@Composable
fun VibelyApp() {
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var videos by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var activeQuery by remember { mutableStateOf<String?>(null) } // null = featured feed (or a category)
    var activeCategory by remember { mutableStateOf<IaCategory?>(null) } // set while a category chip is selected
    var page by remember { mutableIntStateOf(1) }
    var hasMore by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var loadMoreFailed by remember { mutableStateOf(false) }
    val requestGeneration = remember { intArrayOf(0) } // lets a newer search override an older, slower one
    var playing by remember { mutableStateOf<MediaItem?>(null) }
    var libraryPage by remember { mutableStateOf<LibraryPage>(LibraryPage.Root) }
    val appContext = LocalContext.current.applicationContext
    var backgroundPlay by remember { mutableStateOf(PlaybackPrefs.backgroundPlay(appContext)) }
    val cloud = remember { CloudSync(appContext) }
    val library = remember { LibraryRepository(VibelyDatabase.get(appContext), cloud) }
    val account by remember { cloud.account() }.collectAsStateWithLifecycle(initialValue = null)
    var showAccount by remember { mutableStateOf(false) }
    var closeAccountOnSignIn by remember { mutableStateOf(false) } // set when sign-in was requested from a prompt
    val signedIn = account != null
    var syncing by remember { mutableStateOf(false) }
    var syncStatus by remember { mutableStateOf("") }
    val homeListState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    /** Loads page 1 of the featured feed (no query, no category), of a category, or of a search. */
    fun loadFirst(newQuery: String?, category: IaCategory? = null) {
        val generation = ++requestGeneration[0]
        activeQuery = newQuery
        activeCategory = category
        scope.launch {
            loading = true
            loadingMore = false
            loadMoreFailed = false
            message = if (newQuery == null) "Loading…" else "Searching…"
            val result = if (category != null) {
                VibelyRepository.category(category, 1)
            } else if (newQuery == null) {
                VibelyRepository.featured(1)
            } else {
                VibelyRepository.search(newQuery, 1)
            }
            if (generation != requestGeneration[0]) return@launch
            videos = result.items
            page = 1
            hasMore = result.hasMore
            message = result.message
            loading = false
        }
    }

    fun runSearch() {
        val q = query.trim()
        if (q.isNotEmpty()) loadFirst(q)
    }

    fun loadMore() {
        if (loading || loadingMore || !hasMore) return
        val generation = requestGeneration[0]
        val q = activeQuery
        val category = activeCategory
        val next = page + 1
        scope.launch {
            loadingMore = true
            loadMoreFailed = false
            val result = when {
                category != null -> VibelyRepository.category(category, next)
                q == null -> VibelyRepository.featured(next)
                else -> VibelyRepository.search(q, next)
            }
            if (generation == requestGeneration[0]) {
                if (result.failed) {
                    loadMoreFailed = true
                } else {
                    videos = mergePage(videos, result.items)
                    page = next
                    hasMore = result.hasMore
                }
            }
            loadingMore = false
        }
    }

    suspend fun doSync() {
        if (syncing) return
        syncing = true
        syncStatus = ""
        try {
            val r = library.syncNow()
            syncStatus = "Synced — ${r.likes} liked, ${r.saved} saved, ${r.history} history, ${r.playlists} playlists."
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            syncStatus = "Sync failed: ${e.message ?: "unknown error"}"
        } finally {
            syncing = false
        }
    }

    fun openSignIn() {
        closeAccountOnSignIn = true
        showAccount = true
    }

    // After signing in from a "Sign in required" prompt, go straight back to what the user was doing.
    LaunchedEffect(account?.uid) {
        if (account != null && closeAccountOnSignIn) {
            showAccount = false
            closeAccountOnSignIn = false
        }
    }

    // Sync automatically when an account is signed in (app start, sign-in).
    LaunchedEffect(account?.uid) {
        if (account != null) doSync()
    }

    // Load real featured content when the app opens.
    LaunchedEffect(Unit) { loadFirst(null) }

    // -1 = a typed search is showing, so no chip is highlighted.
    val selectedChip = when {
        activeCategory != null -> IaCategories.indexOfFirst { it.id == activeCategory?.id }
        activeQuery == null -> 0
        else -> -1
    }

    if (showAccount) {
        AccountScreen(
            cloud = cloud,
            library = library,
            account = account,
            syncing = syncing,
            syncStatus = syncStatus,
            onSyncNow = { scope.launch { doSync() } },
            onClose = {
                showAccount = false
                closeAccountOnSignIn = false
            }
        )
        return
    }
    val current = playing
    if (current != null) {
        PlayerScreen(
            item = current,
            library = library,
            backgroundPlay = backgroundPlay,
            signedIn = signedIn,
            onRequireSignIn = { openSignIn() },
            onPlayRelated = { playing = it },
            onClose = {
                playing = null
                VibelyAds.onPlayerClosed() // interstitial, only when enough videos/time have passed
            }
        )
        return
    }

    Scaffold(
        containerColor = Bg,
        topBar = {
            Column(
                Modifier.fillMaxWidth().background(Bg).padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayCircleFilled, null, tint = Accent, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Vibe", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("ly", color = Accent, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { showAccount = true }) {
                        Icon(Icons.Default.AccountCircle, "Account and sync", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    placeholder = { Text("Search videos and music…") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        IconButton(
                            enabled = query.isNotBlank(),
                            onClick = { runSearch() }
                        ) { Icon(Icons.Default.ArrowForward, "Search") }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { runSearch() }),
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Color.DarkGray
                    )
                )
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF191A1F)) {
                val tabs = listOf(
                    Icons.Default.Home to "Home",
                    Icons.Default.Favorite to "Shorts",
                    Icons.Default.VideoLibrary to "Library",
                    Icons.Default.Settings to "Settings"
                )
                tabs.forEachIndexed { index, pair ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(pair.first, contentDescription = pair.second) },
                        label = { Text(pair.second) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent,
                            selectedTextColor = Accent,
                            indicatorColor = Color(0xFF392126),
                            unselectedIconColor = Color.LightGray,
                            unselectedTextColor = Color.LightGray
                        )
                    )
                }
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> HomeContent(
                modifier = Modifier.padding(padding),
                title = activeCategory?.label ?: activeQuery?.let { "Results for “$it”" } ?: "Featured",
                videos = videos,
                loading = loading,
                loadingMore = loadingMore,
                hasMore = hasMore,
                loadMoreFailed = loadMoreFailed,
                message = message,
                selectedChip = selectedChip,
                listState = homeListState,
                onChipClick = { index ->
                    query = ""
                    val category = IaCategories[index]
                    if (category.query == null) loadFirst(null) else loadFirst(category.label, category)
                },
                onLoadMore = { loadMore() },
                onItemClick = { item -> playing = item }
            )
            1 -> ShortsContent(
                modifier = Modifier.padding(padding),
                library = library,
                signedIn = signedIn,
                onRequireSignIn = { openSignIn() }
            )
            2 -> if (signedIn) {
                LibraryTab(
                    library = library,
                    page = libraryPage,
                    onPageChange = { libraryPage = it },
                    onPlay = { item -> playing = item },
                    modifier = Modifier.padding(padding)
                )
            } else {
                GuestLibraryPrompt(modifier = Modifier.padding(padding), onSignIn = { openSignIn() })
            }
            else -> SettingsContent(
                modifier = Modifier.padding(padding),
                accountSubtitle = when {
                    !cloud.configured -> "Cloud sync not set up"
                    account != null -> account?.email ?: "Signed in"
                    else -> "Sign in to like, save and sync"
                },
                onOpenAccount = { showAccount = true },
                backgroundPlay = backgroundPlay,
                onBackgroundPlayChange = {
                    backgroundPlay = it
                    PlaybackPrefs.setBackgroundPlay(appContext, it)
                }
            )
        }
    }
}


@Composable
private fun SettingsContent(
    modifier: Modifier = Modifier,
    accountSubtitle: String,
    onOpenAccount: () -> Unit,
    backgroundPlay: Boolean,
    onBackgroundPlayChange: (Boolean) -> Unit
) {
    Column(modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Text("Settings", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Customize your Vibely experience", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        listOf(
            Triple(Icons.Default.Person, "Account", accountSubtitle),
            Triple(Icons.Default.Palette, "Appearance", "Dark theme and display"),
            Triple(Icons.Default.Language, "Language", "App language"),
            Triple(Icons.Default.PlayCircle, "Playback", "Keep playing when Vibely is in the background"),
            Triple(Icons.Default.Security, "Privacy", "Privacy and permissions"),
            Triple(Icons.Default.Source, "Media sources", "Connected permitted sources"),
            Triple(Icons.Default.Info, "About Vibely", "Version ${BuildConfig.VERSION_NAME}")
        ).forEach { (icon, title, subtitle) ->
            val rowModifier = if (title == "Playback") {
                Modifier.fillMaxWidth().toggleable(
                    value = backgroundPlay,
                    role = Role.Switch,
                    onValueChange = onBackgroundPlayChange
                )
            } else {
                Modifier.fillMaxWidth().clickable(role = Role.Button) {
                    if (title == "Account") onOpenAccount()
                }
            }
            Row(
                rowModifier.padding(vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, null, tint = Accent, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Medium)
                    Text(subtitle, color = Color.Gray, fontSize = 12.sp)
                }
                if (title == "Playback") {
                    Switch(
                        checked = backgroundPlay,
                        onCheckedChange = null, // the whole row is the toggle target (better for screen readers)
                        colors = SwitchDefaults.colors(checkedTrackColor = Accent)
                    )
                } else {
                    Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                }
            }
            HorizontalDivider(color = Color(0xFF303137))
        }
    }
}

@Composable
private fun HomeContent(
    modifier: Modifier,
    title: String,
    videos: List<MediaItem>,
    loading: Boolean,
    loadingMore: Boolean,
    hasMore: Boolean,
    loadMoreFailed: Boolean,
    message: String,
    selectedChip: Int,
    listState: LazyListState,
    onChipClick: (Int) -> Unit,
    onLoadMore: () -> Unit,
    onItemClick: (MediaItem) -> Unit
) {
    // Infinite scroll: ask for the next page when the last few items come into view.
    val nearEnd by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 3
        }
    }
    LaunchedEffect(nearEnd, hasMore, loading, loadingMore, loadMoreFailed, videos.size) {
        if (nearEnd && hasMore && !loading && !loadingMore && !loadMoreFailed) onLoadMore()
    }

    // Videos with a sponsored native-ad slot after the 3rd, then after every 6th.
    val feed = remember(videos) { buildFeed(videos, VibelyAds.enabled) }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IaCategories.forEachIndexed { index, category ->
                    FilterChip(
                        selected = index == selectedChip,
                        onClick = { onChipClick(index) },
                        label = { Text(category.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = SurfaceDark,
                            labelColor = Color.White,
                            selectedContainerColor = Accent,
                            selectedLabelColor = Color.White
                        ),
                        border = null
                    )
                }
            }
        }
        item {
            Text(
                title,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            Text(
                message,
                color = Color.LightGray,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            if (loading) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    color = Accent
                )
            }
        }
        items(feed, key = { it.key }) { entry ->
            when (entry) {
                is FeedEntry.Video -> MediaCard(entry.item, onClick = { onItemClick(entry.item) })
                is FeedEntry.Sponsored -> NativeAdCard(entry.slot)
            }
        }
        if (videos.isNotEmpty() && (hasMore || loadingMore)) {
            item(key = "footer") {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    when {
                        loadingMore -> CircularProgressIndicator(color = Accent, modifier = Modifier.size(28.dp))
                        loadMoreFailed -> TextButton(onClick = onLoadMore) {
                            Text("Couldn’t load more — tap to retry", color = Accent)
                        }
                        else -> TextButton(onClick = onLoadMore) { Text("Load more", color = Accent) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaCard(item: MediaItem, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clickable(onClickLabel = "Play ${item.title}", onClick = onClick).padding(bottom = 18.dp)
    ) {
        Box(
            Modifier.fillMaxWidth().height(190.dp).padding(horizontal = 12.dp)
                .background(SurfaceDark, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (item.thumbnailUrl != null) {
                AsyncImage(
                    model = item.thumbnailUrl,
                    contentDescription = null, // decorative: the card text below already names the item
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp))
                )
            }
            Icon(Icons.Default.PlayCircleFilled, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(58.dp))
            Text(
                item.source,
                color = Color.White,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
            if (item.duration.isNotBlank()) {
                Text(
                    item.duration,
                    color = Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp)
                        .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(5.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.AccountCircle, null, tint = Color.LightGray, modifier = Modifier.size(40.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${item.uploader} • ${item.source}", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun InfoPage(title: String, description: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().background(Bg).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(description, color = Color.LightGray)
    }
}
