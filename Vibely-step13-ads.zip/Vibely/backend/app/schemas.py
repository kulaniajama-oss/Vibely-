from pydantic import BaseModel
from typing import Optional

class MediaItem(BaseModel):
    id: str
    title: str
    uploader: str
    thumbnail_url: Optional[str] = None
    duration: Optional[str] = None
    source: str                      # display name, e.g. "Internet Archive"
    source_id: str = ""              # plugin id, e.g. "internetarchive"
    media_type: Optional[str] = None  # "video" | "audio"
    page_url: Optional[str] = None
    media_url: Optional[str] = None

class SearchResponse(BaseModel):
    query: str
    items: list[MediaItem]
    message: str
    page: int = 1
    has_more: bool = False

class SourceInfo(BaseModel):
    id: str
    name: str
    enabled: bool
    description: str

class ResolveResponse(BaseModel):
    source_id: str
    id: str
    media_url: str
    media_type: str
