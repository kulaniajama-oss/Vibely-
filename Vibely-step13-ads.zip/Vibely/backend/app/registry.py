import os
from urllib.parse import urlparse
import httpx
from bs4 import BeautifulSoup
import logging
from app.plugins.demo import DemoPlugin
from app.plugins.internet_archive import InternetArchivePlugin

log = logging.getLogger("vibely.registry")

class PluginRegistry:
    def __init__(self):
        self.plugins = [
            InternetArchivePlugin(),
            DemoPlugin(enabled=os.getenv("ENABLE_DEMO", "false").lower() == "true"),
        ]

    def _collect(self, call):
        """Run call(plugin) on every enabled plugin; one failing source never breaks the rest."""
        results, errors, has_more = [], [], False
        for plugin in self.plugins:
            if not plugin.enabled:
                continue
            try:
                items = call(plugin)
                results.extend(items)
                if len(items) >= plugin.page_size:
                    has_more = True
            except Exception as exc:  # noqa: BLE001 - isolate plugin failures
                log.warning("source %s failed: %s", plugin.source_id, exc)
                errors.append(plugin.display_name)
        return results, errors, has_more

    def search(self, query, page=1):
        return self._collect(lambda p: p.search(query, page))

    def featured(self, page=1):
        return self._collect(lambda p: p.featured(page))

    def resolve(self, source_id, item_id):
        for plugin in self.plugins:
            if plugin.source_id == source_id and plugin.enabled:
                return plugin.resolve(item_id)
        raise ValueError("Unknown or disabled source.")

    def source_status(self):
        return [
            {
                "id": p.source_id,
                "name": p.display_name,
                "enabled": p.enabled,
                "description": p.description,
            }
            for p in self.plugins
        ]

    def metadata(self, url: str):
        parsed = urlparse(url)
        if parsed.scheme != "https" or not parsed.hostname:
            raise ValueError("Only HTTPS page URLs are accepted.")

        allowed = {
            host.strip().lower()
            for host in os.getenv("ALLOWED_METADATA_DOMAINS", "").split(",")
            if host.strip()
        }
        host = parsed.hostname.lower()
        if not allowed or not any(host == d or host.endswith("." + d) for d in allowed):
            raise ValueError("This domain is not in ALLOWED_METADATA_DOMAINS.")

        try:
            with httpx.Client(
                timeout=8.0,
                follow_redirects=False,
                headers={"User-Agent": "VibelyMetadataBot/0.1"}
            ) as client:
                response = client.get(url)
                response.raise_for_status()
                content_type = response.headers.get("content-type", "")
                if "text/html" not in content_type:
                    raise ValueError("The permitted page did not return HTML.")
                soup = BeautifulSoup(response.text[:1_500_000], "html.parser")
                title = (
                    (soup.find("meta", property="og:title") or {}).get("content")
                    or (soup.title.string.strip() if soup.title and soup.title.string else "")
                )
                image = soup.find("meta", property="og:image")
                description = soup.find("meta", property="og:description")
                return {
                    "url": url,
                    "title": title[:300],
                    "thumbnail_url": image.get("content") if image else None,
                    "description": description.get("content")[:500] if description and description.get("content") else None,
                    "source": host,
                }
        except ValueError:
            raise
        except Exception as exc:
            raise RuntimeError(f"Metadata request failed: {exc}") from exc

registry = PluginRegistry()
