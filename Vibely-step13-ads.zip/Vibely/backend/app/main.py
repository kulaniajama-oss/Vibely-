from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from app.registry import registry
from app.schemas import ResolveResponse, SearchResponse, SourceInfo

app = FastAPI(
    title="Vibely API",
    version="0.3.0",
    description="Multi-source metadata discovery API for permitted sources."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict to your app/web origins before production.
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

def _message(count: int, errors: list[str], empty_text: str) -> str:
    text = f"{count} results." if count else empty_text
    if errors:
        text += " Unavailable right now: " + ", ".join(errors) + "."
    return text

@app.get("/health")
def health():
    return {"status": "ok", "service": "vibely-api"}

@app.get("/api/sources", response_model=list[SourceInfo])
def sources():
    return registry.source_status()

@app.get("/api/search", response_model=SearchResponse)
def search(q: str = Query(min_length=1, max_length=160), page: int = Query(1, ge=1, le=50)):
    items, errors, has_more = registry.search(q, page)
    return SearchResponse(
        query=q, items=items, page=page, has_more=has_more,
        message=_message(len(items), errors, "No results found."),
    )

@app.get("/api/featured", response_model=SearchResponse)
def featured(page: int = Query(1, ge=1, le=50)):
    items, errors, has_more = registry.featured(page)
    return SearchResponse(
        query="", items=items, page=page, has_more=has_more,
        message=_message(len(items), errors, "Nothing to show yet."),
    )

@app.get("/api/resolve", response_model=ResolveResponse)
def resolve(source_id: str = Query(min_length=1, max_length=40), id: str = Query(min_length=1, max_length=130)):
    try:
        result = registry.resolve(source_id, id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:  # upstream failure
        raise HTTPException(status_code=502, detail=f"Source request failed: {exc}")
    if not result:
        raise HTTPException(status_code=404, detail="No directly playable file found for this item.")
    return ResolveResponse(source_id=source_id, id=id, **result)

@app.get("/api/metadata")
def metadata(url: str = Query(min_length=8, max_length=2048)):
    # Metadata extraction is deliberately opt-in and domain-allowlisted.
    try:
        return registry.metadata(url)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
