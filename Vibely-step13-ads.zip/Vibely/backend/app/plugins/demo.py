from app.plugins.base import SourcePlugin
from app.schemas import MediaItem

class DemoPlugin(SourcePlugin):
    source_id = "demo"
    display_name = "Vibely Demo"
    description = "Sample catalog used to verify the app before live sources are configured."

    def __init__(self, enabled: bool = False):
        self.enabled = enabled

    def _samples(self) -> list[MediaItem]:
        return [
            MediaItem(id="demo-1", title="Welcome to Vibely", uploader="Vibely Team", source=self.display_name, source_id=self.source_id),
            MediaItem(id="demo-2", title="Discover technology and learning", uploader="Demo Channel", source=self.display_name, source_id=self.source_id),
            MediaItem(id="demo-3", title="Music and audio discovery", uploader="Demo Audio", source=self.display_name, source_id=self.source_id),
        ]

    page_size = 100

    def search(self, query: str, page: int = 1) -> list[MediaItem]:
        if page > 1:
            return []
        q = query.casefold()
        return [i for i in self._samples() if q in i.title.casefold() or q in i.uploader.casefold()]

    def featured(self, page: int = 1) -> list[MediaItem]:
        return self._samples() if page == 1 else []
