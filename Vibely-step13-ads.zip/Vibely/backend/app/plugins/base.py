from abc import ABC, abstractmethod
from typing import Optional
from app.schemas import MediaItem


class SourcePlugin(ABC):
    source_id: str
    display_name: str
    description: str
    enabled: bool = True
    page_size: int = 20  # a result list at least this long means "there may be more pages"

    @abstractmethod
    def search(self, query: str, page: int = 1) -> list[MediaItem]:
        raise NotImplementedError

    def featured(self, page: int = 1) -> list[MediaItem]:
        """Items shown on the home screen. Optional."""
        return []

    def resolve(self, item_id: str) -> Optional[dict]:
        """Return {"media_url": str, "media_type": str} for an item, or None."""
        return None
