"""Internet Archive source adapter.

Uses the public, documented Internet Archive APIs (advancedsearch + metadata).
Restricted/borrow-only items are excluded, so only openly accessible media is returned.
The parsing helpers are plain functions so they can be tested without network access.
"""
import json
import re
from typing import Optional

import httpx

from app.cache import TTLCache
from app.plugins.base import SourcePlugin
from app.schemas import MediaItem

BASE = "https://archive.org"
PAGE_SIZE = 24
SEARCH_TTL = 300      # seconds
RESOLVE_TTL = 1800
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")
HEADERS = {"User-Agent": "Vibely/0.2 (+https://github.com/)"}

VIDEO_EXT = (".mp4", ".m4v", ".webm")  # Android ExoPlayer cannot play Ogg Theora (.ogv)
AUDIO_EXT = (".mp3", ".m4a", ".ogg", ".opus", ".flac", ".wav")


def clean_query(q: str) -> str:
    """Strip Lucene operators so user text is treated as plain keywords."""
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s-]", " ", q, flags=re.UNICODE)).strip()


def build_search_query(q: str) -> str:
    base = "mediatype:(movies OR audio) AND -access-restricted-item:true"
    cleaned = clean_query(q)
    return f"({cleaned}) AND {base}" if cleaned else base


def _first(value) -> str:
    if isinstance(value, list):
        return str(value[0]) if value else ""
    return "" if value is None else str(value)


def format_runtime(value) -> Optional[str]:
    """Accepts seconds ("123.4"), "mm:ss" or "hh:mm:ss"; returns "m:ss"/"h:mm:ss"."""
    text = _first(value).strip()
    if not text:
        return None
    if ":" in text:
        return text
    try:
        total = int(float(text))
    except ValueError:
        return None
    if total <= 0:
        return None
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def doc_to_item(doc: dict) -> Optional[MediaItem]:
    identifier = _first(doc.get("identifier"))
    if not ID_RE.match(identifier):
        return None
    mediatype = _first(doc.get("mediatype"))
    return MediaItem(
        id=identifier,
        title=_first(doc.get("title")) or identifier,
        uploader=_first(doc.get("creator")) or "Internet Archive",
        thumbnail_url=f"{BASE}/services/img/{identifier}",
        duration=format_runtime(doc.get("runtime")),
        source="Internet Archive",
        source_id="internetarchive",
        media_type="audio" if mediatype == "audio" else "video",
        page_url=f"{BASE}/details/{identifier}",
    )


def pick_media_file(files: list[dict]) -> Optional[tuple[str, str]]:
    """Choose the best directly playable original/derivative file.

    Returns (filename, media_type) or None. Prefers mp4 video, then other video,
    then mp3 audio, then other audio. Skips tiny/sample files.
    """
    def usable(f):
        name = _first(f.get("name"))
        if not name or name.startswith("_") or "/" in name:
            return False
        try:
            size = int(_first(f.get("size")) or 0)
        except ValueError:
            size = 0
        return size == 0 or size > 20_000  # ignore stubs

    candidates = [f for f in files if usable(f)]

    def best(exts):
        for ext in exts:
            matches = [f for f in candidates if _first(f.get("name")).lower().endswith(ext)]
            if matches:
                # prefer derivative (smaller, streamable) over the source original
                matches.sort(key=lambda f: (_first(f.get("source")) == "original",
                                            int(_first(f.get("size")) or 0)))
                return _first(matches[0].get("name"))
        return None

    video = best(VIDEO_EXT)
    if video:
        return video, "video"
    audio = best(AUDIO_EXT)
    if audio:
        return audio, "audio"
    return None


class InternetArchivePlugin(SourcePlugin):
    source_id = "internetarchive"
    display_name = "Internet Archive"
    description = "Openly accessible movies and audio from archive.org (public API)."
    page_size = PAGE_SIZE

    def __init__(self, client: Optional[httpx.Client] = None):
        self._client = client
        self._cache = TTLCache(ttl_seconds=SEARCH_TTL, max_entries=256)

    def _get(self, url: str, params: Optional[dict] = None, ttl: float = SEARCH_TTL) -> dict:
        key = (url, json.dumps(params, sort_keys=True, default=str))
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        if self._client is not None:
            r = self._client.get(url, params=params)
        else:
            with httpx.Client(timeout=12.0, headers=HEADERS, follow_redirects=True) as c:
                r = c.get(url, params=params)
        r.raise_for_status()
        data = r.json()
        self._cache.set(key, data, ttl)  # failures raise above, so errors are never cached
        return data

    def _advanced_search(self, query: str, page: int = 1, sort: str = "downloads desc") -> list[MediaItem]:
        data = self._get(
            f"{BASE}/advancedsearch.php",
            params={
                "q": query,
                "fl[]": ["identifier", "title", "creator", "mediatype", "runtime"],
                "sort[]": sort,
                "rows": PAGE_SIZE,
                "page": max(1, page),
                "output": "json",
            },
        )
        docs = data.get("response", {}).get("docs", [])
        items = [doc_to_item(d) for d in docs]
        return [i for i in items if i is not None]

    def search(self, query: str, page: int = 1) -> list[MediaItem]:
        if not clean_query(query):
            return []
        return self._advanced_search(build_search_query(query), page)

    def featured(self, page: int = 1) -> list[MediaItem]:
        return self._advanced_search(
            "collection:(prelinger) AND mediatype:movies AND -access-restricted-item:true",
            page,
        )

    def resolve(self, item_id: str) -> Optional[dict]:
        if not ID_RE.match(item_id):
            raise ValueError("Invalid item id.")
        data = self._get(f"{BASE}/metadata/{item_id}", ttl=RESOLVE_TTL)
        picked = pick_media_file(data.get("files", []))
        if not picked:
            return None
        name, media_type = picked
        from urllib.parse import quote
        return {
            "media_url": f"{BASE}/download/{item_id}/{quote(name)}",
            "media_type": media_type,
        }
