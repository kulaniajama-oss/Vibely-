from app.plugins.internet_archive import (
    build_search_query, clean_query, doc_to_item, format_runtime, pick_media_file,
)


def test_clean_query_strips_lucene_operators():
    assert clean_query('foo:bar* "baz" (x) AND y') == "foo bar baz x AND y"


def test_build_query_filters_restricted_and_type():
    q = build_search_query("jazz")
    assert q.startswith("(jazz)")
    assert "-access-restricted-item:true" in q
    assert "mediatype:(movies OR audio)" in q


def test_format_runtime():
    assert format_runtime("125") == "2:05"
    assert format_runtime("3725.4") == "1:02:05"
    assert format_runtime("12:30") == "12:30"
    assert format_runtime(None) is None
    assert format_runtime("abc") is None


def test_doc_to_item():
    item = doc_to_item({"identifier": "abc_123", "title": ["T"], "creator": "C", "mediatype": "audio"})
    assert item.id == "abc_123" and item.title == "T" and item.media_type == "audio"
    assert item.thumbnail_url.endswith("/services/img/abc_123")
    assert doc_to_item({"identifier": "../evil"}) is None


def test_pick_media_file_prefers_video_derivative():
    files = [
        {"name": "movie.mpeg", "size": "999999", "source": "original"},
        {"name": "movie.mp4", "size": "500000", "source": "derivative"},
        {"name": "movie.ogv", "size": "400000", "source": "derivative"},
        {"name": "song.mp3", "size": "300000", "source": "original"},
    ]
    assert pick_media_file(files) == ("movie.mp4", "video")


def test_pick_media_file_audio_and_none():
    assert pick_media_file([{"name": "a.mp3", "size": "90000"}]) == ("a.mp3", "audio")
    assert pick_media_file([{"name": "notes.txt", "size": "10"}]) is None
