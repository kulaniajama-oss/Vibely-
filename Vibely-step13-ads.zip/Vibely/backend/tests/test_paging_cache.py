import pytest

from app.cache import TTLCache
from app.plugins.base import SourcePlugin
from app.plugins.internet_archive import InternetArchivePlugin, PAGE_SIZE
from app.schemas import MediaItem


class FakeResponse:
    def __init__(self, data):
        self._data = data

    def raise_for_status(self):
        pass

    def json(self):
        return self._data


class FakeClient:
    def __init__(self, data=None, fail=False):
        self.calls = []
        self.data = data if data is not None else {"response": {"docs": []}}
        self.fail = fail

    def get(self, url, params=None):
        self.calls.append((url, params))
        if self.fail:
            raise RuntimeError("boom")
        return FakeResponse(self.data)


def docs(n):
    return {"response": {"docs": [
        {"identifier": f"item{i}", "title": f"T{i}", "mediatype": "movies"} for i in range(n)
    ]}}


# ---------- TTLCache ----------

def test_cache_expires_with_fake_clock():
    now = [0.0]
    c = TTLCache(ttl_seconds=10, max_entries=5, clock=lambda: now[0])
    c.set("a", 1)
    assert c.get("a") == 1
    now[0] = 10.0
    assert c.get("a") is None


def test_cache_evicts_least_recently_used():
    c = TTLCache(ttl_seconds=100, max_entries=2, clock=lambda: 0.0)
    c.set("a", 1)
    c.set("b", 2)
    assert c.get("a") == 1          # a is now most recent
    c.set("c", 3)                   # evicts b
    assert c.get("b") is None
    assert c.get("a") == 1 and c.get("c") == 3


# ---------- Internet Archive paging + caching ----------

def test_ia_search_sends_page_param():
    client = FakeClient(docs(3))
    plugin = InternetArchivePlugin(client=client)
    plugin.search("jazz", page=3)
    _, params = client.calls[0]
    assert params["page"] == 3
    assert params["rows"] == PAGE_SIZE


def test_ia_identical_requests_are_cached():
    client = FakeClient(docs(2))
    plugin = InternetArchivePlugin(client=client)
    first = plugin.search("jazz", page=1)
    second = plugin.search("jazz", page=1)
    assert len(first) == len(second) == 2
    assert len(client.calls) == 1
    plugin.search("jazz", page=2)    # different page -> new request
    assert len(client.calls) == 2


def test_ia_errors_are_not_cached():
    client = FakeClient(fail=True)
    plugin = InternetArchivePlugin(client=client)
    for _ in range(2):
        with pytest.raises(RuntimeError):
            plugin.search("jazz")
    assert len(client.calls) == 2


def test_ia_resolve_rejects_bad_id():
    plugin = InternetArchivePlugin(client=FakeClient())
    with pytest.raises(ValueError):
        plugin.resolve("../etc/passwd")


# ---------- registry: has_more + failure isolation ----------

class FullPagePlugin(SourcePlugin):
    source_id, display_name, description, page_size = "full", "Full", "", 2

    def search(self, query, page=1):
        return [MediaItem(id=f"{page}-{i}", title="t", uploader="u", source="Full", source_id="full") for i in range(2)]


class ShortPagePlugin(SourcePlugin):
    source_id, display_name, description, page_size = "short", "Short", "", 5

    def search(self, query, page=1):
        return [MediaItem(id="s", title="t", uploader="u", source="Short", source_id="short")]


class BrokenPlugin(SourcePlugin):
    source_id, display_name, description = "broken", "Broken", ""

    def search(self, query, page=1):
        raise RuntimeError("down")


def make_registry(plugins):
    from app.registry import PluginRegistry
    reg = PluginRegistry()
    reg.plugins = plugins
    return reg


def test_registry_has_more_when_any_source_returns_full_page():
    items, errors, has_more = make_registry([FullPagePlugin(), ShortPagePlugin()]).search("x", 1)
    assert len(items) == 3 and errors == [] and has_more is True


def test_registry_no_more_when_pages_are_short():
    _, _, has_more = make_registry([ShortPagePlugin()]).search("x", 1)
    assert has_more is False


def test_registry_isolates_failing_source():
    items, errors, _ = make_registry([BrokenPlugin(), ShortPagePlugin()]).search("x", 1)
    assert len(items) == 1 and errors == ["Broken"]
