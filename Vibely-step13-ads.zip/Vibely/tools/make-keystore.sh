#!/usr/bin/env bash
# Creates the signing key for Vibely releases and prepares the values for GitHub Secrets.
#
# Needs a JDK (for `keytool`). Termux: `pkg install openjdk-17`. Ubuntu: `sudo apt install default-jdk-headless`.
# Run it ON YOUR OWN DEVICE (never in a shared or online environment).
#
#   bash tools/make-keystore.sh
#
# IMPORTANT: back up vibely-release.jks and your password somewhere safe (e.g. a password manager).
# If you lose either one you can never publish an update to people who installed a signed Vibely.
set -euo pipefail

KEYSTORE="vibely-release.jks"
ALIAS="vibely"

if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool not found. Install a JDK first (Termux: pkg install openjdk-17)." >&2
  exit 1
fi
if [ -e "$KEYSTORE" ]; then
  echo "$KEYSTORE already exists. Refusing to overwrite it." >&2
  exit 1
fi

echo "keytool will now ask for a password and some details about you."
echo "Use ONE password for both the keystore and the key (just press Enter when asked for the key password)."
echo

keytool -genkeypair -v \
  -keystore "$KEYSTORE" \
  -alias "$ALIAS" \
  -keyalg RSA -keysize 2048 -validity 10000

# GitHub Secrets can only hold text, so the binary keystore is stored base64-encoded.
base64 < "$KEYSTORE" | tr -d '\n' > "$KEYSTORE.base64.txt"

cat <<MSG

Done. Created:
  $KEYSTORE              <- the real key. Back it up. NEVER commit or share it.
  $KEYSTORE.base64.txt   <- the same key as text, for the KEYSTORE_BASE64 secret.

In your GitHub repo open Settings -> Secrets and variables -> Actions and add these 4 *secrets*:
  KEYSTORE_BASE64     = the full contents of $KEYSTORE.base64.txt
  KEYSTORE_PASSWORD   = the password you just chose
  KEY_ALIAS           = $ALIAS
  KEY_PASSWORD        = the same password again

Then add one *variable* (Variables tab, not Secrets):
  VIBELY_BACKEND_URL  = https://YOUR-SERVICE.onrender.com   (your Render URL)

When everything is saved, delete $KEYSTORE.base64.txt from this device (keep $KEYSTORE backed up).
MSG
